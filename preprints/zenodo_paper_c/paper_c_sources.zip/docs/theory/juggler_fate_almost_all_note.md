---
title: "Fate Contagion and Termination Criteria for the Juggler Map"
author: Philippe Cochin
date: 24 September 2026
keywords:
  - Juggler map
  - Juggler sequence
  - floor-power maps
  - logarithmic density
  - almost-all orbits
  - Collatz map
  - integer dynamics
header-includes:
  - \usepackage{amsmath,amssymb}
  - \usepackage{float}
  - \floatplacement{figure}{H}
  - \AtBeginDocument{\author{Philippe Cochin \\ \texttt{philippe@cochin.fr}}}
---

## Abstract

The Juggler map sends an even positive integer to the integer part of
its square root and an odd positive integer to the integer part of
its three-halves power. We prove that every nonempty set \(A\) of
positive integers closed under taking preimages satisfies
\(\sum_{n\in A,\,n\le x}1/n\ge c(\log x)^{37/50}\) for all sufficiently
large \(x\). Thus any realized cycle basin or nonempty class of
unbounded orbits must have this divergent logarithmic mass. Five
disjoint actual predecessor families, with initial words E, OE, OOEE,
OOOEE and OOEOE, supply the recursion. The two five-letter families
enter through the averaged fair-share theorem of the companion Paper B
(its Theorem 6.3), an AI-assisted written proof that has not been
independently reviewed; the deduction from that theorem, and the
recursion, are kernel-checked in Lean.

Without the two five-letter families the exponent is \(5/8\), and that
result is now machine-checked end to end: Lean proves the actual OOEE
production from its summable poor-fiber tail, and Appendix E gives the
written argument. The earlier two-production route remains an
elementary Lean baseline at \(100/203\).

For a fixed verified target \([1,N_0]\), universal termination is
equivalent to an eventual-entry statement: all but
\(O(y(\log y)^{-e})\) odd starts in \((y,2y]\) enter that target,
for some \(e>13/50\); the machine-checked threshold, which does not use
Paper B, is \(3/8\). The rate itself remains unproved. Parity-cylinder,
live-pressure and scale-averaged pressure bounds are sufficient
arithmetic inputs; none is established here. Earlier finite-production
and localized-discrepancy arguments are retained with their original
scope, and the numerical experiments remain observations. Neither
universal termination nor exclusion of every nontrivial cycle or
unbounded orbit is established.

**2020 Mathematics Subject Classification:** 11B37, 11L07, 37P99.

**Keywords:** Juggler map; preimage sets; logarithmic counting;
parity cylinders; integer dynamics.

## 1. Introduction

For a positive integer \(n\), define
\[
J(n)=\begin{cases}
\lfloor\sqrt n\rfloor,&n\text{ even},\\
\lfloor n^{3/2}\rfloor,&n\text{ odd}.
\end{cases}
\]

The Juggler sequence was introduced by Pickover [1] and is
sequence A094683 of the OEIS [2]. Starting from any positive integer,
the orbit under \(J\) appears always to reach \(1\); this has been
verified for all starts up to \(3.5\cdot 10^8\) [11]. The map belongs
to the family of floor-power maps, and its dynamics resembles the
\(3x+1\) problem [3, 4] in one respect and differs from it in another.
The resemblance: a parity decides whether the orbit goes up or down,
and the heuristic model of the orbit is a random walk with negative
drift, here on the scale \(\log\log n\) with steps \(+\log_2 3-1\)
(odd) and \(-1\) (even). The difference: the Juggler map moves by
*powers*, so a single contracting certificate sends \(n\) to
\(n^{e}\) with \(e<1\), and the one-step preimages of an integer are
not a residue class but an interval.

This paper is about the second feature and what it forces. The
narrative has four steps.

*Contagion.* Let \(R\) be the set of starts that reach \(1\), \(F\)
its complement, \(B(C)\) the basin of a nontrivial cycle \(C\), and
\(D\) the set of divergent starts. Each is *backward-closed*: if
\(J(n)\) belongs to it, so does \(n\). Theorem 1 proves that every
nonempty backward-closed set is large in logarithmic density, with an
explicit exponent, by a downward recursion over five actual
productions: E, OE and OOEE (Sections 5.8--5.9 and Appendix E), which
are machine-checked and give the exponent \(5/8\), and the two
five-letter words OOOEE and OOEOE, which enter through Paper B's
averaged fair-share theorem and raise it to \(37/50\) (Section 5.10).
Applied to the fate classes: if a single start fails to
reach \(1\), the failures have logarithmic count
\(\gg(\log x)^\lambda\) and, on infinitely many dyadic blocks,
natural density \(\gg(\log y)^{\lambda-1}\), for every
\(0<\lambda\le37/50\). This excludes no fate; it fixes the
quantitative shape of the trichotomy.

*Odd generation.* A set that is closed both forwards and backwards
and avoids \(1\) is the \(E\)-forest (iterated even preimages) over
its odd members, and its odd members are the odd preimages of its
intersection with the sparse set \(S=\{\lfloor m^{3/2}\rfloor:\ m\
\text{odd}\}\) (Theorem 2). An arbitrary failure set is thereby
replaced by sparse odd-image seeds together with deterministic even
ancestry. This is the geometry that the later sections use.

*The almost-all equivalence.* Tao [6] proved that almost all Collatz
orbits (in logarithmic density) attain almost bounded values, with a
target \(f(N)\to\infty\) arbitrarily slowly. For the Juggler map,
contagion and odd generation together turn a bounded-target statement
into the conjecture: every positive integer reaches \(1\) if and only
if all but \(O(y(\log y)^{-e})\) odd starts in \((y,2y]\) enter
\([1,N_0]\), for some \(e>13/50\) (Theorem 3). The
threshold is the complement of the contagion exponent. The Collatz preimage lower bound of Krasikov--Lagarias [7],
discussed with its target restriction in Section 1.3, does not
by itself yield this implication.

*Sufficient estimates at growing depth.* The exponent walk needs to
fall by \(L(y)=\log_2(\log(2y)/\log N_0)\) to put a start in
\((y,2y]\) below the floor. A Chernoff estimate counts words whose
walk fails to cross this level by depth \(\lceil CL(y)\rceil\).
Turning this word count into a count of integer starts requires
additional arithmetic information. Sections 8--9 give three
sufficient forms of that information: upper bounds on bad cylinders,
one-sided control of their continuations, and a bound on one
exponential moment of live starts. A bound on tilted odd shares
implies the moment bound. None is established here.

The first-letter decomposition in Section 6 relates the remaining
\(OO\)-contribution to failures at a larger scale. Section 10 connects
this term with live-start counts and states a uniformity requirement
for a particular cylinder-counting method. These are reductions and
limitations of the stated estimates, not necessity results for every
possible proof of termination.

### 1.1 Main results

Write \(\ell_A(u,v]=\sum_{n\in A,\,u<n\le v}1/n\). Throughout,
\(N_0\ge2\) is any integer with \([1,N_0]\subseteq R\) (the Lean-verified
value is \(260\); the certified computational value is
\(3.5\cdot 10^8\) [11]).

**Theorem 1 (fate contagion).** Let \(A\subseteq\mathbb N\) be nonempty
and backward-closed, and let \(0<\lambda\le37/50\).
There are \(c>0\) and \(x_0\), depending on \(A\) and \(\lambda\), with
\[
\sum_{\substack{n\in A\\ n\le x}}\frac1n\ \ge\ c\,(\log x)^{\lambda}
\qquad(x\ge x_0).
\]
Consequently each fate class realized by at least one start — \(R\),
the basin of any existing nontrivial cycle, the divergent set —
satisfies this bound, and on infinitely many dyadic blocks has natural
density \(\gg(\log y)^{\lambda-1}\). (Theorems 5.19 and 5.20 and their dyadic consequences.)

For \(\lambda\le5/8\) its log-mass bound is kernel-checked in Lean with
no hypothesis (Theorem 5.19), and Appendix E gives a written argument for
its analytic input. The range \(5/8<\lambda\le37/50\) (Theorem 5.20)
uses one further input, Theorem 6.3 of Paper B [12], an AI-assisted
written proof that has not been independently reviewed; the deduction of
the log-mass bound from it is kernel-checked. At both exponents the
dyadic clause is written. The two earlier routes
are retained with their original exponents, as follows. The route of Sections 4--5 and Appendix D
--- the block average of Proposition 4.4, the monotone sweep and the
six finite productions of Section 5.7 --- gives every
\(\lambda<\lambda^{**}\approx0.4926\), the root of
\[
2^{-\lambda}+\tfrac19(\tfrac38)^\lambda+\tfrac29(\tfrac34)^\lambda
 +\sum_{k=2}^{6}3^{-(k+1)}\left(\tfrac12(\tfrac34)^k\right)^\lambda=1.
\tag{1.1}
\]
(The \(V_5\) truncation of the first seven terms is \(0.4924\); the \(V_4\) truncation of the first six terms is \(0.4916\); the \(V_3\) truncation of the first five is \(0.4891\); the \(OEOEE\) truncation of the first four is \(0.4801\); the pairing-only root of the first three is \(0.4480\).)
The two-production route of Section 5.8 uses no exponential sum: the
fibers whose parity share is far from \(\tfrac12\) have finite total
logarithmic mass, so the pointwise coefficient \(\tfrac29\) of the
\(OE\) family may be replaced by the averaged one, and the recursion
reaches every \(\lambda<\lambda_{\mathrm{ideal}}\), where
\(2^{-\lambda_{\mathrm{ideal}}}+\tfrac13(3/4)^{\lambda_{\mathrm{ideal}}}=1\)
and \(\lambda_{\mathrm{ideal}}\approx0.4927\). That route is formalized
in Lean 4 with no hypothesis for every \(\lambda\le100/203=0.49261\ldots\),
which exceeds \(\lambda^{**}\); the range
\(100/203<\lambda<\lambda_{\mathrm{ideal}}\) is one choice of a parameter
\(\eta_0\) away and is not separately certified. The formal infinite
series of the finite productions has the same limiting root
\(\lambda_{\mathrm{ideal}}\).
The ideal characteristic model in Proposition 5.12 has root
\(1\); the other run-model values, including \(0.8414\), are
conditional calculations and are not attained density exponents.

**Theorem 2 (odd generation).** Let \(A\) be forward- and
backward-closed with \(1\notin A\). Every \(n\in A\) reaches by a possibly empty sequence of even
steps to an odd member \(m\ge 3\) of \(A\); for odd \(n\),
\(n\in A\iff\lfloor n^{3/2}\rfloor\in A\); and \(A\ne\emptyset\) iff
\(A\) contains the image \(\lfloor m^{3/2}\rfloor\) of some odd
\(m\ge 3\). In particular every positive integer reaches \(1\) iff no
odd image fails to. (Theorem 6.1; Lean.)

**Theorem 3 (the conjecture as an almost-all statement).** The
following are equivalent: (i) every positive integer reaches \(1\);
(ii) for some \(0<\lambda\le37/50\), the starts \(n\le x\) whose
orbit never enters \([1,N_0]\) have logarithmic count
\(o((\log x)^{\lambda})\); (iii) for some \(e>13/50\)
(\(e>3/8\) using only the machine-checked Theorem 5.19) and all large \(y\), \(\#\{n\ \text{odd}\in(y,2y]:\ n\notin R\}\le y(\log y)^{-e}\).
(Corollary 7.1, Theorems 7.2, 7.3.)

**Theorem 4 (the frontier reduction).** Let
\(L(y)=\log_2(\log 2y/\log N_0)\), \(d(y)=\lceil CL(y)\rceil\),
\(p_C=(1-1/C)/\log_2 3\), \(e(C)=C\,D(p_C\|\tfrac12)/\ln 2\), and
\(e_q^{\rm Az}(C)=2(C(1-q\log_2 3)-1)^2/
(C(\log_2 3)^2\ln2)\). Assume \(C\ge5\). The following hypotheses give
the indicated, case-dependent bounds. Each implies (iii) of Theorem 3
whenever its displayed rate exceeds \(13/50\), using Theorem 1, or
\(3/8\), using only the machine-checked Theorem 5.19. The constants
\(C\) below are the least integers for the threshold \(13/50\), with
those for \(3/8\) in parentheses (Appendix B):

(a) *cylinder form* \(\mathrm H(C,A)\): no \(O\)-rooted,
\(L(y)\)-bad itinerary cylinder of depth \(d(y)\) exceeds its fair
share \(2^{-(d-1)}y/2\) among odd starts by more than
\(y(\log y)^{-A}\), \(A>C+e(C)\)
(Theorem 8.3), giving \(e(C)-\varepsilon\) and hence the conjecture for
\(C\ge14\) (\(C\ge16\));

(b) *one-sided form* \(\mathrm H_q(C,A)\), with
\(0<q<\log 2/\log 3\) and \(C>1/(1-q\log_2 3)\): every
\(L(y)\)-bad cylinder of depth \(1\le t<d(y)\) sends at most a fraction
\(q\) of its members, plus \(y(\log y)^{-A}\), to an odd next state
(Theorem 9.1;
\(A>C+e_q^{\rm Az}(C)\)), giving \(e_q^{\rm Az}(C)-\varepsilon\);
at \(q=0.55\), \(C\ge28\) (\(C\ge34\)) crosses the threshold;

(c) *pressure form* \(\mathrm P_\theta(C)\):
\(\frac1N\sum_{n\ \mathrm{odd}\in(y,2y],\ \tau(n)>d}e^{\theta o_d(n)}\le(\tfrac12(1+e^{\theta}))^{d}e^{o(d)}\)
at \(\theta=\log(p_C/(1-p_C))\), with \(N=y/2\), where \(\tau\) is the entrance time
into \([1,N_0]\) and \(o_d\) the odd count of the first \(d\) letters;
this gives \(e(C)-\varepsilon\). Its biased *no-momentum form*, for
\(0<q<p_C<1\),
\(\sum_{t<d}(s_\theta(t)-q)^+=o(d)\) gives
\(C D(p_C\|q)/\ln2-\varepsilon\) only at the optimizing tilt
\(\theta=\log(p_C(1-q)/(q(1-p_C)))\) (Theorem 9.2,
Proposition 9.3).

None of these hypotheses is proved here. A bounded loss at each
of \(o(\log\log y)\) exceptional depths can be absorbed in the
moment criterion. The tower comparison and finite-depth model in
Section 9.3 describe the scope of this argument; neither is an
arithmetic necessity theorem.

**Theorem 5 (first-letter decomposition).** A two-way closed set
has the disjoint first-letter decomposition of Section 6.2. In the
normalization used there, its logarithmic density satisfies (6.1),
with the stated boundary error. For the failure set \(F\), the free
term \(\psi_F\) is a known normalization factor times the decreasing
limit of the live proportion among \(OO\)-type starts
(Proposition 10.1). Each sufficient estimate of Theorem 4 bounds this
term at its stated logarithmic rate. The upper recursion obtained by
bounding the fiber weights gives decay estimates with a critical
exponent; that upper inequality alone does not force the failure set
to be empty (Corollary 10.2).

**Proposition (depth-uniformity budget).** Suppose the error bound
available for each cylinder is
\(K2^{\kappa d}y^{1-\delta_0 2^{-cd}}\), with
\(K,\delta_0,c>0\) and \(\kappa\ge0\) independent of the depth.
The resulting union-bound error is negligible at depth
\(C\log_2\log y+O(1)\) precisely when \(cC<1\)
(Proposition 10.3). This is a criterion for the available error
majorant, not a lower bound on the actual discrepancy.

Under a localization of the triple parity discrepancy of nested floor
powers to sub-dyadic intervals — stated as an explicit hypothesis in
Appendix C; Paper B [12] lists the short-interval localization it
needs among its open questions — the earlier two-production exponent improved to
\(\lambda^{***}\approx0.5392\), with rate threshold \(0.4608\) and least
depth constant \(C\ge 18\). This conditional comparison is now weaker
than Theorems 5.19 and 5.20.
Nothing in Sections 2--12 depends on Appendix C.

### 1.2 The three fates as currently constrained

The three fate classes are the three Moirai: Atropos cuts the thread
(the class \(R\)), Lachesis measures an allotted length (a cycle
basin), Clotho spins without end (divergence). What is known about
each, all from outside this paper:

- *Atropos.* Every \(n\le N_0=3.5\cdot 10^8\) reaches \(1\)
  (independently certified computation, [11, Section 5]); the
  Lean-verified floor is \(N_0=260\). Paper B [12] proves that
  \(7/8\) of all starts descend below themselves within five steps,
  with a power saving on dyadic blocks.
- *Lachesis.* A nontrivial cycle has minimum above \(3.5\cdot 10^8\)
  and period at least \(780239\) [11]; it has at least four even
  steps; if \(3^o/2^L=1+\Lambda\), its odd share is
  \(\log 2/\log 3+\log(1+\Lambda)/(L\log3)\), strictly above but,
  under the finance bound, very near the critical zero-drift share.
- *Clotho.* A divergent orbit has unbounded exponent walk; its record
  jumps are quantized to the \(\log_2 3\) lattice [11]. Nothing
  excludes it.

Theorem 1 adds one sentence to each: whichever of the three acts at
all acts on a set of logarithmic count \(\gg(\log x)^\lambda\)
for every \(0<\lambda\le37/50\): machine-checked up to \(5/8\), and
beyond it with the review boundary of Paper B's Theorem 6.3.

### 1.3 Related work

*Collatz parity vectors.* Terras [4] and Everett [5] showed that the
first \(k\) parities of the Collatz orbit of \(n\) are determined by
\(n\bmod 2^k\) and equidistributed exactly, and deduced that almost
all starts have finite stopping time (descend below themselves). The
analogous exact statement fails for the Juggler map: the parities of
\(\lfloor n^{3/2}\rfloor\), \(\lfloor\lfloor n^{3/2}\rfloor^{3/2}\rfloor\),
\(\dots\) are Diophantine, not algebraic, and their equidistribution
is proved only through the words of length five (Paper B, [12]).

*Tao's theorem.* Tao [6] proved that for any \(f(N)\to\infty\), almost
all Collatz orbits (in logarithmic density) attain a value below
\(f(N)\). The bounded-target version is not available, and the
renewal machinery through the Syracuse random variables is the heart
of the proof. Section 7.1 explains, as a structural analogy and not
as a transfer of methods, which parts of that picture change for the
Juggler map.

*Preimage trees.* Krasikov and Lagarias [7] obtain an
\(x^{0.84}\) lower bound for Collatz preimage counts, for targets not
divisible by \(3\) and sufficiently large \(x\). Such a lower bound
alone does not give a divergent logarithmic count: a set whose
counting function is \(O(x^{0.84})\) has a convergent reciprocal sum.
It therefore cannot by itself contradict a failure estimate of size
\(y(\log y)^{-e}\). For Juggler, Theorem 1 gives a divergent
logarithmic lower bound for every nonempty preimage set.

*Floor-power maps and exponential sums.* The parity of
\(\lfloor n^{3/2}\rfloor\) along an arithmetic progression is a
question about \(\{n^{3/2}/2\}\); Section 4 uses only an elementary
sweep argument and, on even blocks, the second-derivative test with
Vaaler's approximation [10], as for Piatetski-Shapiro sequences.
Deeper nesting is Paper B's subject.

*Companion papers.* Paper A [11] proves period lower bounds for a
hypothetical cycle from a certified descent floor (cycle financing,
walk-charge envelope); Paper B [12] proves that the five-step
power-envelope certificates have density \(7/8\), with a power saving,
from the parity equidistribution of nested floor powers; its Theorem
6.3 gives the fair share on almost every depth-five fiber, the input of
Section 5.10. Neither paper is reproved here; both enter as citations,
and one statement of the type Paper B proves enters Appendix C as an
explicit hypothesis.

### 1.4 Verification

Statements carry one of four roles. *Lean*: the exact combinatorial
layer is formalized in Lean 4; the root `formal/Problems/JugglerFatePaper.lean`
imports exactly the thirty-seven modules of its historical barrel and
builds with `lake build Problems.JugglerFatePaper`, without `sorry` and
without `native_decide`; `formal/AxiomCheckPaperC.lean` prints the axiom
dependencies of every name in that barrel and `AxiomCheckPaperC.expected`
records them — Mathlib's `propext`, `Classical.choice`, `Quot.sound`
and nothing else (names in Appendix A). The supplementary modules of
Theorems 5.19 and 5.20 have their own axiom checks, with the same three
axioms (Appendix A). *Human proof*: the analytic and
probabilistic counting. *Verified computation*: exact integer
computations (the descent floor is Paper A's; the closure of
\([1,260]\) under the two productions up to \(10^9\) is computed
here). *Observation*: numerical experiments that check hypotheses and
constants; they prove nothing and are labelled wherever they appear.

| Result | Status |
|---|---|
| Fate classes closed; trichotomy; exclusion (Lemma 2.1) | Lean |
| Even block is an interval (Lemma 3.1) | Lean |
| \(OE\) fiber is an interval; cell identity (Lemma 3.2) | Lean |
| Odd generation (Theorem 6.1) | Lean |
| Envelope descent into the floor (Lemma 8.1) | Lean, on Paper A's power envelope |
| Sweep lemma (Lemma 4.1), both half-cell conventions | Lean |
| Monotone pairing (Lemma 4.1') | Lean |
| Fiber parity (Lemma 4.2), goodness unpacked | Lean, through Lemma 4.1' |
| Thin fibers (Lemma 4.3): the count on \((u,2u]\) and the log-mass of the bad \(m>U\) | Lean |
| Block average (Proposition 4.4), asymptotic | human proof; the exact layer, the slow sum \(O(m')\), the two-sided count of the block and the deduction of (4.1) and of the asymptotic form from the two remaining exponential-sum bounds are Lean, those two bounds are not |
| Share law and its three corollaries (Lemma 4.5, Corollary 4.6) | human proof; the phase expansion with its cubic remainder, the range of the quadratic phase with its threshold \([-\tfrac56,\tfrac16]\), and the integral \(\tfrac{25}{108}\) are Lean, the equidistribution and the measure identifications are not |
| Production inequality (5.2) with the \(V\)-ladder terms of Section 5.7 | human proof; the \(E\)-family and the \(OE\)-fiber family are Lean with explicit errors, the block-average family needs the two exponential-sum bounds and the ladder needs Appendix D |
| Theorem 5.3 at exponent \(13/40\), unconditional: two productions at the pointwise coefficient, no hypothesis | Lean; superseded in exponent by the averaged route below |
| Block lock (Lemma 5.14): a fiber's parity share leaves \(\tfrac12\) only by locking onto a rational step of small denominator | Lean |
| Fiber lock (Lemma 5.15), by Dirichlet approximation | Lean |
| Resonance count, the arc count behind Theorem 5.16 | Lean |
| Poor-fiber tail (Theorem 5.16) and the share on an arbitrary set (Corollary 5.17) | Lean |
| Theorem 5.18, contagion by two productions at the averaged coefficient: Theorem 5.3 for every \(0<\lambda\le100/203\) with no hypothesis, and Theorem 7.2 and Corollary 8.4 with their contagion hypothesis discharged at \(e>103/203\) | Lean; the supremum \(\lambda_{\mathrm{ideal}}\) and the range \(100/203<\lambda<\lambda_{\mathrm{ideal}}\) are the choice of \(\eta_0\), human |
| Fate contagion at the failure set, log-mass form (Corollary 5.5(2), first clause) | Lean, unconditionally at exponent \(100/203\) and, by the pointwise route, at \(13/40\): the failure set is backward-closed by Lemma 2.1 and nonempty by assumption, so Theorem 5.18 applies to it |
| Corollary 5.4 (natural density, infinitely often): the dyadic pigeonhole, from the shell bound of Theorem 5.18 | Lean, for every \(0<\lambda\le100/203\) with no hypothesis and with the constant \(K/12\); the range \(100/203<\lambda<\lambda_{\mathrm{ideal}}\) is human, as for Theorem 5.18 |
| Corollary 5.5 at the three fate classes: the reach-one class, the failures, the basin of a cycle state and the divergent starts, each in log-mass form and in dyadic-block form | Lean, at exponent \(100/203\), by instantiating Theorem 5.18 and Corollary 5.4 through Lemma 2.1 |
| Production words \(V_k=(OE)^{k-1}OEE\) are prefix-free (Section 5.7, Appendix D) | Lean, for the whole family and not only the six; the disjointness of source sets it feeds needs Appendix D's analytic layer, which is human |
| The side condition \(e(C)>\tfrac{27}{40}\) of the unconditional criteria, at \(C=30\), by rational bounds on \(e\), \(\log 2\) and \(\log_2 3\) | Lean; the least such \(C\) (\(23\)) and the paper's own thresholds \(13/50\) and \(3/8\) stay with the audit |
| Cube fibers full or alternating (Lemma 4.7) | Lean |
| Recursion lemma (Lemma 5.1) | Lean |
| Seed (Lemma 5.2) | Lean |
| Contagion (Theorem 5.3), given the production inequality (5.2), for every \(\lambda\le 0.49\) | Lean; \(\zeta(0.49)>0\) by exact rational bounds, the root \(\lambda^{**}\) is human |
| Least failure is \(OO\)-type; first-letter trichotomy (Proposition 6.3(i), Section 6.2) | Lean |
| First-letter identity (6.1) | Lean, the exact three-piece decomposition and the uniqueness of the odd preimage; the normalization to \(\varphi_A,\varphi^{\rm fib}_A,\psi_A\) and the boundary error are human |
| Tao-type rate implies the conjecture (Theorem 7.2), with the contagion bound of Theorem 5.3 as a hypothesis | Lean |
| Almost-all equivalence (Theorem 7.3), with the contagion bound of Theorem 5.3 as a hypothesis | Lean |
| Corollary 8.4, the conjecture from a cylinder bound, with the contagion bound of Theorem 5.3 as a hypothesis | Lean |
| Chernoff count of bad words (Lemma 8.2, exact form) | Lean |
| Theorem 8.3, explicit form \(y\Lambda^{-e(C)}+2\Lambda^Cy(\log y)^{-A}\) at every \(y\) | Lean; the \(\varepsilon\)-absorption into the displayed form is human |
| Pressure form (Theorem 9.2, exact: a pressure bound \(Na_\theta^dE\) gives at most \(Ne^{-dD(p_C\Vert 1/2)}E\) live starts) | Lean, on the live weight |
| Pressure telescoping (Proposition 9.3) | Lean, on the word-weight framework |
| One-sided form (Theorem 9.1, exact: at every \(y\) the odd failures of \((y,2y]\) number at most \((xa_q^{d-1}N+(x-1)\,\mathrm{err}\,(d-1)(2x)^{d-1})/x^{p_Cd}\) for every tilt \(x\ge1\), by exponential moments) | Lean, without the martingale; the absorption of the error into the rate and the displayed asymptotic form are human |
| The conjecture from the one-sided hypothesis \(\mathrm H_q(C,A)\) (Theorem 9.1's consequence), with the contagion bound as a hypothesis, or with nothing else assumed when \(e^{\rm Ch}_q(C)>\tfrac{27}{40}\) | Lean; the exponent is the Chernoff one of Proposition 9.3 with \(A>C(1+\log_2x)+1+e\), the paper's numerical forms are human. The hypothesis \(\mathrm H_q(C,A)\) itself is doubtful: see the barrier word in Section 9.1 |
| The conjecture from the pressure hypothesis \(\mathrm P_\theta(C)\) and from the no-momentum hypothesis \(\mathrm M_{\theta,q}(C)\) (Section 9.2's consequences), with the contagion bound as a hypothesis, or with nothing else assumed when the exponent exceeds \(\tfrac{27}{40}\) | Lean; the paper's \(e^{o(d)}\) is quantified as \((\log y)^\varepsilon\) and its \(o(d)\) as \(\delta d\), the numerical forms are human |
| Theorem 9.1 with exceptional atoms (Section 10(d), first paragraph): the share bound may fail on bad atoms of total mass \(y(\log y)^{-B}\) at each depth, and the conjecture still follows, with nothing else assumed when the exponent exceeds \(\tfrac{27}{40}\) | Lean; the condition is \(B>C\log_2x+1+e\) in place of the paper's \(B>e_q(C)\), sufficient and not sharp |
| The bias energy of the \(L(y)\)-bad words supplies the exceptional atoms (Section 10(d)): \(\sum_{w\ \text{bad}}D(w)^2\le(q-\tfrac12)^2y^2(\log y)^{-2B}/2^t\) at the depths below \(\lceil CL(y)\rceil\), at all large scales, gives the conjecture with nothing else assumed | Lean, by Cauchy--Schwarz on the bad atoms that violate the share bound; the exact enumeration of Section 11 finds that energy at its worst-case value from depth \(16\)--\(20\) at every computable scale, so the hypothesis has no numerical support |
| Collapsed-component bias (Section 10(d), after the measurement): the next-letter bias of the starts whose iterate lands in a window of values is an alternating sum of fiber sizes, bounded by the variation of the fiber profile, the even branch smooths it, \((v+1)(M_v-m_v)+2M_v\) per value, and a sandwich on the profile propagates through even steps without amplification | Lean; the variation bound on a fiber profile and the parity of the odd-preimage mass are human |
| Azuma and exponential-moment arguments (Sections 8--10, except Lemma 8.2, Theorem 8.3, Theorem 9.1, Theorem 9.2 and Proposition 9.3 in their exact forms) | human proof |
| Cylinder-splitting identity for the first-letter bias (Section 10(d), second equality) | Lean; the Parseval form in Walsh sums, and the exceptional-atom estimate it is meant to supply, are human |
| Exact landing windows of the nested productions ((D.1), (D.2)) | Lean; the smooth comparison (D.3), the multiplicities and the production inequality they feed are human |
| Localized triple discrepancy (Appendix C) | hypothesis, conditional |
| Theorem 5.19, the log-mass bound at 5/8, and Theorems 7.2 and 9.4 and the corollaries of Theorem 9.2 and Proposition 9.3 at the threshold 3/8 | Lean, with no contagion-side hypothesis: `FateOOEEWeighted` proves the actual OOEE production from a count form of its poor-fiber tail (`OOEEResonanceTail`), and `FatePressureOOEE` gives the corollaries; Appendix E is the written argument; the dyadic clause of Theorem 1 and Corollary 7.1 are human proofs |
| Theorem 5.20, the log-mass bound at 37/50, and Theorem 7.2 and the corollaries of Theorem 9.2 and Proposition 9.3 at the threshold 13/50 | human proof for its one analytic input, Theorem 6.3 of Paper B [12], which is AI-assisted and not independently reviewed; Lean from the finiteness of the two reciprocal sums it bounds (`FateDepthFiveWeighted`, `FateDepthFiveAssembly`); Theorem 9.4 at 13/50, the dyadic clause and Corollary 7.1 are human proofs |
| OOEE mixed modes on the actual short source interval | Lean, in OOEEMixedModes; the poor-fiber tail and the production built on it are Lean in `OOEEResonanceTail` and `FateOOEEWeighted` |
| Numerical experiments (Section 11) | observation |

![Logical dependencies. The arithmetic lemmas feed the contagion theorem. Each unproved parity hypothesis is a sufficient route to a time-bounded live count, which implies eventual termination only at the stated rate. No converse time bound is asserted.](figures/paper_c_dependencies.png){ width=88% }

## 2. Fate classes and closure

\(\mathbb N=\{1,2,\dots\}\). For \(A\subseteq\mathbb N\) and
\(0\le u<v\) write
\[
\ell_A(u,v]=\sum_{\substack{n\in A\\ u<n\le v}}\frac1n,\qquad
g_A(t)=\ell_A\bigl(e^{t/2},e^{t}\bigr].
\]
For \(A=\mathbb N\), \(g(t)=t/2+O(e^{-t/2})\).

**Definition.** \(A\) is *backward-closed* if \(J(n)\in A\) implies
\(n\in A\), and *forward-closed* if \(n\in A\) implies \(J(n)\in A\).

**Lemma 2.1 (fate classes).** Let \(R=\{n:\exists k,\ J^k(n)=1\}\),
\(F=\mathbb N\setminus R\), \(B(m)=\{n:\exists k,\ J^k(n)=m\}\), and
\(D=\{n:\forall B\ \exists k,\ J^k(n)>B\}\). Each of \(R,F,B(m),D\) is
backward-closed; \(R,F,D\) are also forward-closed. Every \(n\ge 1\)
lies in \(R\), or in \(B(m)\) for some \(m\ge 2\) on a cycle, or in
\(D\), and these possibilities exclude one another.

*Proof.* Backward closure is the definition of each set (for \(D\):
\(J^k(J(n))=J^{k+1}(n)\)). Forward closure of \(R\): if \(J^k(n)=1\)
then \(J^{k-1}(J(n))=1\) for \(k\ge 1\), and \(J(1)=1\). Forward
closure of \(D\): given \(B\), pick \(k\) with \(J^k(n)>\max(B,n)\);
then \(k\ge 1\) and \(J^{k-1}(J(n))>B\). Trichotomy: a bounded orbit
repeats, a repeat is a cycle, a cycle through \(1\) is the fate
\(R\). Exclusion: an orbit that reaches \(1\) or enters a cycle is
bounded; an orbit that reaches \(1\) and passes through a cycle state
\(m\ge 2\) of period \(L\) would force \(m=J^{qL}(m)=1\). Lean:
`reachesOne_backwardClosed`, `not_reachesOne_backwardClosed`,
`ancestor_backwardClosed`, `escapes_backwardClosed`,
`reachesOne_floorPower`, `escapes_floorPower`, `fate_trichotomy`,
`reachesOne_not_escapes`, `cycle_basin_not_escapes`,
`reachesOne_not_cycle_basin`. \(\square\)

Throughout Sections 3--5, \(A\) is a nonempty backward-closed set.
Every statement applies to each fate class realized by at least one
start.

## 3. The two productions

**Lemma 3.1 (even block).** Let \(m\in A\). Every even \(n\) with
\(m^2\le n<(m+1)^2\) lies in \(A\). Writing \(E(m)\) for this set,
\(|E(m)|\ge m\) and
\[
\frac1m\Bigl(1-\frac2m\Bigr)\ \le\ \frac{m}{(m+1)^2}\ \le\ \sum_{n\in E(m)}\frac1n\ \le\ \frac{m+1}{m^2}.
\]

*Proof.* \(J(n)=\lfloor\sqrt n\rfloor=m\) exactly on that interval, so
\(n\in A\). The interval has \(2m+1\) integers, at least \(m\) and at
most \(m+1\) of them even, each between \(m^2\) and \((m+1)^2\). Lean:
`even_block_mem`, `even_block_card`. \(\square\)

**Lemma 3.2 (\(OE\) fiber).** Let \(m\in A\) and
\[
\Phi(m)=\{n\ \text{odd}:\ m^4\le n^3<(m+1)^4\}
=\{n\ \text{odd}:\ m^{4/3}\le n<(m+1)^{4/3}\}.
\]
If \(n\in\Phi(m)\) and \(\lfloor n^{3/2}\rfloor\) is even, then
\(J(J(n))=m\), hence \(n\in A\). Moreover
\(H_m:=|\Phi(m)|\in[\tfrac23m^{1/3}-1,\ \tfrac23(m+1)^{1/3}+1]\), and
the fibers of distinct \(m\) are disjoint.

*Proof.* \(J(n)=\lfloor\sqrt{n^3}\rfloor=:k\); if \(k\) is even then
\(J(k)=\lfloor\sqrt k\rfloor\), and
\(\lfloor\sqrt{\lfloor\sqrt N\rfloor}\rfloor=m\iff m^4\le N<(m+1)^4\):
this is the exact form of the transparent nesting
\(\lfloor\sqrt{\lfloor n^{3/2}\rfloor}\rfloor=\lfloor n^{3/4}\rfloor\).
The interval \([m^{4/3},(m+1)^{4/3})\) has length between
\(\tfrac43m^{1/3}\) and \(\tfrac43(m+1)^{1/3}\) by the mean value
theorem, and a half-open interval of length \(\ell\) contains between
\(\ell/2-1\) and \(\ell/2+1\) odd integers. Disjointness is the cell
identity. Lean: `sqrt_sqrt_eq_iff`, `oe_fiber_mem`,
`floorPower_oe_fiber`, `oe_fiber_disjoint`. \(\square\)

Write \(G_m=\#\{n\in\Phi(m):\lfloor n^{3/2}\rfloor\ \text{even}\}\).
The whole argument rests on lower bounds for \(G_m\): an elementary
bound on every fiber outside a thin exceptional set (Section 4.1),
and a classical average over an even block of \(m\)'s (Section 4.2).

![The two productions. (a) The even integers of $[m^2,(m+1)^2)$ all map to $m$. (b) The $OE$ fiber $\Phi(m)$ for $m=10^5$: the odd $n$ with $\lfloor n^{3/4}\rfloor=m$, coloured by the parity of $\lfloor n^{3/2}\rfloor$; those with even image (blue) have $J(J(n))=m$.](figures/paper_c_productions.png){ width=100% }

## 4. Parity on a fiber

### 4.1 The sweep lemma

On \(\Phi(m)\) the quantity \(x=n^{3/2}/2\) has \(\lfloor n^{3/2}\rfloor\)
even iff \(\{x\}<\tfrac12\). Consecutive odd \(n\) advance \(x\) by
\(\approx\tfrac32n^{1/2}\approx\tfrac32m^{2/3}\), and over the whole
fiber this step drifts by less than one unit of \(1/H_m\). So modulo
\(1\) the fiber is an arithmetic progression with a nearly constant
step \(\alpha\), of length \(H_m\). Such a progression cannot avoid a
half-circle unless its step is within \(O(1/H_m)\) of \(0\), or its
two-step is (\(\alpha\approx\tfrac12\) with the wrong phase).

**Lemma 4.1 (sweep).** Let \(x_1<x_2<\dots<x_H\) be real numbers with
\(x_{j+1}-x_j\in[a,b]\) for all \(j\), where \(0<a\le b\le\tfrac12\),
\(b\le\tfrac{21}{20}a\) and \((H-1)a\ge 12\). Then
\[
\#\{j:\{x_j\}<\tfrac12\}\ \ge\ \tfrac H7
\qquad\text{and}\qquad
\#\{j:\{x_j\}\ge\tfrac12\}\ \ge\ \tfrac H7 .
\]
The same holds with the cells \((k/2,(k+1)/2]\) in place of
\([k/2,(k+1)/2)\), i.e. with the representative in \((0,1]\) in place
of the fractional part.

*Proof.* Cut \(\mathbb R\) into cells \(C_k=[k/2,(k+1)/2)\),
\(k\in\mathbb Z\); even \(k\) are the *good* cells (\(\{x\}<\tfrac12\)),
odd \(k\) the *bad* cells. Call \(C_k\) *traversed* if \(x_1\le k/2\)
and \((k+1)/2\le x_H\).

(i) *A traversed cell contains at least \(g:=\lfloor 1/(2b)\rfloor\ge 1\)
and at most \(G:=\lfloor 1/(2a)\rfloor+1\) of the points.* Let \(j_0\)
be the least index with \(x_{j_0}\ge k/2\). Then \(x_{j_0}<k/2+b\)
(either \(j_0=1\) and \(x_1=k/2\), or \(x_{j_0-1}<k/2\)). Since every
step is at most \(b\), \(x_{j_0+i}<k/2+(i+1)b\le(k+1)/2\) for all
\(i\le 1/(2b)-1\), and these indices exist because \((k+1)/2\le x_H\).
That gives at least \(\lfloor 1/(2b)\rfloor\) points in \(C_k\). Since
every step is at least \(a\), the points in \(C_k\) are \(x_{j_0+i}\)
with \(k/2+ia\le x_{j_0+i}<(k+1)/2\), so \(i<1/(2a)\) and there are at
most \(\lfloor 1/(2a)\rfloor+1\) of them. The same count holds for any
cell as an upper bound.

(ii) *Counting cells.* The traversed cells are consecutive, and their
number \(T\) is at least \(2(x_H-x_1)-2\ge 2(H-1)a-2\ge 22\). Good and
bad traversed cells alternate, so their numbers \(T_g,T_b\) differ by
at most one and \(T_g,T_b\ge 10\). Every point outside the traversed
cells lies in the cell of \(x_1\) or the cell of \(x_H\).

(iii) *The ratio.* Hence \(\mathrm{Good}\ge gT_g\) and
\(H\le G(T_g+T_b+2)\le G(2T_g+3)\), so
\[
\frac{\mathrm{Good}}H\ \ge\ \frac gG\cdot\frac{T_g}{2T_g+3}\ \ge\ \frac gG\cdot\frac{10}{23}.
\]
Put \(X=1/(2a)\ge 1\), so \(G=\lfloor X\rfloor+1\) and, from
\(b\le\tfrac{21}{20}a\), \(g\ge\lfloor\tfrac{20}{21}X\rfloor\). If
\(X<2\): \(g\ge 1,G\le 2\). If \(2\le X<3\): \(g\ge 1,G=3\). If
\(3\le X<4\): \(g\ge 2,G=4\). If \(4\le X<5\): \(g\ge 3,G=5\). If
\(X\ge 5\): \(g/G\ge(\tfrac{20}{21}X-1)/(X+1)\ge 0.62\). In all cases
\(g/G\ge\tfrac13\), so \(\mathrm{Good}/H\ge\tfrac{10}{69}>\tfrac17\).
The bad count is symmetric. For left-open cells the same proof applies
verbatim (the first point in a cell \((c,c+\tfrac12]\) after a point
\(\le c\) is \(\le c+b\le c+\tfrac12\)). \(\square\)

Lean: `sweep_fract_lt_half`, `sweep_fract_ge_half` (closed cells) and
`sweep_rep_le_half`, `sweep_rep_gt_half` (left-open cells, with the
representative \(x-\lceil x\rceil+1\in(0,1]\)), in
`formal/Problems/Juggler/FateSweep.lean`. The formal count uses the
strictly interior cells (at least \((T-3)/2\) of one colour, ratio
\(11/25\)) in place of the traversed cells (ratio \(10/23\)), and
obtains the left-open case from the closed one by
\(x_j\mapsto -x_{H+1-j}\).

The product \(g/G\cdot 10/23\) cannot reach \(\tfrac13\). An
adversarial sequence with steps in \([a,b]\) can lock a \(3+1\)
split near \(a=\tfrac14\). The OE fiber is monotone.

**Lemma 4.1' (monotone pairing).** Keep the hypotheses of Lemma 4.1
and assume the consecutive differences are monotone (nondecreasing
or nonincreasing). Then
\[
\#\{j:\{x_j\}<\tfrac12\}\ \ge\ \tfrac H3-2
\qquad\text{and}\qquad
\#\{j:\{x_j\}\ge\tfrac12\}\ \ge\ \tfrac H3-2.
\]
The same holds with the cells \((k/2,(k+1)/2]\) in place of
\([k/2,(k+1)/2)\).

*Proof.* We prove the nondecreasing case for both half-cell
conventions. Reversing the order and reflecting,
\(z_j=-x_{H+1-j}\), then gives the nonincreasing case; it
interchanges the half-cell conventions and preserves the two
color counts up to relabeling. Assume the steps are nondecreasing. Cut \(\mathbb R\) into the cells \(C_k=[k/2,(k+1)/2)\)
of Lemma 4.1. Since every step is at most \(b\le\tfrac12\), the cells
of \(x_1,\dots,x_H\) are \(T\) consecutive integers, each visited;
write \(\rho_1,\dots,\rho_T\ge 1\) for their occupancies in order, so
\(\sum_i\rho_i=H\), and consecutive cells have opposite colours. Call
the cells \(2,\dots,T-1\) *interior*. Put \(X=1/(2a)\),
\(G=\lfloor X\rfloor+1\) and \(g=\lfloor 1/(2b)\rfloor\ge 1\). As in
Lemma 4.1(i), every cell has \(\rho_i\le G\) and every interior cell
has \(\rho_i\ge g\); and \((H-1)a\ge 12\) gives
\(H\ge 24X+1\ge 24G-23\).

(a) *A later cell is at most one fuller than an earlier interior
cell.* Let \(2\le i<j\le T\). The \(\rho_i+1\) steps from the last
point before the cell of index \(i\) to the first point after it span
more than \(\tfrac12\), so one of them, \(\gamma\), exceeds
\(1/(2(\rho_i+1))\). Every step inside the cell of index \(j\) comes
later, hence is at least \(\gamma\), and the \(\rho_j-1\) steps inside
that cell span less than \(\tfrac12\). So \((\rho_j-1)\gamma<\tfrac12\),
i.e. \(\rho_j\le\rho_i+1\). In particular, once an interior cell of
occupancy \(v\) has occurred, every later cell has occupancy at most
\(v+1\).

(b) *Pairs and surplus.* Pair the interior cells consecutively,
\((2,3),(4,5),\dots\); at most three cells are unpaired (the first,
the last, and possibly one interior cell), each holding at most \(G\)
points. Each pair has one cell of each colour, so each colour receives
at least \(\sum_{\rm pairs}\min(\rho,\rho')\), and
\[
\sum_{\rm pairs}\min(\rho,\rho')
\ \ge\ \tfrac13(H-3G)+S,\qquad
S:=\sum_{\rm pairs}\Bigl(\min(\rho,\rho')-\tfrac{\rho+\rho'}3\Bigr).
\]
It therefore suffices to show \(S\ge G-2\). Both entries of every
pair lie in \([g,G]\), so every pair has
\(\min/\mathrm{sum}\ge g/(g+G)=:r\), and a pair contributes at least
\((r-\tfrac13)(\rho+\rho')\) to \(S\).

(c) *\(G\ge 7\).* Then \(X\ge 6\) and \(g\ge\lfloor\tfrac{20}{21}X\rfloor\)
give \(7g\ge 5G\) (\(g\ge 5\) at \(G=7\), \(g\ge 6\) at \(G=8\), and
\(7g>\tfrac{20G-41}3\ge 5G\) for \(G\ge 9\)), so \(r\ge\tfrac5{12}\) and
\(S\ge\tfrac1{12}(H-3G)\ge\tfrac{21G-23}{12}\ge G-2\).

(d) *\(3\le G\le 6\) and \(g\ge 2\).* The possible \((G,g)\) are
\((3,2),(4,2),(4,3),(5,3),(5,4),(6,4),(6,5)\). Except for \((4,2)\),
\(r\ge\tfrac38\), so \(S\ge\tfrac1{24}(H-3G)\ge\tfrac{21G-23}{24}\ge G-2\)
because \(3G\le 25\). For \((G,g)=(4,2)\) the interior occupancies lie
in \(\{2,3,4\}\); by (a), after the first interior cell of occupancy
\(2\) every cell has occupancy at most \(3\). So the pairs with both
entries in \(\{3,4\}\) (ratio \(\ge\tfrac37\)) precede the pairs with
both entries in \(\{2,3\}\) (ratio \(\ge\tfrac25\)), and at most one
pair straddles, with ratio \(\ge\tfrac13\) and at most \(6\) points.
Hence \(S\ge\tfrac1{15}(H-3G-6)\ge\tfrac{24G-41}{15}>2=G-2\).

(e) *\(G=2\).* Interior occupancies lie in \(\{1,2\}\), every pair has
ratio \(\ge\tfrac13\), and \(S\ge 0=G-2\).

(f) *\(G=3\) and \(g=1\)*, i.e. \(2\le X<3\) and \(b>\tfrac14\); then
\(a\le\tfrac14\) and \(b\le\tfrac{21}{80}\), so \(3b<1\) and \(7b<2\).
Interior occupancies lie in \(\{1,2,3\}\), and by (a) every cell after
the first interior cell of occupancy \(1\) has occupancy at most
\(2\). The pairs are therefore: pairs with both entries in \(\{2,3\}\),
of ratio \(\ge\tfrac25\); at most one straddling pair \((\rho,1)\) with
\(\rho\in\{2,3\}\), which contributes at least \(-\tfrac13\) to \(S\);
and pairs with both entries in \(\{1,2\}\). In the last group,
\((1,1)\) does not occur: two adjacent interior cells with one point
each would have three consecutive steps spanning more than \(1>3b\).
Nor do two consecutive pairs with six points in all: four consecutive
interior cells with six points would have seven consecutive steps
spanning more than \(2>7b\). So among any two consecutive pairs of the
last group at least one is \((2,2)\), and the two together hold at
least \(7\) points of which the scarcer colour gets at least \(3\):
their contribution to \(S\) is at least \(3-\tfrac73=\tfrac23\), and
they hold at most \(8\) points, so the last group contributes at
least \(\tfrac1{12}N_2-\tfrac23\) to \(S\), where \(N_2\) is its
number of points (a leftover single pair contributes at least \(0\)).
With \(N_1\) the number of points in the first group,
\(N_1+N_2\ge H-3G-4=H-13\), and
\[
S\ \ge\ -\tfrac13+\tfrac1{15}N_1+\tfrac1{12}N_2-\tfrac23
\ \ge\ \tfrac1{15}(H-13)-1\ \ge\ 1=G-2,
\]
since \(H\ge 24X+1\ge 49\).

In all cases \(S\ge G-2\), so the scarcer colour has at least
\(\tfrac13(H-3G)+G-2=\tfrac H3-2\) points. For left-open cells the
same argument applies with the cells \((k/2,(k+1)/2]\), or apply the
closed case to \(-x_{H+1-j}\) as in Lemma 4.1. \(\square\)

Lean: `sweep_monotone_fract_lt_half`, `sweep_monotone_fract_ge_half`
(closed cells) and `sweep_monotone_rep_le_half`,
`sweep_monotone_rep_gt_half` (left-open cells), instances of
`Sweep.sweep_monotone_cell` and `sweep_monotone_ceil`, in
`formal/Problems/Juggler/FateSweepMonotone.lean`.

*Remark (erratum, 8 September 2026).* An earlier version of this
proof asserted that every pair satisfies
\(\min\ge(\rho+\rho')/3\), on the grounds that the step scale
\(1/(2\delta)\) changes by at most \(X/21\) "spread over the cells" and
that with \(X<2.1\) the pairs are \((1,1)\), \((1,2)\) or \((2,2)\).
Monotone steps need not change gradually: with \(a=\tfrac{10}{41}\),
\(b=\tfrac{21}{82}\) the sequence \(-2a,-a,0,a,2a,2a+b,2a+2b,\dots\)
has nondecreasing steps in \([a,b]\), and its cells \(2\) and \(3\) —
an interior pair in the pairing of (b) — have occupancies \((3,1)\). That version also paired the two partial
end cells as if they were interior. The statement is unchanged; the
proof above replaces it, with (a) in place of the spreading claim, the
end cells left unpaired, and the surplus \(S\) paying for them.

**Lemma 4.2 (fiber parity).** For \(m\ge 10^6\) put
\(\alpha_m=\{\tfrac32m^{2/3}\}\) and call \(m\) *good* if
\[
\|\alpha_m\|\ \ge\ 22\,m^{-1/3}
\qquad\text{and}\qquad
\|\alpha_m-\tfrac12\|\ \ge\ 2\,m^{-1/3},
\]
where \(\|\cdot\|\) is the distance to the nearest integer. If \(m\)
is good then \(G_m\ge\tfrac13H_m-2\) and \(H_m-G_m\ge\tfrac13H_m-2\).

*Proof.* Let \(n_1<\dots<n_H\) be the odd integers of \(\Phi(m)\),
\(n_{j+1}=n_j+2\), and \(x_j=n_j^{3/2}/2\). Then
\(\lfloor n_j^{3/2}\rfloor\) is even iff \(\{x_j\}<\tfrac12\). The
steps are
\[
\delta_j=x_{j+1}-x_j=\int_{n_j}^{n_j+2}\tfrac34t^{1/2}\,dt
\in\bigl[\tfrac32n_j^{1/2},\ \tfrac32(n_j+2)^{1/2}\bigr]
\subseteq[A_m,B_m],
\]
with \(A_m=\tfrac32m^{2/3}\) and
\(B_m=\tfrac32\bigl((m+1)^{4/3}+2\bigr)^{1/2}\). Using
\(\sqrt u-\sqrt v\le(u-v)/(2\sqrt v)\) and
\((m+1)^{4/3}-m^{4/3}\le\tfrac43(m+1)^{1/3}\),
\[
\eta_m:=B_m-A_m\le\frac{(m+1)^{1/3}+\tfrac32}{m^{2/3}}
\le m^{-1/3}\Bigl(1+\frac1{3m}+\frac32m^{-1/3}\Bigr)\le 1.02\,m^{-1/3}.
\]
Also \(H_m-1\ge\tfrac23m^{1/3}-2\ge 0.646\,m^{1/3}\).

*Case 1: \(\alpha_m\le\tfrac12-2m^{-1/3}\).* Put \(N=\lfloor A_m\rfloor\)
and \(y_j=x_j-jN\); then \(\{y_j\}=\{x_j\}\) and the steps of \(y\) lie
in \([a,b]=[\alpha_m,\alpha_m+\eta_m]\subseteq[22m^{-1/3},\tfrac12]\).
Now \(b/a\le 1+1.02/22<\tfrac{21}{20}\) and
\((H-1)a\ge 0.646\cdot 22>12\). The steps of \(y\) are nondecreasing.
Lemma 4.1' applies.

*Case 2: \(\alpha_m\ge\tfrac12+2m^{-1/3}\).* Put \(z_j=j(N+1)-x_j\),
increasing with steps
\((N+1)-\delta_j\in[1-\alpha_m-\eta_m,\ 1-\alpha_m]\subseteq[20.98\,m^{-1/3},\ \tfrac12]\);
again \(b/a\le 1+1.02/20.98<\tfrac{21}{20}\) and
\((H-1)a\ge 0.646\cdot 20.98>12\). Write \(\langle z\rangle\in(0,1]\)
for the representative of \(z\) modulo \(1\) in \((0,1]\). Then
\(\langle z_j\rangle=1-\{x_j\}\) for every \(j\), so
\(\{x_j\}<\tfrac12\iff\langle z_j\rangle\in(\tfrac12,1]\). The steps of
\(z\) are monotone. Lemma 4.1' in its left-open form gives both counts.

The middle range \(|\alpha_m-\tfrac12|<2m^{-1/3}\) and the range
\(\|\alpha_m\|<22m^{-1/3}\) are excluded by goodness. \(\square\)

Lean: `FiberParity.fiber_parity_good` in
`formal/Problems/Juggler/FateFiberParity.lean`, with goodness unpacked
as \(22m^{-1/3}\le\alpha_m\le 1-22m^{-1/3}\) and
\(\alpha_m\le\tfrac12-2m^{-1/3}\) or \(\alpha_m\ge\tfrac12+2m^{-1/3}\)
(`FiberParity.Good`). The step of \(x(n)=n\sqrt n/2\) over two units is
\((u^2+uv+v^2)/(u+v)\) with \(u=\sqrt{n+2}\), \(v=\sqrt n\)
(`xval_step`), which lies in \([\tfrac32v,\tfrac32u]\) by
\((2u+v)(u-v)\ge 0\) and \((u+2v)(u-v)\ge 0\) and is nondecreasing
because the upper bound at \(n\) is the lower bound at \(n+2\); no
integral is needed. The upper step is taken at \(n_{j+1}\in\Phi(m)\),
so \(B_m=\tfrac32(m+1)^{2/3}\) and \(\eta_m\le m^{-1/3}\) by Bernoulli
on \((1+1/m)^{2/3}\); the fiber has at least \(\tfrac23m^{1/3}-1\)
members by Bernoulli on \((1+1/m)^{4/3}\). Both cases go through
`Sweep.sweep_monotone_cell` and `sweep_monotone_ceil` of
`FateSweepMonotone`, with \(\lceil 2z_j\rceil\equiv\lfloor 2x_j\rfloor\)
(mod \(2\)) in Case 2.

**Lemma 4.3 (bad fibers are thin).** For \(u\ge 10^6\),
\[
\#\{m\in(u,2u]:\ m\ \text{bad}\}\le 63\,u^{2/3},
\qquad
\sum_{\substack{m>U\\ m\ \text{bad}}}\frac1m\le 306\,U^{-1/3}\quad(U\ge 10^6).
\]

*Proof.* \(\varphi(m)=\tfrac32m^{2/3}\) increases with
\(\varphi(m+1)-\varphi(m)\in[(m+1)^{-1/3},m^{-1/3}]\subseteq[(3u)^{-1/3},u^{-1/3}]\)
on \((u,2u]\). Badness means \(\{\varphi(m)\}\) lies in one of two arcs
of the circle, of total length at most \(48\,u^{-1/3}\). As \(m\) runs
over \((u,2u]\), \(\varphi\) increases by
\(\tfrac32u^{2/3}(2^{2/3}-1)<0.882\,u^{2/3}\), so it passes each arc at
most \(0.882u^{2/3}+2\) times, and each pass through an arc of length
\(w\) takes at most \(w(3u)^{1/3}+1\) values of \(m\). Hence the count
is at most \((0.882u^{2/3}+2)(48\cdot 3^{1/3}+2)\le 63\,u^{2/3}\) for
\(u\ge 10^6\). Summing \(63\,(2^iU)^{-1/3}\) over \(i\ge 0\) gives
\(63U^{-1/3}/(1-2^{-1/3})\le 306\,U^{-1/3}\). \(\square\)

Lean: `FiberParity.bad_count_le` and `FiberParity.bad_logMass_le` in
`formal/Problems/Juggler/FateThinFibers.lean`, with badness the
negation of `FiberParity.Good` and the log-mass bound stated for every
finite range \((U,N]\). The count is the paper's: the increments of
\(\varphi\) lie in \([(m+1)^{-1/3},m^{-1/3}]\) by Bernoulli both ways;
a bad \(m>u\) has \(\{\varphi(m)+22u^{-1/3}\}<44u^{-1/3}\) or
\(\{\varphi(m)\}\in[\tfrac12-2u^{-1/3},\tfrac12+2u^{-1/3})\), so the
wrap-around arc is a single arc after the shift; on an arc of width
\(w\) a sequence increasing by at least \(d\) per step holds at most
\(w/d+1\) points per integer window (`arc_count_le`), and at most
\(\varphi(2u)-\varphi(u)+2\) windows are met. The formal count uses
\(d=(2u)^{-1/3}\), sharper than the \((3u)^{-1/3}\) above, so
\(w/d\) is \(44\cdot 2^{1/3}\) and \(4\cdot 2^{1/3}\) and the total
\((0.882u^{2/3}+2)(48\cdot 2^{1/3}+2)\) clears \(63u^{2/3}\) with room.
The dyadic sum uses \(2^{-1/3}\le 0.794\), whence
\(63/(1-2^{-1/3})\le 306\).

### 4.2 The block average

The adversarial sweep \(G_m\ge H_m/7\) is not the fiber bound: Lemma
4.1' gives the monotone floor \(H_m/3-2\). In the numerical
experiments of Section 11 the mean of \(G_m/H_m\) is
\(\tfrac12\) and the minimum on good fibers is near \(\tfrac13\). When
the members of \(A\) come in even blocks — as the \(E\)-produced part
of \(A\) always does — the fibers can be averaged over the block, and
the average is asymptotically \(\tfrac12\) by a classical exponential-sum
estimate.

**Proposition 4.4 (block average).** For \(m'\ge2\), put
\(I(m')=[m'^{8/3},(m'+1)^{8/3})\) and
\[
U(m')=\{n\text{ odd in }I(m'):
 \lfloor n^{3/4}\rfloor\text{ even},\quad
 \lfloor n^{3/2}\rfloor\text{ even}\}.
\]
This is the disjoint union of the even-image parts of \(\Phi(m)\)
over \(m\in E(m')\). There is an absolute constant \(C_B\) such that
\[
\left||U(m')|-\tfrac14\#\{n\text{ odd in }I(m')\}\right|
 \le C_B m'^{11/9}\log(m'+1).
\tag{4.1}
\]
In particular
\[
|U(m')|=\tfrac13m'^{5/3}(1+O(m'^{-4/9}\log(m'+1))).
\]
No numerical value of \(C_B\) is asserted.

*Proof.* Write \(M=\#\{n\text{ odd in }I(m')\}\asymp m'^{5/3}\)
and \(\psi(z)=(-1)^{\lfloor z\rfloor}\). Expanding the two
indicators gives four sums: \(M\), the sums of \(\psi(n^{3/4})\)
and \(\psi(n^{3/2})\), and their product.

The slow sum is \(O(m')\): pair consecutive fibers of
\(\lfloor n^{3/4}\rfloor\), whose odd-point counts differ by at
most \(3\), and bound the remaining end fiber by \(O(m'^{2/3})\).

We use the interval form of Vaaler's approximation [10]. For
\(J\ge1\), the parity wave has a trigonometric approximation
\(V_J(z/2)\), with zero constant term and coefficients \(O(1/|q|)\),
and a nonnegative error majorant \(\Delta_J(z/2)\). Its degree is
\(J\), every coefficient is \(O(1/J)\), and
\(\|\Delta_J\|_\infty=O(1)\). All constants in this paragraph are
absolute; the interval endpoints are included in the majorant.

Take \(J=\max(1,\lfloor m'^{4/9}\rfloor)\) and reindex odd
integers as \(n=2r+1\). For \(q\ne0\), the fast phase
\(f(r)=q(2r+1)^{3/2}/2\) has
\(|f''|\asymp |q|m'^{-4/3}\), with constant sign. The
second-derivative test [13, Theorem 2.2] gives, uniformly on initial
subintervals,
\[
\left|\sum_r e(f(r))\right|
 \ll m'|q|^{1/2}+m'^{2/3}|q|^{-1/2},\qquad e(z)=e^{2\pi iz}.
\]
The coefficient sum and the majorant sum are therefore bounded by
\[
\ll m'J^{1/2}+m'^{2/3}+M/J\ll m'^{11/9}.
\]
For the product, expand both waves. A mixed phase is
\(f=(q_1n^{3/4}+q_2n^{3/2})/2\), with \(q_2\ne0\), and
\[
f''(r)=\tfrac32q_2n^{-1/2}
 \left(1-\frac{q_1}{4q_2}n^{-3/4}\right).
\]
For \(|q_1|\le J\), the correction is
\(O(m'^{-14/9})\); for all sufficiently large \(m'\) the same
second-derivative estimate applies uniformly. Summing the slow
coefficients adds at most \(O(\log(J+1))\).

The slow majorant has constant contribution \(O(M/J)\).
Its nonzero modes have monotone derivative
\(\tfrac34 q_1 n^{-1/4}\), of magnitude
\(\asymp |q_1|m'^{-2/3}\) and at most \(1/2\) for sufficiently
large \(m'\). Kusmin--Landau [13, Theorem 2.1] bounds a mode by
\(O(m'^{2/3}/|q_1|)\), so the majorant contributes
\(O(M/J+m'^{2/3}\log(J+1)/J)\).
Since \(|\psi|=1\), \(|V_J|\le1+\Delta_J=O(1)\), and the
majorants are nonnegative, the product-approximation error is
bounded by a constant times the sum of the two majorants. These
estimates prove (4.1) for sufficiently large \(m'\); increasing
the unspecified absolute constant covers the finitely many smaller
integers \(m'\ge2\). \(\square\)

Lean: the exact layer and the conditional deduction, in
`formal/Problems/Juggler/FateBlockAverage.lean`. The block is
`BlockAverage.oddBlock`, exactly the odd \(n\) with
\(m'^2\le\lfloor n^{3/4}\rfloor<(m'+1)^2\) by the landing window of
Appendix D.1 (`mem_oddBlock`); `U_card_eq` is the sentence that
\(U(m')\) is the disjoint union of the even-image parts of the
\(\Phi(m)\) over the even \(m\) of the block, with
`oddBlock_card_eq` the same for the whole block; and `four_card_U` is
the expansion
\(4|U(m')|=M+S_1+S_2+S_{12}\) that the proof starts from. The slow
sum needs no analysis: it is the alternating sum
\(\sum_m(-1)^m|\Phi(m)|\) over the block (`slowSum_eq_fibers`),
consecutive fibers differ by at most two members
(`oeFiber_card_succ_diff`, from
\(\tfrac23m^{1/3}-1\le|\Phi(m)|\le\tfrac23(m+1)^{1/3}+1\)), and
the block pairs off, so \(|S_1|\le 2m'+\tfrac23(m'+1)^{2/3}+1\)
(`slowSum_abs_le`). The count \(M\) is pinned two-sidedly by the same
fiber bounds (`oddBlock_card_le`, `oddBlock_card_ge`), whence
\(|M/4-m'^{5/3}/3|\le m'+1\) (`oddBlock_quarter_close`). Given bounds
on the fast sum and the product sum only, (4.1) is
`block_average_two_bounds`, in the paper's shape
`block_average_bound_two` with \(C_B=C/2+2\), and the asymptotic form
is `block_average_asymptotic` with the explicit error
\(B/2+2(m'+1)\). Those two bounds are hypotheses there, not theorems:
Vaaler's approximation, the second-derivative test and Kusmin--Landau
are not formalized, so this proposition stays a human proof and the
table says so.

*Revision note.* The earlier value \(C_0=250\) depended on an
unverified explicit majorant and small-parameter inequalities that
do not hold throughout their printed range. The asymptotic form above
is all that the subsequent recursions use.

### 4.3 The share is a quadratic sweep

Sections 4.1 and 4.2 bound \(G_m\) from below, by a sweep on each good
fiber and by an exponential sum across an even block. Neither says what
\(G_m/H_m\) *is*. It has a closed form, and the form explains both the
floor of Lemma 4.2 and the extreme fibers that the goodness condition
excludes. Nothing in Sections 5--10 depends on this subsection; it is
here because it identifies which of the two tools is doing the work,
and because it names the hypothesis behind the gap between them.

Throughout, \(n_1=\min\Phi(m)\), \(n_j=n_1+2(j-1)\), and
\(x_j=n_j^{3/2}/2\), so that \(\lfloor n_j^{3/2}\rfloor\) is even iff
\(\{x_j\}<\tfrac12\). Write
\[
\theta_m=\{x_1\},\qquad
\beta_m=\alpha_m\,(H_m-1),
\]
with \(\alpha_m=\{\tfrac32m^{2/3}\}\) as in Lemma 4.2, taken in
\((-\tfrac12,\tfrac12]\), and set
\[
S(\beta,\theta)
=\bigl|\{s\in[0,1]:\ \{\theta+\beta s+\tfrac13s^2\}<\tfrac12\}\bigr|.
\]

**Lemma 4.5 (share law).** As \(m\to\infty\),
\[
G_m/H_m=S(\beta_m,\theta_m)
 +O\left(H_m^{-1/2}+\frac{1+|\beta_m|}{H_m}\right).
\]
The estimate is useful when \(|\beta_m|=o(H_m)\); it is not a
uniform equidistribution assertion for all fibers.

*Proof.* Expand \(x_j\) about \(n_1\). With \(u=2(j-1)/n_1\),
\[
x_j=\tfrac12n_1^{3/2}(1+u)^{3/2}
=x_1+\tfrac32n_1^{1/2}(j-1)+\tfrac34n_1^{-1/2}(j-1)^2+E_j,
\qquad |E_j|\le\tfrac14(j-1)^3n_1^{-3/2}.
\]
On the fiber \(j-1\le H_m-1\ll m^{1/3}\) and \(n_1\ge m^{4/3}\), so
\(|E_j|\ll m^{-1}\), below \(1/H_m\). Put \(s=(j-1)/(H_m-1)\in[0,1]\).
The linear coefficient is \(A=\tfrac32n_1^{1/2}\), and since
\(n_1=m^{4/3}+O(1)\) we have \(A=\tfrac32m^{2/3}+O(m^{-2/3})\), so
\(A\equiv\alpha_m+O(m^{-2/3})\pmod1\) and the accumulated difference over the
fiber is \(O(m^{-1/3})=O(1/H_m)\). Hence
\(A(j-1)\equiv\beta_ms\pmod 1\) up to \(O(1/H_m)\). The quadratic
coefficient gives
\(\tfrac34n_1^{-1/2}(H_m-1)^2=\tfrac13+O(1/H_m)\) by Lemma 3.2, so
\[
x_j\ \equiv\ \theta_m+\beta_ms+\tfrac13s^2\pmod 1,
\]
uniformly to \(O(1/H_m)\). Put \(\epsilon=O(1/H_m)\). Replacing the exact phase by
the displayed quadratic can change an indicator only within
\(\epsilon\) of an integer or half-integer. If \(|\beta_m|\le2\),
there are \(O(1)\) such levels and their inverse images have total
length \(O(\sqrt\epsilon)\), since the quadratic has second
derivative \(2/3\). If \(|\beta_m|>2\), its derivative has magnitude
at least \(|\beta_m|-2/3\), and the total inverse-image length is
\(O(\epsilon)\). Each of these sets, and each half-cell inverse
image, has \(O(1+|\beta_m|)\) interval components. Sampling on the
uniform grid costs \(O((1+|\beta_m|)/H_m)\). This proves the stated
bound, including tangencies to the cell boundaries. \(\square\)

**Corollary 4.6.** For every \(\beta\):

1. \(\int_0^1S(\beta,\theta)\,d\theta=\tfrac12\).
2. \(S(\beta,\theta)\in\{0,1\}\) for some \(\theta\) if and only if
   \(\beta\in[-\tfrac56,\tfrac16]\).
3. \(\displaystyle\int\bigl|\{\theta:S(\beta,\theta)=0\}\bigr|\,d\beta=\tfrac{25}{108}\),
   and the same for \(S=1\).

*Proof.* (1) By Fubini the integral is
\(\int_0^1\!\int_0^1\mathbf 1[\{\theta+\varphi(s)\}<\tfrac12]\,d\theta\,ds\),
and the inner integral is \(\tfrac12\) for every \(s\), whatever
\(\varphi\).

(2) Let \(\varphi(s)=\beta s+\tfrac13s^2\), so
\(\varphi'(s)=\beta+\tfrac23s\). If \(\beta\ge0\) then \(\varphi\) is
increasing with range \(\beta+\tfrac13\); if \(\beta\le-\tfrac23\) it is
decreasing with range \(-\beta-\tfrac13\); and if
\(-\tfrac23<\beta<0\) it dips to \(\varphi(-\tfrac32\beta)=-\tfrac34\beta^2\)
and returns to \(\beta+\tfrac13\), so its range is
\(\max(0,\beta+\tfrac13)+\tfrac34\beta^2\). An extreme value of \(S\)
needs the image of \([0,1]\) to miss a half-circle, hence range
\(\le\tfrac12\). That is \(\beta\le\tfrac16\) in the first case,
\(\beta\ge-\tfrac56\) in the second, and no constraint in the third,
since the range there is at most \(\tfrac13\).

(3) The \(\theta\)-measure is \(\max(0,\tfrac12-\text{range})\).
Integrating the four pieces of (2),
\[
\int_0^{1/6}\!\!\bigl(\tfrac16-\beta\bigr)
+\int_{-1/3}^0\!\!\bigl(\tfrac16-\beta-\tfrac34\beta^2\bigr)
+\int_{-2/3}^{-1/3}\!\!\bigl(\tfrac12-\tfrac34\beta^2\bigr)
+\int_{-5/6}^{-2/3}\!\!\bigl(\tfrac56+\beta\bigr)
=\tfrac1{72}+\tfrac{11}{108}+\tfrac{11}{108}+\tfrac1{72}
=\tfrac{25}{108}.
\]
The statement for \(S=1\) is the reflection \(\theta\mapsto\theta+\tfrac12\).
\(\square\)

Lean: the exact layer, in `formal/Problems/Juggler/FateShareLaw.lean`.
The expansion of \(x_j\) about \(n_1\) with the remainder
\(|E_j|\le\tfrac14(j-1)^3n_1^{-3/2}\) is `ShareLaw.xval_expansion`;
its Taylor step is, after \(v=\sqrt{1+u}\), the polynomial inequality
\(0\le1+\tfrac32(v^2-1)+\tfrac38(v^2-1)^2-v^3\le(v^2-1)^3/16\)
(`ShareLaw.taylor_three_halves`), so no derivative is taken, and on a
fiber the remainder is at most \(\tfrac2{27}(m+1)/m^2\)
(`ShareLaw.xval_expansion_fiber`). The range of
\(\varphi(s)=\beta s+\tfrac13s^2\) on \([0,1]\) in the three cases
of (2) is `ShareLaw.phiRange`, attained (`ShareLaw.exists_phi_sub_eq`)
and never exceeded (`ShareLaw.phi_sub_le`), and it is at most
\(\tfrac12\) exactly for \(\beta\in[-\tfrac56,\tfrac16]\)
(`ShareLaw.phiRange_le_half_iff`). The integral of (3),
\(\int\max(0,\tfrac12-\text{range})\,d\beta=\tfrac{25}{108}\) as
\(\tfrac1{72}+\tfrac{11}{108}+\tfrac{11}{108}+\tfrac1{72}\), is
`ShareLaw.integral_extremeMeasure`, with the integrand vanishing outside
\([-\tfrac56,\tfrac16]\) (`ShareLaw.extremeMeasure_eq_zero`). Not
formalized: the reduction of \(x_j\) modulo \(1\) to
\(\theta_m+\beta_ms+\tfrac13s^2\) with its \(O(1/H_m)\) error, the
inverse-image and grid-sampling estimates that make Lemma 4.5 from it,
the Fubini argument of (1), and the identification of the
\(\theta\)-measure with \(\max(0,\tfrac12-\text{range})\) in (2)
and (3).

Part (1) is the reason no aggregate count in this paper sees the
extreme fibers: they are compensated at every drift separately, which
is what Proposition 4.4 recovers by a different route. Part (2) says the
extremes occupy a window of one drift unit, that is
\(\alpha_m\in[-\tfrac54,\tfrac14]m^{-1/3}\) by \(H_m\sim\tfrac23m^{1/3}\).

At the centre of that window the law degenerates to an identity.

**Lemma 4.7 (cube fibers).** Let \(k\ge2\) and \(m=k^3\). Every
\(n\in\Phi(m)\) has \(n=k^4+t\) with \(3t\le4k\), and then
\(\lfloor n^{3/2}\rfloor=k^6+\tfrac32k^2t\) exactly. Consequently the
fiber of an even cube is full, \(G_m=H_m\), and along the fiber of an
odd cube the images alternate in parity, so \(|2G_m-H_m|\le1\).

*Proof.* If \(3t\ge4k+1\) then
\((3k^4+4k+1)^3\le(3k^4+3t)^3=27(k^4+t)^3\), and
\((3k^4+4k+1)^3\ge27(k^3+1)^4\), so \(n^3\ge(k^3+1)^4\) and \(n\notin\Phi(m)\).
Given \(3t\le4k\), the claimed value \(q=k^6+\tfrac32k^2t\) satisfies
\(n^3-q^2=\tfrac34k^4t^2+t^3\ge0\) and
\((q+1)^2-n^3=2k^6+3k^2t+1-\tfrac34k^4t^2-t^3>0\), so \(q=\lfloor n^{3/2}\rfloor\).
For even \(k\) the value \(k^6+\tfrac32k^2t\) is even for every \(t\); for
odd \(k\) the fiber's \(t\) are even and the value has the parity of
\(1+t/2\). Lean: `cube_fiber_range`, `cube_fiber_sqrt_even`,
`cube_fiber_sqrt_odd`, `even_cube_fiber_full`,
`odd_cube_fiber_alternating` in
`formal/Problems/Juggler/CubeFiber.lean`. \(\square\)

**Remark 4.8 (what the window is, arithmetically).** \(\alpha_m=0\)
exactly means \(\tfrac32m^{2/3}\in\mathbb Z\), that is \(27m^2=8k^3\),
whose integer solutions are \(m=(2e)^3\) and \(k=6e^2\). So the centre of
the extreme window is the even cubes of Lemma 4.7, and the window
itself is the near-solution set of that equation; the crossings are
spaced \(\asymp m^{1/3}\) apart, giving \(\sim\tfrac32M^{2/3}\) of them
below \(M\). Two consequences worth recording. The set is asymmetric
about \(0\), which the symmetric goodness condition of Lemma 4.2 cannot
express: that condition discards \(\|\alpha_m\|<22m^{-1/3}\), of width
\(44m^{-1/3}\), against the \(\tfrac32m^{-1/3}\) the extremes actually
occupy. Nothing here depends on the difference, since Lemma 4.3 already
makes the discarded mass \(o(1)\); the point is that the goodness
threshold is a convenience, not a boundary of the phenomenon. And the
two sides of the window are not symmetric in strength either: full
fibers contain the infinite family of Lemma 4.7, proved, whereas an
empty fiber requires a near-miss together with a phase condition, and
whether there are infinitely many is open.

**Remark 4.9 (averaging the rest term).** Item 3 of Section 5.1
has coefficient \(2/9\); a weighted mean even-image share of
\(1/2+o(1)\) on that source set would give \(1/3\). Such a
weighted mean is a sufficient additional hypothesis. Conditional
equidistribution of the landing phases could help establish it if
the approximation errors and the weights were also controlled, but
equidistribution is not necessary for one mean identity. Neither
Corollary 4.6(1), which averages an independent model phase, nor a
pointwise bound on each fiber establishes the required average on an
arbitrary backward-closed set. The goodness condition already
removes its exceptional fibers at total logarithmic cost \(o(1)\).

## 5. The recursion and the contagion theorem

### 5.1 Three sources of members of \(A\) in \((\sqrt x,x]\)

Let \(x\ge 2\) and \(t=\log x\). Three families of members of
\(A\cap(\sqrt x,x]\) are pairwise disjoint.

1. **\(E\)-images.** For \(m\in A\cap(x^{1/4},\sqrt x-1]\),
   \(E(m)\subseteq(\sqrt x,x]\) (as \(m^2>\sqrt x\) and
   \((m+1)^2\le x\)). Distinct \(m\) give disjoint blocks. By
   Lemma 3.1 the log-mass is at least
   \(\sum_m\frac1m(1-\frac2m)\ge(1-2x^{-1/4})\,\ell_A(x^{1/4},\sqrt x-1]\),
   and \(\ell_A(x^{1/4},\sqrt x-1]\ge g_A(t/2)-2x^{-1/2}\) (at most one
   integer lies in \((\sqrt x-1,\sqrt x]\)).

2. **\(OE\)-images of \(E\)-blocks.** For
   \(m'\in A\cap(x^{3/16},x^{3/8}-1]\), \(U(m')\subseteq A\cap(\sqrt x,x]\)
   (Lemma 3.2 applied to the even \(m\in E(m')\subseteq A\);
   \(I(m')\subseteq(\sqrt x,x]\) as \(m'^{8/3}>\sqrt x\) and
   \((m'+1)^{8/3}\le x\)). Distinct \(m'\) give disjoint \(I(m')\). Each
   \(n\in U(m')\) has \(1/n>(m'+1)^{-8/3}\), so by Proposition 4.4 the
   log-mass of \(U(m')\) is at least
   \(\tfrac13m'^{5/3}(1-\varepsilon_B(m'))(m'+1)^{-8/3}\ge\frac1{3m'}\bigl(1-\varepsilon_B(m')-\tfrac8{3m'}\bigr)\),
   and summing,
   \(\ge\tfrac13(1-\varepsilon'(x))\bigl(g_A(3t/8)-2x^{-3/8}\bigr)\) with
   \(\varepsilon_B(m')=O(m'^{-4/9}\log(m'+1))\ge0\) chosen to
   bound the error in Proposition 4.4 and
   \(\varepsilon'(x)=\sup_{m'>x^{3/16}}(\varepsilon_B(m')+\tfrac8{3m'})\to0\).

3. **\(OE\)-images of the rest.** Let
   \(A^{E}_x=\bigcup_{m''\in A}E(m'')\cap(x^{3/8},x^{3/4}]\) be the
   \(E\)-produced part of \(A\cap(x^{3/8},x^{3/4}]\) and
   \(A^{\rm rest}_x\) its complement in \(A\cap(x^{3/8},x^{3/4}]\). The
   blocks meeting \((x^{3/8},x^{3/4}]\) come from
   \(m''\in[x^{3/16}-1,x^{3/8}]\), so
   \(\ell(A^E_x)\le\sum_{m''}\frac{m''+1}{m''^2}\le(1+2x^{-3/16})\bigl(g_A(3t/8)+2x^{-3/16}\bigr)\)
   and
   \(\ell(A^{\rm rest}_x)\ge g_A(3t/4)-(1+2x^{-3/16})\bigl(g_A(3t/8)+2x^{-3/16}\bigr)\).
   For \(m\in A^{\rm rest}_x\) with \(m\le x^{3/4}-1\) (this drops at
   most one element, of log-mass \(\le 2x^{-3/4}\)),
   \(\Phi(m)\subseteq(\sqrt x,x]\); the fibers are disjoint from each
   other and from those of item 2 (different \(m\)), and for good
   \(m\ge 10^6\) Lemmas 4.2 and 3.2 give log-mass at least
   \(\bigl(\tfrac13H_m-2\bigr)(m+1)^{-4/3}\ge\frac2{9m}\bigl(1-O(m^{-1/3})\bigr)\).
   Bad \(m>x^{3/8}\) carry log-mass at most \(306x^{-1/8}\)
   (Lemma 4.3). Hence item 3 contributes at least
   \(\tfrac2{9}(1-O(x^{-1/8}))\bigl[\ell(A^{\rm rest}_x)-306x^{-1/8}-2x^{-3/4}\bigr]_+\).

The images in item 1 are even, those in items 2--3 odd, so the three
families are disjoint, and all lie in \((\sqrt x,x]\).

### 5.2 The functional inequalities

Adding items 1 and 2:
\[
g_A(t)\ \ge\ (1-\varepsilon_1(t))\,g_A(t/2)+\tfrac13(1-\varepsilon_2(t))\,g_A(3t/8)-\varepsilon_3(t),
\tag{5.1}
\]
with \(\varepsilon_1=2e^{-t/4}\), \(\varepsilon_2=\varepsilon'(e^t)\),
\(\varepsilon_3=2e^{-t/2}+e^{-3t/8}\), all tending to \(0\). Adding
item 3 as well, and noting that the coefficient of the *actual* value
\(g_A(3t/8)\) is
\(\tfrac13(1-\varepsilon_2)-\tfrac2{9}(1+2e^{-3t/16})\to\tfrac19>0\):
\[
g_A(t)\ \ge\ (1-\varepsilon_1)\,g_A(t/2)+\bigl(\tfrac19-\varepsilon_4\bigr)g_A(3t/8)+\bigl(\tfrac29-\varepsilon_5\bigr)g_A(3t/4)-\varepsilon_6(t),
\tag{5.2}
\]
with \(\varepsilon_4,\varepsilon_5,\varepsilon_6\to 0\) (for \(t\) so
large that \(x^{3/8}\ge 10^6\); the bracket \([\cdot]_+\) may be
dropped because the right side of (5.2) is a lower bound for it).
Every coefficient of a \(g_A\)-value on the right is nonnegative for
large \(t\), so lower bounds for \(g_A\) at \(t/2\), \(3t/8\), \(3t/4\)
transfer.

### 5.3 The recursion lemma

The passage from a functional inequality with vanishing errors to a
power lower bound is a standalone statement.

**Lemma 5.1 (recursion lemma).** Let \(e_1,\dots,e_r\in(0,1)\),
\(c_1,\dots,c_r\ge 0\), and \(\lambda\in(0,1)\) with
\[
\zeta:=\sum_{i=1}^rc_ie_i^{\lambda}-1>0 .
\]
Put \(e_{\min}=\min_ie_i\), \(e_{\max}=\max_ie_i\). Let
\(g:(0,\infty)\to[0,\infty)\) satisfy, for all \(t\ge t_1\),
\[
g(t)\ \ge\ \sum_{i=1}^r\bigl(c_i-\eta_i(t)\bigr)\,g(e_it)-\eta_0(t),
\]
where \(0\le\eta_i(t)\le c_i\) for \(i\ge 1\), \(\eta_0(t)\ge 0\), and
\(\sum_{i\ge1}\eta_i(t)e_i^\lambda\le\zeta/3\) and \(\eta_0(t)\le\tfrac{2\zeta}3c_0\)
for all \(t\ge t_1\), for some \(c_0>0\) with \(g(t)\ge c_0\) on
\([e_{\min}t_1,\,t_1]\). Then
\[
g(t)\ \ge\ K\,t^{\lambda}\quad\text{for all }t\ge e_{\min}t_1,\qquad K=c_0t_1^{-\lambda}.
\]

*Proof.* On \([e_{\min}t_1,t_1]\), \(Kt^\lambda\le Kt_1^\lambda=c_0\le g(t)\).
Suppose \(g(t)\ge Kt^\lambda\) holds on \([e_{\min}t_1,T]\) for some
\(T\ge t_1\), and let \(t\in(T,T/e_{\max}]\). Then \(e_it\le e_{\max}t\le T\)
and \(e_it\ge e_{\min}t>e_{\min}t_1\), so each \(e_it\) lies in the
interval where the bound is known, and \(t\ge t_1\), so
\[
\begin{aligned}
g(t)&\ge\sum_i(c_i-\eta_i(t))K(e_it)^\lambda-\eta_0(t)\\
&=Kt^\lambda\left[\sum_i c_i e_i^\lambda-\sum_i\eta_i(t)e_i^\lambda\right]-\eta_0(t)\\
&\ge Kt^\lambda\left(1+\frac{2\zeta}3\right)-\frac{2\zeta}3c_0
\ge Kt^\lambda.
\end{aligned}
\]
using \(c_0=Kt_1^\lambda\le Kt^\lambda\). Hence the bound holds on
\([e_{\min}t_1,T/e_{\max}]\); induction on \(N\) covers
\([e_{\min}t_1,t_1e_{\max}^{-N}]\) for every \(N\), i.e. all
\(t\ge e_{\min}t_1\). \(\square\)

Lean: `recursion_lemma` in `formal/Problems/Juggler/FateRecursion.lean`,
with \(e_{\min}\le e_i\le e_{\max}\) as bounds rather than extrema and
\(\lambda>0\) in place of \(\lambda\in(0,1)\); the hypotheses
\(g\ge 0\) and \(\lambda<1\) are not used.

### 5.4 The seed

**Lemma 5.2 (seed).** Every nonempty backward-closed \(A\) contains an
integer \(m\ge 3\), and for any such \(m\),
\[
g_A(t)\ \ge\ c_A:=\Bigl(1-\frac2{m^4}\Bigr)\Bigl(\frac{0.375}{m+1}-\frac1{(m+1)^2-1}\Bigr)>0
\qquad\text{for all}\ t\ge 4\log(m+1).
\]

*Proof.* If \(A\ni a\le 2\) then \(E(a)\subseteq A\) contains \(2\) or
\(4\), and \(E(2)\ni 4\), so \(A\ni 4\). Fix \(m\ge 3\) in \(A\) and let
\(S_1=E(m)\), \(S_{k+1}=\bigcup_{m''\in S_k}E(m'')\). Then
\(S_k\subseteq A\cap[m^{2^k},(m+1)^{2^k})\) and, by Lemma 3.1,
\(\ell(S_{k+1})\ge(1-2m^{-2^k})\ell(S_k)\), so
\(\ell(S_k)\ge\ell(S_1)\prod_{j\ge 1}(1-2m^{-2^j})\ge 0.75\,\ell(S_1)\ge\frac{0.375}{m+1}\)
for \(m\ge 3\). Let \(y\ge(m+1)^4\) and choose \(k\ge 2\) with
\((m+1)^{2^k}\le y<(m+1)^{2^{k+1}}\). Then \(S_k\subseteq(y^{1/4},y]\)
(as \(y<m^{2^{k+2}}\)). The members of \(S_k\) above \(\sqrt y\) lie
in \((\sqrt y,y]\); the members in \((y^{1/4},\sqrt y-1]\) have their
\(E\)-images in \((\sqrt y,y]\), with log-mass at least
\((1-2m^{-2^k})\) times their own; at most one member lies in
\((\sqrt y-1,\sqrt y]\), with \(1/n\le 1/((m+1)^2-1)\). Hence
\(g_A(\log y)\ge(1-2m^{-4})\bigl(\ell(S_k)-1/((m+1)^2-1)\bigr)\ge c_A\),
and \(c_A>0\) because \(0.375(m+1)\ge 1+0.375/(m+1)\) for \(m\ge 3\).
\(\square\)

### 5.5 The theorem

Let \(\lambda^*\) be the root in \((0,1)\) of
\(2^{-\lambda}+\tfrac13(\tfrac38)^{\lambda}=1\),
let \(\lambda_{\mathrm{pair}}\) be the pairing-only root of
\(2^{-\lambda}+\tfrac19(\tfrac38)^{\lambda}+\tfrac29(\tfrac34)^{\lambda}=1\),
and let \(\lambda^{**}\) be the root of (1.1).
All three defining sums are continuous and strictly decreasing
on \([0,1]\), with value greater than \(1\) at \(0\) and less
than \(1\) at \(1\); each therefore has a unique root there.
Numerically \(\lambda^*\approx0.3774\), \(\lambda_{\mathrm{pair}}\approx0.4480\),
the \(OEOEE\) truncation is \(0.4801\), the \(V_3\) truncation is
\(0.4891\), the \(V_4\) truncation is \(0.4916\), the \(V_5\) truncation is
\(0.4924\), and
\(\lambda^{**}\approx0.4926\).
For comparison: the elementary sweep alone, without Proposition 4.4,
gives \(2^{-\lambda}+\tfrac2{21}(\tfrac34)^\lambda=1\), root
\(0.138\); perfect fiber equidistribution at this depth would
give \(2^{-\lambda}+\tfrac13(\tfrac34)^\lambda=1\), root
\(\lambda_{\mathrm{ideal}}\approx0.4927\), the ceiling of the depth-two
method.

**Theorem 5.3 (logarithmic density of a backward-closed set).** Let
\(A\subseteq\mathbb N\) be nonempty and backward-closed, and let
\(0<\lambda<\lambda^{**}\). There are \(c>0\) and \(x_0\), depending on
\(A\) and \(\lambda\), such that
\[
\sum_{\substack{n\in A\\ n\le x}}\frac1n\ \ge\ c\,(\log x)^{\lambda}
\qquad\text{for all}\ x\ge x_0 .
\]
The same conclusion for \(\lambda<\lambda^*\) uses only
Proposition 4.4 (no sweep lemma).

*Proof.* Apply Lemma 5.1 to \(g=g_A\), using the three
pairs in (5.2) and the five pairs
\((\rho_k,3^{-(k+1)})\), \(2\le k\le6\), of (5.10).
For \(0<\lambda<\lambda^{**}\), the sum of their
\(c_ie_i^\lambda\) is greater than \(1\). Thus
\(\zeta=\sum_i c_i e_i^\lambda-1>0\). Equations (5.2) and
(5.10) have the required form, with the Appendix D
errors, all tending to \(0\). Let \(m\ge 3\) be a
member of \(A\) and \(c_0=c_A\) from Lemma 5.2. Choose \(t_1\) so large
that \(\tfrac{729}{8192}t_1\ge 4\log(m+1)\), that \(e^{729t_1/8192}\ge 10^6\),
and that for all \(t\ge t_1\) the errors satisfy
\(\sum_i\eta_i(t)e_i^\lambda\le\zeta/3\) and
\(\eta_0(t)\le\tfrac{2\zeta}3c_A\). Lemma 5.2 gives \(g_A\ge c_A\) on
\([\tfrac{729}{8192}t_1,t_1]\). The first induction step of Lemma 5.1 covers
up to \(t_1/(\tfrac34)=\tfrac43 t_1\), at which
\(\tfrac{729}{8192}t=\tfrac{243}{2048}t_1\). Lemma 5.1 then gives
\(g_A(t)\ge Kt^\lambda\) for all \(t\ge\tfrac{729}{8192}t_1\), and
\(\sum_{n\in A,\,n\le x}1/n\ge g_A(\log x)\). For \(\lambda<\lambda^*\)
use (5.1) with \((e_i,c_i)=(\tfrac12,1),(\tfrac38,\tfrac13)\). \(\square\)

Lean: `contagion_of_production_inequality` and
`logMass_contagion_of_production` in
`formal/Problems/Juggler/FateContagionBound.lean`, with the inequality
(5.2) — the eight productions \((e_i,c_i)\) above, with errors
\(\eta_i,\eta_0\ge 0\) tending to \(0\) — as a hypothesis and for
every \(0<\lambda\le 0.49\): the seed is Lemma 5.2 (`gA_seed`), the
induction is Lemma 5.1, and \(\zeta(0.49)=0.00168>0\) is `zeta_pos_49`,
eight exact rational lower bounds \(r_i\le e_i^{49/100}\) checked as
\(r_i^{100}\le e_i^{49}\); \(\zeta\) is antitone in \(\lambda\)
(`zeta_antitone`), so \(\lambda\le 0.49\) suffices. The root
\(\lambda^{**}\) and the range \(0.49<\lambda<\lambda^{**}\) are not
formalized, and neither is (5.2) itself. The hypothesis \(\eta_0\ge 0\)
is not needed.

Lean, unconditionally: the two families of Section 5.1 that need no
exponential sum are proved with explicit errors,
\(g_A(t)\ge(1-4e^{-t/4})g_A(t/2)+(\tfrac29-\tfrac{50}9e^{-t/8})g_A(3t/4)-\eta_0(t)\)
for \(t\ge40\) with \(\eta_0(t)=2e^{-t/2}+\tfrac49e^{-3t/4}+136e^{-t/8}\)
(`Production.production_two`, from `Production.family_E` on Lemma 3.1 and
`Production.family_OE` on Lemmas 4.2 and 4.3), and Lemma 5.1 on these
two productions, with \(2^{-13/40}+\tfrac29(\tfrac34)^{13/40}>1\) certified
by \(0.798^{40}\le2^{-13}\) and \(0.91^{40}\le(\tfrac34)^{13}\)
(`Production.zeta2_pos`), gives Theorem 5.3 for every
\(0<\lambda\le\tfrac{13}{40}\) with no hypothesis
(`Production.contagion_elementary`,
`Production.logMass_contagion_elementary`), and Corollary 5.5(2) at that
exponent (`Production.failures_logMass_ge`), in
`formal/Problems/Juggler/FateProduction.lean`. The root of
\(2^{-\lambda}+\tfrac29(\tfrac34)^\lambda=1\) is \(0.32612\ldots\), which
\(\tfrac{13}{40}\) reaches to within \(0.4\%\); what
lifts it to \(\lambda^{**}\) is the block-average family, which needs
the two exponential-sum bounds of Proposition 4.4, and the ladder (5.10),
which needs Appendix D. Composed with Theorem 7.2 and Corollary 8.4,
whose contagion hypothesis it discharges, this gives two statements
with no hypothesis on the contagion side: a Tao-type rate
\(\#\{\text{odd failures in }(y,2y]\}\le y(\log y)^{-e}\) with
\(e>\tfrac{27}{40}\) implies the conjecture
(`Production.conjecture_of_tao_rate`), and so does a cylinder
bound \(\mathrm H(C,A)\) with \(e(C)>\tfrac{27}{40}\)
(`Production.conjecture_of_cylinder_bound`). The paper's
conditional forms need \(e>1-\lambda^{**}\approx0.51\) and the
production inequality (5.2); the price of dropping the exponential sums
at the pointwise coefficient is the stronger rate. Section 5.8 removes
that price: at the averaged coefficient the same two productions give
every \(\lambda\le100/203\) with no hypothesis, and the two reductions
at \(e>103/203\) (`Production.conjecture_of_tao_rate_averaged`,
`Production.conjecture_of_cylinder_averaged`).

**Corollary 5.4 (natural density, infinitely often).** For every
\(\lambda<\lambda^{**}\) there is \(c>0\) such that for every
\(X\ge x_0\) some \(y\in(\sqrt X,X]\) satisfies
\(\#\bigl(A\cap(y/2,y]\bigr)\ge c\,y\,(\log y)^{\lambda-1}\).

*Proof.* \(\ell_A(\sqrt X,X]=g_A(\log X)\ge K(\log X)^\lambda\) is
spread over at most \(\tfrac12\log_2X+2\) dyadic blocks
\((y/2,y]\) with \(\sqrt X<y\le X\); one of them has
\(\ell_A(y/2,y]\ge K'(\log X)^{\lambda-1}\), hence
\(\#(A\cap(y/2,y])\ge\tfrac y2\,\ell_A(y/2,y]\ge\tfrac{K'}2\,y\,(2\log y)^{\lambda-1}\),
because \(\log X\le 2\log y\) and \(\lambda-1<0\). \(\square\)

**Corollary 5.5 (fate contagion).** Let \(\varphi\) be a fate realized
by at least one start: the trivial cycle, a particular nontrivial cycle
\(C\), or divergence. Then \(\{n:\mathrm{fate}(n)=\varphi\}\) satisfies
Theorem 5.3 and Corollary 5.4. In particular:

1. \(\sum_{n\in R,\ n\le x}1/n\gg(\log x)^{\lambda}\) for every
   \(\lambda<\lambda^{**}\).
2. If some start does not reach \(1\), then
   \(\sum_{n\notin R,\ n\le x}1/n\gg(\log x)^{\lambda}\), and on
   infinitely many dyadic blocks the failures have natural density
   \(\gg(\log y)^{\lambda-1}\).
3. If a nontrivial cycle exists, the set of starts that enter it has
   the same lower bounds; if a divergent orbit exists, so does the set
   of divergent starts.

*Proof.* Lemma 2.1 and Theorem 5.3. \(\square\)

Lean: Corollary 5.4 is `Density.exists_block_of_shell` in
`formal/Problems/Juggler/FateDyadicDensity.lean`, the pigeonhole from a
shell bound \(K(\log X)^\lambda\le\ell_A(\sqrt X,X]\) with the constant
\(K/12\): the shell is covered by the blocks \((X/2^{j+1},X/2^j]\),
\(j\le\log_2X\), at most \(3\log X\) of them, a block's log-mass is at
most \(2\,\#(A\cap(y/2,y])/y\), and \(\log X<2\log y\) on the shell;
`Density.natDensity_averaged` is the corollary for every
\(0<\lambda\le100/203\) with no hypothesis, on Theorem 5.18. Corollary
5.5 is the instantiation at the fate classes through Lemma 2.1:
`Density.reachesOne_logMass_averaged` and
`Density.reachesOne_natDensity_averaged` for \(R\);
`Production.failures_logMass_averaged` and
`Density.failures_natDensity_averaged` for the failures;
`Density.basin_logMass_averaged`, `Density.basin_natDensity_averaged`,
`Density.escapes_logMass_averaged` and
`Density.escapes_natDensity_averaged` for the basin of a cycle state
and for the divergent starts. What stays human is the range
\(100/203<\lambda<\lambda_{\mathrm{ideal}}\), as for Theorem 5.18.

### 5.6 Remarks

*The status of stronger density bounds.* The theorem gives a
logarithmic counting lower bound. It does not imply positive natural
or logarithmic density. The ideal model of Section 5.7 has critical
exponent \(1\), but the corresponding arithmetic hypotheses are
not proved. Corollary 5.4 gives a natural-density lower bound on
infinitely many blocks. No pointwise lower bound on every dyadic
block is proved here. The even-only tree of a single seed is
lacunary, but it need not be backward-closed under the full Juggler
map and therefore is not a counterexample for that larger class.

*Sharpness of the constants.* The monotone pairing gives
\(\tfrac13H_m-2\); the observed floor on good fibers is \(0.328\) at
\(\alpha_m\approx\tfrac13\) (Section 11). The depth-two gap
\(0.448\to 0.4927\) was a dynamical averaging problem for the
low-even set \(P=\{m:G_m/H_m\le 0.40\}\); Section 5.8 closes it
without averaging over \(A\), because \(P\) has finite total
logarithmic mass (Theorem 5.16), so that the pointwise \(\tfrac13\) of
the pairing is not needed. The nominal exponent
\(\rho_w\) gives a useful scale diagnostic for candidate productions,
but Model calculation 5.13 shows that it does not collapse the actual
nested fiber to one monomial interval. The finite \(V_k\) constructions
below use their own exact nested fibers; their limiting transfer-matrix
value \(0.4927\) is a model ceiling, not a proved infinite-family
exponent.

*What is excluded.* Nothing. Corollary 5.5 does not say that a cycle
or a divergent orbit is impossible; it says that either would be
common.

### 5.7 Finite productions and comparison models

Every production used above is a parity word \(w\) applied backwards.
Write \(a=\#\{E\ \text{in}\ w\}\), \(b=\#\{O\ \text{in}\ w\}\). The
source of a \(w\)-production sits at log-scale \(\rho_wt\) with

\[
\rho_w=2^{-a}\bigl(\tfrac32\bigr)^{b},
\qquad
c^{\rm ideal}_w=\frac{2^{-|w|}}{\rho_w},
\tag{5.7}
\]

the second being the log-mass coefficient when the fiber realizes the
fair share \(2^{-|w|}\). Formula (5.7) returns every coefficient in
this section and in Appendix C: \(c_E=1\), \(c_{OE}=c_{OEE}=\tfrac13\),
\(c_{OOEEE}=\tfrac19\).

*A Collatz identity.* With \(\rho_w=(\tfrac32)^b2^{-(|w|-b)}\) for a
word with \(b\) odd letters, (5.7) simplifies to
\(c^{\rm ideal}_w=3^{-b}\): the ideal coefficient depends only on the
odd count, and \(3^{-b}\) is the probability that the \(b\) residue
conditions modulo three demanded by the odd backward steps of the
shortcut Collatz map all hold. Hence
\(\sum_wc^{\rm ideal}_w\rho_w^{\lambda}=\sum_w2^{-|w|}\rho_w^{\lambda-1}\),
the exponential moment at \(\lambda-1\) of the fair-coin Collatz walk
over the same words; over a bounded complete prefix-free family its two
classical roots, Kraft equality at \(0\) and the martingale identity
\(\mathbb E\rho=\tfrac12(\tfrac32+\tfrac12)=1\) at \(1\), sit at
\(\lambda=1\) and \(\lambda=2\). Boundedness matters for the second
identity. The family of all minimal descent certificates is prefix-free
and has Kraft mass one, by the survivor-decay estimate of Paper B.
Every terminal multiplier is below one, and the certificate \(E\)
has fair weight \(1/2\) and multiplier \(1/2\). Its total multiplier
moment is therefore at most \(1/4+1/2=3/4\), not one.
For an unbounded family, preserving the second identity requires a
separate limiting argument, such as vanishing multiplier-weighted
survivor mass. The root \(1\) of Proposition 5.12 is
Kraft equality read one exponential level up; the depth-two model,
which lacks the ascending word \(OO\), has the root
\(\lambda_{\mathrm{ideal}}\), and Section 5.8 reaches that root as a
supremum. The identity moves no constant; it says which half of this
paper the Collatz walk reaches, the ceiling and not the engine.

**Proposition 5.12 (an ideal-model critical exponent).** For
\(0<\eta\le1\), define \(\lambda(\eta)\) as the root in
\((0,1]\) of the model characteristic equation
\[
2^{-\lambda}+\tfrac\eta3(\tfrac32)^\lambda=1.
\tag{5.8}
\]
Then \(\lambda(1)=1\) and
\(\lambda'(1)=1/\ln(4/3)=3.4760\ldots\).
This is an algebraic model, not a Juggler counting theorem.

*Proof.* On \([0,1]\), the left side is strictly decreasing:
its derivative is at most
\(-\tfrac12\ln2+\tfrac12\ln(3/2)<0\).
At \(\lambda=0\) it is \(1+\eta/3>1\), and at
\(\lambda=1\) it is \((1+\eta)/2\le1\). This gives a unique
root in that interval, equal to \(1\) exactly for \(\eta=1\).
Implicit differentiation at \((1,1)\) gives the derivative.
At \(\eta=1\) the two tilted weights are both \(1/2\), the
fair-coin path weights. They are not both \(1/2\) for general
\(\eta\). \(\square\)

The root at \(1\) describes what the ideal characteristic equation
permits. Exact nested fibers and their shares must still be proved
before a proposed production list yields an arithmetic exponent.

**Model calculation 5.13 (collapsed-power fiber; not an identity for
the Juggler map).** If one replaces the nested branch belonging to a
production word \(w\) by the single model map
\(\widetilde J_w(n)=\lfloor n^{\rho_w}\rfloor\), then its fiber over a
source \(m'\) is exactly
\(I_{\rm mod}(m')=[m'^{1/\rho_w},(m'+1)^{1/\rho_w})\), and at scale
\(P\asymp m'^{1/\rho_w}\)

\[
|I_{\rm mod}(m')|
=\tfrac1{\rho_w}\,m'^{1/\rho_w-1}(1+O(1/m'))
\asymp P^{\,1-\rho_w}.
\]

The corresponding assertion for the exact map is false. For example,
\(1015\) follows

\[
1015\xrightarrow O32336\xrightarrow E179\xrightarrow O2394
\xrightarrow E48\xrightarrow E6,
\]

so its word is \(OEOEE\) and \(J^5(1015)=6\). But
\(7^{32}\le1015^9<8^{32}\), hence
\(\lfloor1015^{9/32}\rfloor=7\), not \(6\). Nested floors cannot in
general be replaced by one final floor.

Appendix C's localized parity estimate requires an *actual proved*
parameter interval of length at least \(P^{1/2}\). Thus
\(\rho_w\le\tfrac12\) is only the collapsed model's candidate threshold;
it neither proves the needed interval nor the ideal share. The words
\(E\), \(OEE\), and conditionally \(OOEEE\) have separate fiber
arguments in their cited results. The nominal lengths
\(P^{1/2},P^{5/8},P^{23/32}\) remain useful bookkeeping, while the
nominal \(OE\) and \(OOEE\) lengths \(P^{1/4}\) and \(P^{7/16}\) only
screen where that particular localization estimate could apply.

**The conditional run model and the \(K_3\) interface.** Production
words must be prefix-free. First passage of the nominal \(\rho_w\) below
\(\tfrac12\) gives a candidate list, not a theorem that its fibers have
the model length or ideal share. A
run of \(r\) consecutive \(O\)'s forces \(r\) nested \(3/2\)-powers
plus the closing square root — Paper B at depth \(r+1\). Paper B is
complete to depth \(4\), and to depth \(5\) except \(OOOO*\), which is
the parked kernel \(K_3\). Under the additional hypothesis that every
required candidate production through run length \(r\) is established
at the stated share, the transfer matrix gives:

| \(r\) | Paper B depth | conditional \(\lambda(r)\), pairing share | conditional \(\lambda(r)\), ideal-share model |
|---|---|---|---|
| 1 | 2 | \(0.4480\) | \(0.4927\) |
| 2 | 3 | \(0.6247\) | \(0.7180\) |
| 3 | 4 | \(0.7095\) | \(0.8414\) |
| 4 | 5 | \(0.7516\) | \(0.9121\) |

The table is a price list of hypothetical inputs, not an attained
ladder. Appendix C establishes one \(r=2\) word conditionally and prints
\(0.5392\); nothing here supplies the other words needed for \(0.6247\)
or \(0.7180\). Theorems 5.19 and 5.20 reach \(5/8\) and \(37/50\) by a
different route, the actual productions of Sections 5.9--5.10, not
through these run models. Row \(r=4\) would also meet the parked \(K_3\) kernel,
but the model does not prove that this is the only obstruction.

**The finite productions of the first route to Theorem 1.** Put
\(V_k=(OE)^{k-1}OEE\), for \(1\le k\le6\), and
\(\rho_k=\tfrac12(3/4)^k\). These six words are prefix-free.
The exact landing windows have iterated ceiling endpoints; they
are not the single-power windows of Model calculation 5.13.
Appendix D proves, for each of these fixed words, the needed
two-sided asymptotic and the resulting logarithmic coefficient
\(c_k=3^{-k}\).

The \(V_k\)-starts for \(k\ge2\) are contained in family 3 of
Section 5.1: their two-step images are odd \(V_{k-1}\)-produced
members of \(A\). Before counting them at their improved share,
remove those source sets from family 3. The old contribution is
\((2/9)c_{k-1}\); the new one is \(c_k\). Their difference is
\[
c_k-\tfrac29c_{k-1}=3^{-(k+1)},\qquad 2\le k\le6.
\tag{5.9}
\]
Disjointness and the two-sided estimates justify making all five
replacements simultaneously. Thus (5.2) gains
\[
\sum_{k=2}^{6}\bigl(3^{-(k+1)}-o(1)\bigr)g_A(\rho_k t)-o(1).
\tag{5.10}
\]
The corresponding roots are \(0.4801\), \(0.4891\), \(0.4916\),
\(0.4924\), and \(0.4926\). This is the finite input used in
Theorem 5.3.

For comparison only, summing the formal infinite series in (5.9)
gives the ideal depth-two equation
\(2^{-\lambda}+\tfrac13(3/4)^\lambda=1\), with root \(0.4927\).
Neither a uniform estimate in \(k\) nor attainment of that endpoint
is asserted. Adding just \(V_2\) to the conditional construction
in Appendix C would give root \(0.5665\); the analogous infinite
model gives \(0.5769\). These comparisons are not the exponents
claimed in Theorems 1 or C.5.

### 5.8 The averaged coefficient: two productions without exponential sums

Section 5.1 splits the \(OE\)-images into two families, item 2 over the
even blocks, where Proposition 4.4 controls the share, and item 3 over
the rest, where the pointwise floor of Lemma 4.2 applies, and the
ladder of Section 5.7 recovers part of what the pointwise floor loses.
The split exists only to serve the block average. This section takes
the \(OE\) family over all of \(A\cap(x^{3/8},x^{3/4}]\) at once ---
the \(E\)-images are even and the \(OE\)-images odd, which is the only
disjointness Section 5.1 uses --- and replaces the pointwise
coefficient by an averaged one, at the price of discarding the fibers
whose parity share is far from \(\tfrac12\). Those fibers have finite
total logarithmic mass, so the price is nothing. No exponential sum,
Vaaler approximation or second-derivative test appears below; the
tools are Dirichlet approximation and counting, and the chain is
formalized end to end. Full proofs are in the laboratory note [14];
the statements are given here with their constants.

*Notation.* For \(m\ge10^6\) let \(\Phi(m)\) be the \(OE\) fiber of
Lemma 3.2, \(H_m=|\Phi(m)|\), \(G_m\) the number of its members whose
image is even, and \(\sigma_m=G_m/H_m\) the parity share. The proof of
Lemma 4.2 writes the parity of the image of the \(j\)-th member as the
half-cell of a real \(x_j\) whose consecutive steps lie in an interval
\([A_m,A_m+\eta_m]\) with \(A_m=\tfrac32m^{2/3}\) and
\(\eta_m\le m^{-1/3}\) (Lean: `FiberParity.xval_step`); put
\(\alpha_m=\{A_m\}\). By Lemmas 3.2 and 4.2, \(\eta_mH_m\le0.6903\)
for \(m\ge10^6\).

**Lemma 5.14 (block lock).** Let \(m\ge10^6\) and let \(p/q\) be in
lowest terms with \(q\ge1\). Then
\[
\Bigl|\sigma_m-\tfrac12\Bigr|\ \le\
4\,|q\alpha_m-p|\ +\ \frac{5}{2q}\ +\ \frac{3.77\,q}{H_m}.
\]

*Proof.* Cut the fiber into consecutive blocks of \(q\) members. Inside a
block the points \(\{x_j\}\) form a translate of the grid
\(\tfrac1q\mathbb Z\) perturbed by at most
\(\varepsilon=|q\alpha_m-p|+q\eta_m\), because \(\gcd(p,q)=1\) makes
the \(q\) points \(\{y+ip/q\}\) a full grid; a \(\tfrac1q\)-grid meets
a half-circle within \(\tfrac12\) of evenly, and at most
\(2\varepsilon q+1\) of its points lie within \(\varepsilon\) of a
given point, so each block's even count is within
\(4\varepsilon q+\tfrac52\) of \(q/2\); the remainder block contributes
at most \(q\). Summing, \(|G_m-\tfrac12H_m|\le4\varepsilon
H_m+5H_m/(2q)+q\), and \(1+4\eta_mH_m\le3.77\). \(\square\)

**Lemma 5.15 (fiber lock).** Let \(\eta_0\in(0,\tfrac12]\) and
\(m\ge10^6\) with \(H_m\ge1280/\eta_0^2\). If
\(|\sigma_m-\tfrac12|\ge\eta_0\), then some integer \(q\) with
\(1\le q\le3.77/\eta_0\) satisfies \(\|q\alpha_m\|\le32/(\eta_0H_m)\).

*Proof.* Put \(\theta=\eta_0/16\) and \(H_0=\lfloor\theta H_m\rfloor\ge
\theta H_m/2\). Dirichlet's theorem gives \(q\le H_0\) and \(p\) with
\(|q\alpha_m-p|<1/H_0\), and passing to lowest terms decreases both
\(q\) and \(|q\alpha_m-p|\). In Lemma 5.14 the first term is then at
most \(8/(\theta H_m)=128/(\eta_0H_m)\le\eta_0/10\) and the third at
most \(3.77\theta=0.2356\,\eta_0\), so \(|\sigma_m-\tfrac12|\ge\eta_0\)
forces \(5/(2q)\ge0.6644\,\eta_0\), that is \(q\le3.77/\eta_0\); and
\(|q\alpha_m-p|<1/H_0\le32/(\eta_0H_m)\). \(\square\)

**Theorem 5.16 (poor-fiber tail).** Let \(\eta_0\in(0,\tfrac12]\),
\(P_{\eta_0}=\{m\ge10^6:|\sigma_m-\tfrac12|\ge\eta_0\}\) and
\(u_0(\eta_0)=\max(10^6,(1950/\eta_0^2)^3)\). For every \(u\ge u_0\),
\[
\#\bigl(P_{\eta_0}\cap(u,2u]\bigr)\le\frac{430}{\eta_0^2}\,u^{2/3},
\]
and for every \(U\ge u_0\),
\(\sum_{m\in P_{\eta_0},\,m>U}1/m\le2100\,U^{-1/3}/\eta_0^2\).

*Proof.* On \((u,2u]\), \(H_m\ge\tfrac23u^{1/3}-1\) (Lemma 3.2), and
\(u\ge(1950/\eta_0^2)^3\) makes Lemma 5.15 available with
\(Q=3.77/\eta_0\) and \(\delta=32/(\eta_0H_m)\). Every poor \(m\) is
therefore resonant, \(\|q\alpha_m\|\le\delta\) for some \(q\le Q\), and
the arc count of Lemma 4.3, applied for each \(q\le Q\) in turn to the
sequence \(q\cdot\tfrac32m^{2/3}\), whose steps and total increase
scale by \(q\), bounds the resonant \(m\) by
\((0.882u^{2/3}+2)\bigl(2Q\delta(2u)^{1/3}+Q(Q+1)\bigr)\le430u^{2/3}/\eta_0^2\).
The second bound is the first summed over dyadic blocks. \(\square\)

The constants are crude and the exponent is not: the census finds the
true density of the fibers with \(\sigma_m\le0.40\) between
\(1.4u^{-1/3}\) and \(2.1u^{-1/3}\) over \(u\in[10^5,10^8]\) [14]. What
is used below is only that the tail vanishes: the poor set has finite
total logarithmic mass, so it can support no set at every scale.

**Corollary 5.17 (the share on an arbitrary set).** For
\(\eta_0\in(0,\tfrac12]\), \(V\ge u_0(\eta_0)\) and every set
\(S\subseteq(V,\infty)\) of integers,
\[
\sum_{m\in S}\frac{\sigma_m}{m}\ \ge\ \Bigl(\frac12-\eta_0\Bigr)\sum_{m\in S}\frac1m\ -\ \frac{1050}{\eta_0^2}\,V^{-1/3}.
\]

*Proof.* Off \(P_{\eta_0}\) the bound holds termwise; on
\(S\cap P_{\eta_0}\) use \(\sigma_m\ge0\) and discard at most
\(1/(2m)\) per term, which Theorem 5.16 sums to at most
\(1050\,V^{-1/3}/\eta_0^2\). \(\square\)

**Theorem 5.18 (contagion by two productions).** Let \(A\) be nonempty
and backward-closed, \(0<\eta_0\le\tfrac14\), and \(\lambda>0\) with
\[
\zeta(\lambda,\eta_0)=2^{-\lambda}+\tfrac23\bigl(\tfrac12-\eta_0\bigr)\bigl(\tfrac34\bigr)^{\lambda}-1>0.
\]
There are \(K>0\) and \(t_1\) with \(g_A(t)\ge Kt^{\lambda}\) for
\(t\ge t_1\), hence \(\sum_{n\in A,\,n\le x}1/n\ge K(\log x)^\lambda\)
for \(x\ge x_0\). Consequently the conclusion of Theorem 5.3 holds for
every \(0<\lambda<\lambda_{\mathrm{ideal}}\), the root of
\(2^{-\lambda}+\tfrac13(\tfrac34)^\lambda=1\),
\(\lambda_{\mathrm{ideal}}=0.49265798\ldots\): given such a \(\lambda\), some
\(\eta_0\) has \(\zeta(\lambda,\eta_0)>0\).

*Proof.* For \(m\in A\cap(x^{3/8},x^{3/4}-1]\) the fibers \(\Phi(m)\) lie
in \((\sqrt x,x]\), are pairwise disjoint and disjoint from the
\(E\)-images, each \(n\in\Phi(m)\) has \(1/n>(m+1)^{-4/3}\), and
\(H_m(m+1)^{-4/3}\ge\tfrac2{3m}(1-O(m^{-1/3}))\) by Lemma 3.2. Corollary
5.17 with \(V=x^{3/8}\), whose error \(V^{-1/3}=x^{-1/8}\) has the shape
Lemma 4.3 already contributes, gives the \(OE\) family log-mass at
least \(\tfrac23(\tfrac12-\eta_0)(1-O(x^{-1/8}))\,g_A(3t/4)-700x^{-1/8}/\eta_0^2\),
and with item 1 of Section 5.1 unchanged,
\[
g_A(t)\ \ge\ (1-\varepsilon_1(t))\,g_A(t/2)
+\Bigl(\tfrac13-\tfrac23\eta_0-\varepsilon_7(t)\Bigr)g_A(3t/4)-\varepsilon_8(t),
\]
with \(\varepsilon_7,\varepsilon_8\to0\) for fixed \(\eta_0\). Lemma 5.1
with the seed of Lemma 5.2 finishes as in Theorem 5.3. \(\square\)

Corollaries 5.4 and 5.5 use Theorem 5.3 only through its conclusion,
so by Theorem 5.18 each holds for every \(\lambda<\lambda_{\mathrm{ideal}}\);
so do Corollary 7.1 and Theorems 7.2 and 7.3 at the matching
thresholds. Sections 5.9 and 5.10 raise the exponent further. Both corollaries are Lean at \(100/203\) (Section 5.5).

Lean: the whole chain. `BlockLock.block_lock` in
`formal/Problems/Juggler/FateBlockLock.lean` is Lemma 5.14 before
division by \(H_m\), a statement about an arbitrary real sequence with
steps in \([a,a+\eta]\); `FiberParity.fiber_lock` in
`FateFiberLock.lean` is Lemma 5.15, through Dirichlet's theorem in
lowest terms (`exists_coprime_approx`) and the fiber instantiation
`fiber_block_lock`; `FiberParity.resonance_count_le'` in
`FateResonanceCount.lean` is the arc count; `FiberParity.poor_count_le'`
and `poor_logMass_le` in `FatePoorTail.lean` are the two bounds of
Theorem 5.16, and `nonpoor_fiber_logMass_ge` the per-fiber bound behind
Corollary 5.17. In `FatePoorProduction.lean`,
`Production.production_two_averaged` is the production inequality
above, with error \(2e^{-t/8}\) on the \(OE\) coefficient and
\(2e^{-t/2}+\tfrac23e^{-3t/4}+1400e^{-t/8}/\eta_0^2\) additive, under
the one new hypothesis \(3(1280/\eta_0^2+1)\le e^{t/8}\), which is the
block condition of Lemma 5.15 at \(U=\lfloor e^{3t/8}\rfloor\) and the
whole cost of averaging; `Production.contagion_averaged` is Theorem
5.18 with \(\lambda\) and \(\eta_0\) free and \(\zeta(\lambda,\eta_0)>0\)
as its hypothesis. The exponent is a separate arithmetic certificate:
`Production.zeta2avg_pos` checks \(0.710737\le2^{-100/203}\) and
\(216967/250000\le(\tfrac34)^{100/203}\) as \(203\)rd powers in exact
integer arithmetic, so that \(\zeta(100/203,10^{-5})>2.05\cdot10^{-5}\),
and `zeta2avg_antitone` extends it to every \(\lambda\le100/203\).
Hence `Production.logMass_contagion_averaged`: for every nonempty
backward-closed \(A\) and every \(0<\lambda\le100/203\), with no
hypothesis, \(\sum_{n\in A,\,n\le x}1/n\ge K(\log x)^\lambda\) for
\(x\ge x_0\), above \(\lambda^{**}=0.4925715\ldots\) of the first route;
and with it `failures_logMass_averaged` (Corollary 5.5(2) at
\(100/203\)), `conjecture_of_tao_rate_averaged` (Theorem 7.2 at
\(e>103/203\)) and `conjecture_of_cylinder_averaged` (Corollary
8.4 at \(e(C)>103/203\)). The certificate is re-derived in exact
rational arithmetic by `oe_rest_average.exponent_certificate`, with the
smaller denominators enumerated: \(67/136\) also lies in
\((\lambda^{**},\lambda_{\mathrm{ideal}})\) but leaves a tenth of the margin,
and \(33/67\) falls short of \(\lambda^{**}\). The break-even is
\(\eta_0=4.69\cdot10^{-5}\) at \(100/203\) and \(8.60\cdot10^{-5}\) at
\(\lambda^{**}\); the range \(100/203<\lambda<\lambda_{\mathrm{ideal}}\) is
the choice of \(\eta_0\) in Theorem 5.18 and is not separately
certified.

What Section 5.8 changed is the critical path of Theorem 1:
Proposition 4.4 with its two exponential-sum bounds, the ladder of
Section 5.7 with Appendix D, and the statements of Lemmas 4.1, 4.1' and
4.2 are no longer needed for the exponent; one step of Lemma 4.2's
proof, the step interval, is. What does not change: the supremum is
approached and not attained, \(\eta_0\) being fixed before \(x\), as in
Theorem 5.3; the constants are large (at \(\eta_0=4.3\cdot10^{-5}\),
\(u_0\approx1.2\cdot10^{36}\), \(x_0\approx10^{96}\), \(t_1\approx221\));
and no standing question moves --- the exponent is below \(1\), the
rate of Theorem 7.2 is not proved, no cycle is excluded and no orbit is
shown to reach \(1\).

### 5.9 Three actual productions and exponent 5/8

This section proves Theorem 1 at the exponent \(5/8\). Its analytic
input is the OOEE poor-fiber estimate of Appendix E. Lean proves a count
form of that estimate and the production (5.12) from it, so (5.11) is
kernel-checked (Formal boundary, below); Theorem E.1 itself is not
formalized. Section 5.8 supplies the positive seed needed below.

**Theorem 5.19 (three-production contagion).** Every nonempty
backward-closed set \(A\) of positive integers satisfies
\[
\sum_{n\le X,\ n\in A}\frac1n\ge K(\log X)^{5/8}
\qquad(X\ge X_0)
\tag{5.11}
\]
for some \(K>0,X_0\). The same conclusion holds for each realized
fate class. The bound (5.11) is kernel-checked in Lean with no
hypothesis; each fate class is backward-closed by Lemma 2.1.

*Proof.* Put
\[
a(n)=n+(n\bmod2),\quad w(n)=\log\frac{a(n)+1}{a(n)-1},\quad
F(t)=\sum_{n\le\lfloor e^t\rfloor,\ n\in A}w(n).
\]
For positive integers, \(1/n\le w(n)\le4/n\). Let
\(S_E(t),S_{OE}(t),S_{OOEE}(t)\) be the corresponding weighted
masses of starts in \(A\), below \(\lfloor e^t\rfloor\), with
the indicated actual initial words. The three families are disjoint.
Exact even-fiber conservation gives, for \(t\ge8\),
\[
F(t/2-4)\le S_E(t).
\]
The OE poor-fiber theorem of Section 5.8, converted to this weight,
and Appendix E's OOEE theorem give constants \(C,T\) such that
\[
\frac{33}{100}F(3t/4-4)\le S_{OE}(t)+C,\qquad
\frac{11}{100}F(9t/16-4)\le S_{OOEE}(t)+C
\quad(t\ge T).
\tag{5.12}
\]
Here all cutoffs concern actual starts. An OE predecessor of \(m\)
has \(n^3<(m+1)^4\); an OOEE predecessor has
\(n^9<64(m+1)^{16}\). Since \(m+1\le2m\), the target
cutoffs \(m\le e^{3t/4-4}\) and \(m\le e^{9t/16-4}\)
place their sources below \(e^t\). Distinct target fibers are
disjoint, and backward closure puts their sources in \(A\).

For completeness, the weighted OE coefficient follows from
\(H_m=(2/3)m^{1/3}+O(1)\), source weight
\(2m^{-4/3}(1+O(1/m))\), and target weight
\(2m^{-1}(1+O(1/m))\). The actual fiber ratio is
\((2/3)\sigma_m+O(m^{-1/3})\). Outside a poor set of finite
reciprocal mass it exceeds \(33/100\), after a finite initial
segment is removed. The removed target weight is bounded independently
of \(A\) and the cutoff. The OOEE coefficient is Appendix E's
arbitrary-target consequence with \(\eta=1/900\), since
\(1/9-1/900=11/100\). This proves (5.12), including its uniform
additive loss. The weighted OE step also has a separate Lean proof.

Disjointness now yields
\[
F(t)\ge F(t/2-4)+\frac{33}{100}F(3t/4-4)
                  +\frac{11}{100}F(9t/16-4)-2C.
\]
Let \(G(t)=F(t-16)-5C\). For each
\(r\in\{1/2,3/4,9/16\}\),
\(rt-16\le r(t-16)-4\). Monotonicity, and the coefficient
sum \(36/25\), therefore give eventually
\[
G(t)\ge G(t/2)+\frac{33}{100}G(3t/4)
                  +\frac{11}{100}G(9t/16).
\tag{5.13}
\]
The constant remainder is \(5C(36/25-1)-2C=C/5\ge0\).
Section 5.8 implies \(F(t)\to\infty\), so \(G\) has a
positive seed on a sufficiently late compact interval. Exact rational
comparisons, obtained by taking eighth powers, give
\[
2^{-5/8}\ge\frac{648}{1000},\quad
(3/4)^{5/8}\ge\frac{835}{1000},\quad
(9/16)^{5/8}\ge\frac{697}{1000}.
\]
Their weighted sum is at least \(50011/50000>1\).
The recursion lemma with zero errors gives \(G(t)\ge Kt^{5/8}\).
Evaluate at \(t=\log X\) and use the weight comparison to
obtain (5.11). \(\square\)

**Dyadic consequence.** There is \(c>0\) such that infinitely
many dyadic intervals \((y,2y]\) contain at least
\(cy(\log y)^{-3/8}\) members of \(A\). Otherwise their
reciprocal masses are eventually at most
\(c(\log y)^{-3/8}\). Summing over \(y=2^k\) up to \(X\)
bounds the total by a constant times \(c(\log X)^{5/8}\),
plus a fixed initial mass. Choosing \(c\) below the constant in
(5.11) is a contradiction. Smaller positive exponents follow by
weakening (5.11). This proves all clauses of Theorem 1; the dyadic
consequence at this new exponent is written, not separately audited in Lean.

**Formal boundary.** `FateOOEEAssembly` proves disjointness, the
even cutoff, the shifted recursion, the rational certificate and the
contagion and Tao implications. `FateOEWeighted` proves the OE input,
including a uniform error at most 6 when converting its finite
weighted sums to twice reciprocal mass. `FateOOEEWeighted` proves the
OOEE input, `OOEEProductionBound`, for every backward-closed class,
from the summable count-poor tail of `OOEEResonanceTail`; the
mixed-mode cancellation is `OOEEMixedModes`. So
`FateOOEEWeighted.logMass_growth` is (5.11), and
`FateOOEEWeighted.conjecture_of_tao_rate` and
`FateOOEEWeighted.pressure_average_conjecture` are Theorems 7.2 and
9.4 at the threshold \(3/8\), with no contagion-side hypothesis. These
supplementary modules have their own audits, among them
`formal/AxiomCheckOOEEWeighted.lean` and
`formal/AxiomCheckOOEECountPoorTail.lean`, with only `propext`,
`Classical.choice` and `Quot.sound`; the historical Paper C barrel
and its 473 recorded reports retain their earlier scope.

### 5.10 Five actual productions and exponent 37/50

The two five-letter words \(OOOEE\) and \(OOEOE\) are the next
productions. For each of them, the odd starts whose fifth iterate along
the word is a given target \(y\) lie in a window of about
\(\tfrac{32}{27}y^{5/27}\) consecutive integers near \(y^{32/27}\): a
fiber of length about \(P^{5/32}\) at source scale \(P\). That is too
short for the localized estimates of Appendix C, and the comparisons of
Appendix B record the localized route as closed. Paper B [12, Theorem 6.3]
proves an averaged substitute: almost every fiber receives its fair share
of both words. This section feeds that theorem into the recursion of
Section 5.9.

**Theorem 5.20 (five-production contagion).** Every nonempty
backward-closed set \(A\) of positive integers satisfies
\[
\sum_{n\le X,\ n\in A}\frac1n\ge K(\log X)^{37/50}
\qquad(X\ge X_0)
\tag{5.14}
\]
for some \(K>0,X_0\). The same conclusion holds for each realized
fate class. The proof has one input that is not formalized,
[12, Theorem 6.3], an AI-assisted written proof that has not been
independently reviewed; the rest is kernel-checked.

*Proof.* For \(a\in\{OOOEE,OOEOE\}\) and an integer \(y\ge1\), let
\(H_a(y)\) be the number of odd integers whose fifth iterate along
\(a\), with each letter applied regardless of parity, equals \(y\), and
let \(\mathcal F_a(y)\) be the set of those whose actual five-letter
word is \(a\). Call \(y\) poor for \(a\) if
\(|\#\mathcal F_a(y)-H_a(y)/16|\ge H_a(y)/1000\). By [12, Theorem 6.3]
with \(\eta=1/1000\), the poor targets of each word have a finite
reciprocal sum.

Keep the weight \(w\) and the mass \(F\) of Section 5.9, and let
\(S_{OOOEE}(t)\) and \(S_{OOEOE}(t)\) be the weighted masses of the
starts in \(A\) below \(\lfloor e^t\rfloor\) with the indicated actual
initial words. The candidates of a target \(y\) lie in
\([y^{32/27},\,y^{32/27}+\tfrac{32}{27}y^{5/27}+6]\), and
\(|H_a(y)-\tfrac{16}{27}y^{5/27}|\le4\) [12, Appendix D.1]. So when
\(y\in A\), \(y\ge10^{15}\) and \(y\) is not poor, its at least
\((\tfrac1{16}-\tfrac1{1000})H_a(y)\) actual sources, all in \(A\) by
backward closure, carry reciprocal mass at least \(\tfrac1{28}\cdot\tfrac1y\).
The windows of distinct targets are disjoint, the poor targets have
bounded reciprocal mass, and a fixed shift \(b\ge0\) of the target cutoff
places every source below \(e^t\). Converting reciprocal mass to the
weight \(w\) as in Section 5.9 gives constants \(b,C,T\) with
\[
\frac1{28}F\Bigl(\frac{27t}{32}-b\Bigr)\le S_a(t)+C
\qquad(t\ge T,\ a\in\{OOOEE,OOEOE\}).
\tag{5.15}
\]

The five families \(E\), \(OE\), \(OOEE\), \(OOOEE\) and \(OOEOE\) are
disjoint, so (5.12) and (5.15) give, for large \(t\),
\[
F(t)\ge F(t/2-4)+\frac{33}{100}F(3t/4-4)
+\frac{11}{100}F(9t/16-4)+\frac1{14}F\Bigl(\frac{27t}{32}-b\Bigr)-4C .
\]
Shift as in Section 5.9, now by \(s=16+32b/5\): let
\(G(t)=F(t-s)-8C\). Each \(r\in\{1/2,3/4,9/16\}\) satisfies
\(rt-s\le r(t-s)-4\), and
\(\tfrac{27}{32}t-s\le\tfrac{27}{32}(t-s)-b\). The coefficient sum is
\(1+\tfrac{33}{100}+\tfrac{11}{100}+\tfrac1{14}>\tfrac32\), so the
constant remainder \(8C(\sum_ic_i-1)-4C\) is nonnegative, and \(G\)
satisfies the recursion with zero errors. As in Section 5.9, \(G\) has a
positive seed on a sufficiently late compact interval. Exact rational
comparisons give
\[
2^{-37/50}\ge\frac{59873}{100000},\quad
(3/4)^{37/50}\ge\frac{10103}{12500},\quad
(9/16)^{37/50}\ge\frac{32663}{50000},\quad
(27/32)^{37/50}\ge\frac{17637}{20000}.
\]
Their weighted sum is at least \(17505199/17500000>1\). The recursion
lemma gives \(G(t)\ge Kt^{37/50}\). Evaluate at \(t=\log X\) and use the
weight comparison to obtain (5.14). \(\square\)

**Dyadic consequence.** As in Section 5.9, infinitely many dyadic
intervals \((y,2y]\) contain at least \(cy(\log y)^{-13/50}\) members
of \(A\), for some \(c>0\). This proves all clauses of Theorem 1; the
dyadic consequence at \(37/50\) is written, not separately audited in
Lean.

**Formal boundary.** `FateDepthFiveWeighted.depth_five_productions`
proves (5.15) for every backward-closed class from the finiteness of the
two reciprocal sums at \(\eta=1/1000\). It uses the fiber geometry of
`DepthFiveFibreGeometry`: the exact windows, the bounds above, and the
identification of \(\mathcal F_a(y)\) with the actual fibers.
`FateDepthFiveAssembly` proves the five-way disjointness, the shifted
recursion, the certificate `certificate_37_50`, and, given (5.15),
Theorem 7.2 and the corollaries of Theorem 9.2 and Proposition 9.3 at
the threshold \(13/50\). Composed,
`FateDepthFiveWeighted.logMass_growth_of_tails` is Theorem 5.20 with the
finiteness of the two reciprocal sums as its only hypothesis. The audits
`formal/AxiomCheckDepthFiveWeighted.lean` and
`formal/AxiomCheckDepthFiveAssembly.lean` show only `propext`,
`Classical.choice` and `Quot.sound`. Paper B's Theorem 6.3 supplies the
hypothesis in writing; of its proof, only Lemma D.3 and the fibre
geometry (D.2) are formalized.

## 6. Odd generation and the exact first-letter decomposition

Write \(S=\{\lfloor m^{3/2}\rfloor:\ m\ \text{odd}\}\) for the image of
the odd integers, and \(S_{\rm odd}\) for its odd members. The set
\(S\) is sparse: it has \(\asymp z^{2/3}\) members below \(z\).

### 6.1 Odd generation

**Theorem 6.1 (odd generation; Lean).** Let \(A\) be forward- and
backward-closed with \(1\notin A\). Then:

1. every \(n\in A\) descends by even steps only to an odd member
   \(m\ge 3\) of \(A\) (`exists_odd_ancestor_ge_three`);
2. for odd \(n\), \(n\in A\iff\lfloor n^{3/2}\rfloor\in A\)
   (`odd_mem_iff`), so the odd members of \(A\) are exactly the odd
   preimages of \(A\cap S\);
3. \(A\ne\emptyset\iff A\cap S\ne\emptyset\), i.e. \(A\) contains the
   image of some odd \(m\ge 3\) (`nonempty_iff_odd_image_mem`).

*Proof.* (1) If \(n\in A\) is even, \(\lfloor\sqrt n\rfloor\in A\) by
forward closure and is smaller; the chain stops at an odd integer,
which is \(\ge 3\) since \(1\notin A\) and \(2\notin A\) (\(J(2)=1\)).
(2) Forward closure gives one direction, backward closure the other.
(3) follows from (1) and (2). \(\square\)

Applied to the failure set \(F\): every positive integer reaches \(1\)
iff no image \(\lfloor m^{3/2}\rfloor\) of an odd \(m\) fails to reach
\(1\), and \(F\) is the \(E\)-forest over the odd preimages of
\(F\cap S\). The theorem changes the geometry of the problem. An
arbitrary failure set is replaced by a set of *seeds* — odd images,
a set of density \(\asymp z^{-1/3}\) at scale \(z\) — together with
the deterministic even ancestry of each odd preimage (its \(E\)-forest, whose
levels are the intervals of Lemma 3.1) and the unique odd preimage of
each seed in \(S\). Two consequences are used below: the log-count of
\(F\) is controlled by that of its odd members (Theorem 7.2), and the
first-letter decomposition of \(F\) has exactly one term that the
productions do not control (Section 6.2).

### 6.2 The exact decomposition and the free term

Let \(A\) be forward- and backward-closed. On \((\sqrt x,x]\) its
members split by first letters into three exact pieces (Figure 3):

- the **even** members, \(=\bigsqcup_{m\in A}E(m)\cap(\sqrt x,x]\),
  of log-mass \(\ell_A(x^{1/4},\sqrt x]+O(x^{-1/4})\) (Lemma 3.1);
- the **\(OE\)-type** odd members (\(\lfloor n^{3/2}\rfloor\) even),
  \(=\bigsqcup_{m\in A}\{n\in\Phi(m)\cap(\sqrt x,x]:\lfloor n^{3/2}\rfloor\ \text{even}\}\)
  (Lemma 3.2),   of log-mass between \(\tfrac29\) and \(\tfrac49\)
  times \(\ell_A(x^{3/8},x^{3/4}]\) on good fibers (Lemma 4.2,
  two-sided pairing) and \(\tfrac13(1+o(1))\) times it on \(E\)-blocks
  (Proposition 4.4);
- the **\(OO\)-type** odd members (\(\lfloor n^{3/2}\rfloor\) odd),
  \(=\{n(m):m\in A\cap S_{\rm odd},\ \sqrt x<n(m)\le x\}\),
  of log-mass \(\sum_{m\in A\cap S_{\rm odd},\ \sqrt x<n(m)\le x}1/n(m)\),
  where \(n(m)\) is the unique odd preimage. Writing the cutoff on
  \(n(m)\) keeps the floor endpoints exact.

Let \(\varphi_A(t)=\ell_A(e^{t/2},e^t]/(t/2)\) be the logarithmic
density of \(A\) on \((\sqrt x,x]\), \(t=\log x\). Define
\(\varphi^{\rm fib}_A(3t/4)\) by the normalization
\(\tfrac14\cdot\tfrac t2\cdot\varphi^{\rm fib}_A(3t/4)=\) log-mass of
the \(OE\)-type members, and \(\psi_A(t)\) by
\(\tfrac14\cdot\tfrac t2\cdot\psi_A(t)=\) log-mass of the \(OO\)-type
members. Then \(\varphi^{\rm fib}_A(s)\) is the density of \(A\) on
\((e^{s/2},e^s]\) weighted, on each fiber, by twice the even-image
fraction \(p_m=G_m/H_m\) of that fiber — so
the weighted and unweighted masses agree to vanishing relative
error on complete \(E\)-block unions, with an additional
exponentially small boundary error (Proposition 4.4), and
\(\varphi^{\rm fib}_A(s)\le\tfrac43\varphi_A(s)+O(e^{-s/6})\) always
(Lemmas 4.2, 4.3) — and \(\psi_A(t)\) is the log-weighted share of
\(A\) among the \(OO\)-type odd integers of \((\sqrt x,x]\), up to a
factor \(1+O(e^{-\delta t})\) from the depth-two equidistribution of
the parity of \(\lfloor n^{3/2}\rfloor\). With these definitions the
three pieces give the identity with boundary error
\[
\varphi_A(t)=\tfrac12\varphi_A(t/2)+\tfrac14\,\varphi^{\rm fib}_A(3t/4)+\tfrac14\,\psi_A(t)+O(e^{-t/4}/t),
\tag{6.1}
\]
whose only error is the boundary term of Lemma 3.1. For
\(A=\mathbb N\) every term is \(1+o(1)\). For \(A=F\) the boundary
condition is \(\varphi_F(t)=0\) for \(t\le\log N_0\).

![The first-letter decomposition of a two-way closed set on $(\sqrt x,x]$: the even members come from scale $x^{1/2}$ through $E$-blocks, the $OE$-type odd members from scale $x^{3/4}$ through fibers, and the $OO$-type odd members are the odd preimages of the odd images of $A$ at scale $x^{3/2}$ — the free term.](figures/paper_c_decomposition.png){ width=100% }

**Definition 6.2 (\(S\)-fairness).** A two-way closed set \(A\) is
*\(S\)-fair at scale \(t\)* if \(\psi_A(t)\le\varphi_A(3t/2)\), i.e. if
\(A\) is not over-represented among the odd images of odd integers at
scale \(e^{3t/2}\) relative to its density among all integers there;
it is *\(S\)-fair* if this holds for all \(t\ge t_0\).

**Proposition 6.3 (exact statements).** (i) \(\psi_F\equiv 0\) iff
\(F=\emptyset\): if \(F\ne\emptyset\), its minimum is odd with odd
image, so \(\psi_F(t)>0\) on a shell containing \(\min F\). (ii) The
identity (6.1) holds for \(F\) with the stated error, and its right
side contains exactly one term, \(\tfrac14\psi_F(t)\), that is not
determined by \(F\) at smaller scales through the two productions.

*Proof.* (i) If \(F=\emptyset\) then \(\psi_F\equiv 0\). If
\(F\ne\emptyset\), let \(n_F=\min F\). It is odd (an even failure has
the smaller failure \(\lfloor\sqrt{n_F}\rfloor\)), and its image is
odd (if \(J(n_F)\) were even, \(J^2(n_F)=\lfloor n_F^{3/4}\rfloor<n_F\) would be
a smaller failure). So \(n_F\) is an \(OO\)-type failure and
\(\psi_F(t)>0\) for \(t\) with \(e^{t/2}<n_F\le e^t\). (ii) is the
decomposition. \(\square\)

Lean: `minimal_failure_odd_odd` and `exists_minimal_failure` (the least
failure is odd with odd image), and the three pieces as
`first_letter_trichotomy` with `first_letter_pieces_disjoint`, in
`formal/Problems/Juggler/FateFirstLetter.lean`. The exact layer of
(6.1) is `first_letter_split` there: for any weight and any finite
index set, the weighted mass of a two-way closed class is the sum of
its even, \(OE\)-type and \(OO\)-type pieces, each indexed as the
paper indexes it, by the image lying in the class; `shellLogMass_split`
is the log-mass form on a shell \((y,x]\). The free term's
\(n(m)\) is well defined by `floorPower_odd_injective` (`J` is
strictly increasing on the odd integers, `floorPower_odd_lt`), and
`sum_image_ooPiece` rewrites the third piece as the paper's sum over
the odd images. What is not formalized is the normalization: the
densities \(\varphi_A\), \(\varphi^{\rm fib}_A\), \(\psi_A\),
the identification of each piece with its term of (6.1), and the
boundary error \(O(e^{-t/4}/t)\).

**Remark 6.4 (the walk heuristic; not a theorem).** If \(F\) were
\(S\)-fair, if the fiber weights were ideal
(\(\varphi^{\rm fib}_F=\varphi_F\)), and if the error term of (6.1)
were zero, then (6.1) would give
\(\varphi_F(t)\le\tfrac12\varphi_F(t/2)+\tfrac14\varphi_F(3t/4)+\tfrac14\varphi_F(3t/2)\):
the harmonic inequality of a random walk on \(\log t\) with steps
\(\log\tfrac12,\log\tfrac34,\log\tfrac32\) of probabilities
\(\tfrac12,\tfrac14,\tfrac14\), whose drift \(-0.317\) is negative, so
that the boundary condition \(\varphi_F=0\) below \(\log N_0\) would
force \(\varphi_F\equiv 0\). None of the three conditions is available
with the constants proved here: the fiber weights are only known to
lie in \([\tfrac23,\tfrac43]\), so the coefficients of the inequality
can sum to \(\tfrac12+\tfrac13+\tfrac14=\tfrac{13}{12}>1\), and the boundary
error \(O(e^{-t/4}/t)\) is not zero at the scales just above the floor
where the walk exits. We therefore do not claim that \(S\)-fairness
implies the conjecture. What is exact is Proposition 6.3; what is
proved about the free term is Proposition 10.1, which identifies
\(\psi_F(t)\) with a quantity bounded by every hypothesis of
Sections 8--9.

### 6.3 Where Papers A and B sit

Paper A [11] constrains the fate Lachesis from the inside: finance and
the walk charge bound the *states* of a hypothetical cycle (minimum
\(>3.5\cdot 10^8\), period \(\ge 780239\)). Theorem 1 constrains the
basin: if the cycle exists, its basin is a two-way closed class with
the cycle's states as seeds and log-count \(\gg(\log x)^\lambda\) for every
\(0<\lambda\le37/50\) (Theorems 5.19 and 5.20). In the present argument the
two estimates do not meet: finance bounds the seed, contagion the growth from
the seed, and no inequality bounds a basin from above. Paper B [12]
controls the descending branches of (6.1) — the fairness of the
landing distributions of \(E\), \(OE\) and, with its depth-4 and
depth-5 theorems, of deeper contracting words — on dyadic blocks, and
for the two depth-five words on almost every fiber (its Theorem 6.3,
used in Section 5.10);
Appendix C uses one statement of that type on sub-dyadic intervals as
an explicit hypothesis. Neither touches \(\psi_F\): the ascending
branch \(OO\) sends mass to \(x^{3/2}\), and its return is the
nested-floor parity at all depths. The two papers' large-deviation
exponents are one rate function read at two levels: the \(L\)-bad
condition of Section 8 at depth \(d=CL\) demands an odd share above
\(p_C=(1-1/C)/\log_23\), and \(e(C)/C\to1-H(\log2/\log3)=0.050044\)
bits as \(C\to\infty\), the exponent of Lagarias's Theorem D [3] that
Paper B's Section 6 uses; Paper B sits at \(L=0\), where the threshold
is \(\log2/\log3\) itself. The gap is \(4.8\cdot10^{-3}\) at \(C=100\)
and closes like \(1/C\).

## 7. The almost-all equivalence

**Corollary 7.1 (logarithmic form).** The following are equivalent:
(1) every \(n\ge 1\) reaches \(1\); (2) for some
\(0<\lambda\le37/50\), \(\sum_{n\le x,\ n\notin R}1/n=o((\log x)^{\lambda})\);
(3) for some \(0<\lambda\le37/50\), the starts \(n\le x\) whose orbit
never enters \([1,N_0]\) have logarithmic count \(o((\log x)^{\lambda})\).

*Proof.* (1)\(\Rightarrow\)(3): the set is empty. (3)\(\Rightarrow\)(2):
an orbit that enters \([1,N_0]\) reaches \(1\), so \(F\) is contained
in the set of (3). (2)\(\Rightarrow\)(1): \(F\) is backward-closed; if
it were nonempty, Theorem 5.20
would contradict (2). \(\square\)

**Theorem 7.2 (a Tao-type bound with rate implies the conjecture).**
Suppose that for some \(e>13/50\) and all
sufficiently large \(y\),
\[
\#\{n\ \text{odd},\ y<n\le 2y:\ n\notin R\}\ \le\ \frac{y}{(\log y)^{e}} .
\]
Then \(R=\mathbb N\).

*Proof.* By decreasing \(e\) if necessary, assume
\(13/50<e<1\); the hypothesis is preserved for large
\(y\). Suppose \(F\ne\emptyset\). By Theorem 6.1 every \(n\in F\)
lies in the \(E\)-tree of an odd member of \(F\). For an odd
\(n_0\in F\) the level-\(j\) set \(S_j(n_0)\) of its \(E\)-tree has
log-mass at most \(\prod_{i<j}(1+n_0^{-2^i})/n_0\le 2/n_0\)
(Lemma 3.1 gives \(\sum_{n\in E(m)}1/n\le(m+1)/m^2\)), and only levels
with \(n_0^{2^j}\le x\), i.e. \(j\le\log_2\log x\), meet \([1,x]\).
Hence
\[
\begin{aligned}
\sum_{\substack{n\in F\\n\le x}}\frac1n
&\le2(1+\log_2\log x)
 \sum_{\substack{n_0\in F\text{ odd}\\n_0\le x}}\frac1{n_0}\\
&\le2(1+\log_2\log x)
 \left(\sum_{k_0\le k\le\lfloor\log_2x\rfloor}(k\ln2)^{-e}+O(1)\right)\\
&\ll(\log x)^{1-e}\log\log x.
\end{aligned}
\]
By Theorem 5.20 the left side is
\(\ge K(\log x)^{\lambda}\) for every \(\lambda\le37/50\)
and all large \(x\). Choosing \(\lambda\in(1-e,37/50)\)
gives a contradiction. With Theorem 5.19 in place of Theorem 5.20 the
same proof needs \(e>3/8\), and its contagion input is machine-checked.
\(\square\)

**Theorem 7.3 (equivalence).** Every positive integer reaches \(1\) if
and only if there is \(e>13/50\) such that
\(\#\{n\ \text{odd}\in(y,2y]:\ n\notin R\}\le y(\log y)^{-e}\) for all
large \(y\).

*Proof.* If every integer reaches \(1\) the left side is \(0\).
Conversely Theorem 7.2. \(\square\)

Lean: `tao_rate_iff_conjecture` in
`formal/Problems/Juggler/FateContagionBound.lean`, with a contagion
bound as a hypothesis, as for Theorem 7.2; and
`conjecture_of_cylinder_bound_of_production`, Corollary 8.4 with
the earlier Theorem 5.3 replaced by the production inequality (5.2), so that the
chain from \(\mathrm H(C,A)\) to the conjecture has (5.2) as its only
analytic input, for any \(\lambda\le 0.49\) with \(1-\lambda<e(C)\)
(\(C\ge 19\) still suffices: \(e(19)=0.527>0.51\)). With the
contagion hypothesis discharged by Theorem 5.18,
`Production.conjecture_of_tao_rate_averaged` is Theorem 7.2 at
\(e>103/203\) and `Production.conjecture_of_cylinder_averaged`
is Corollary 8.4 at \(e(C)>103/203\), with no hypothesis on the
contagion side (Section 5.8). At the current thresholds,
`FateOOEEWeighted.conjecture_of_tao_rate` is Theorem 7.2 at
\(e>3/8\) with no contagion-side hypothesis, and
`FateDepthFiveAssembly.conjecture_of_tao_rate` is Theorem 7.2 at
\(e>13/50\) given the depth-five productions (5.15) for the failure set,
which `FateDepthFiveWeighted.depth_five_productions` derives from the
finiteness of the two reciprocal sums of Section 5.10.

The threshold \(13/50\) is the complement of the contagion exponent
\(37/50\), and \(3/8\) that of the machine-checked exponent \(5/8\).
Appendix C's earlier conditional exponent gives the weaker threshold
\(0.4608\).
Any improvement of the contagion exponent lowers the rate required of
the almost-all statement, and \(\lambda\to 1\) would make any positive
rate suffice — but that improvement requires all descent certificates
and is circular here (Section 5.6).

### 7.1 Comparison with the Collatz map: a structural analogy

The comparison with Tao's theorem [6] is a structural analogy, not a
transfer of methods, and it concerns two specific features.

*Depth.* Juggler's multiplicative changes of \(\log n\) motivate
a walk on \(\log\log n\) and the depth \(O(\log\log y)\).
This is the depth used by the sufficient hypotheses here, not a
proved stopping-time bound for every orbit. For the accelerated
Collatz map of Terras and Everett, parity words of length \(k\)
correspond to residue classes modulo \(2^k\). Their counts in an
interval of length \(y\) have an additive \(O(1)\) boundary error;
relative control by that fact alone becomes ineffective once
\(2^k\) is comparable to or larger than \(y\). Saying that every
depth of order \(\log y\) has singleton cylinders would be too
strong: the multiplicative constant in the depth matters.

*Preimage counts.* The result of Krasikov--Lagarias [7] cited in
Section 1.3 has a different counting scale from Theorem 1. An
\(x^{0.84}\) lower bound is compatible with a bounded reciprocal
sum, and by itself cannot contradict a logarithmic error bound.
This comparison explains why the particular argument of Theorem
7.2 does not transfer. It does not exclude other almost-all-to-all
arguments for Collatz.

*The analogue of Theorem 1 fails for Collatz, by exhibit.* For the
shortcut map \(n\mapsto n/2\), \(n\mapsto(3n+1)/2\), the set
\(A=\{3\cdot2^k:k\ge0\}\) is backward-closed: a multiple of three has
no odd preimage, since \(2\cdot3\cdot2^k-1\equiv2\pmod3\), so the fiber
of \(3\cdot2^k\) is \(\{3\cdot2^{k+1}\}\); the same holds for the
standard map. \(A\) is infinite, its counting function is
\(\lfloor\log_2(x/3)\rfloor+1\), and its reciprocal sum is exactly
\(\tfrac23\). What separates the two maps is not fiber size but
worst-case backward log-mass: the even block of \(m\) returns log-mass
at least \(\tfrac1m(1-\tfrac2m)\) for every \(m\) (Lemma 3.1, item 1 of
Section 5.1), whereas the Collatz fiber of \(m\) returns \(\tfrac1m\)
in the mean over \(m\) and exactly \(\tfrac1{2m}\) on every multiple of
three. Theorem 1 quantifies over every backward-closed set, so the
worst case governs and the mean is irrelevant.

Tao's theorem [6] has an arbitrarily slowly growing target and
logarithmic-density exceptional set. Our eventual-entry equivalence
has a fixed verified target and a specified dyadic rate; obtaining
that rate remains open. No part of Tao's renewal argument is claimed
to have been supplied for Juggler.


At the threshold \(13/50\) the conclusions of this section use Paper B's
Theorem 6.3 through Theorem 5.20. At \(3/8\), Theorem 7.2 is
kernel-checked with no contagion-side hypothesis; Corollary 7.1 is
written.

## 8. From parity control to the almost-all bound

### 8.1 Notation

For a word \(w\in\{O,E\}^d\) and \(t\le d\) write \(o_t(w)\) for the
number of odd letters among the first \(t\) and
\[
u_t(w)=o_t(w)\log_2 3-t
\]
for the *exponent walk*, so that the ideal image after \(t\) letters is
\(n^{2^{u_t}}\). For \(y>N_0\) put
\[
L(y)=\log_2\frac{\log 2y}{\log N_0},\qquad d(y)=\lceil C\,L(y)\rceil ,
\]
with a constant \(C\ge 5\) fixed below. A word \(w\) of length \(d\) is
\(L\)-*bad* if \(u_t(w)>-L\) for every \(1\le t\le d\) (its walk never
descends to \(-L\)). \(\mathrm{word}_d(n)\) is the realized itinerary
of the first \(d\) steps of \(n\) (letter \(s\) is the parity of
\(J^{s-1}(n)\)); the *cylinder* \([w]_y\) is the set of odd
\(n\in(y,2y]\) with \(\mathrm{word}_{|w|}(n)=w\). Odd starts have first
letter \(O\), so the fair share of an \(O\)-rooted cylinder of depth
\(d\) relative to the reference mass \(N=y/2\). The actual number of
odd starts in \((y,2y]\) is \(N+O(1)\); this bounded endpoint error
is absorbed in the asymptotic bounds below is \(2^{-(d-1)}N\).

### 8.2 Envelope descent and the rarity of bad words

**Lemma 8.1 (envelope descent).** Let \(n\in(y,2y]\) and \(d\ge 1\). If
\(\mathrm{word}_d(n)\) is not \(L(y)\)-bad, then \(n\in R\).

*Proof.* Some \(t\le d\) has \(u_t\le -L(y)\), i.e.
\(3^{o_t}/2^t\le\log N_0/\log 2y\le\log N_0/\log n\), i.e.
\(n^{3^{o_t}}\le N_0^{2^t}\) as integers. The power envelope
\(J^t(n)^{2^t}\le n^{3^{o_t}}\) (Paper A, Theorem 2.2;
`power_bound_word`) gives \(J^t(n)\le N_0\), so \(J^t(n)\in R\) and
\(n\in R\) by backward closure. Lean: `iterate_le_of_envelope`,
`mem_of_envelope_floor`, `reachesOne_of_itinerary_envelope`.
\(\square\)

**Lemma 8.2 (Chernoff).** For \(C\ge 5\) put
\[
p_C=\frac{1-1/C}{\log_2 3},\qquad
e(C)=\frac{C\,D(p_C\,\|\,\tfrac12)}{\ln 2},\qquad
D(p\|\tfrac12)=p\ln(2p)+(1-p)\ln(2(1-p)).
\]
For \(L>0\) and \(d\ge CL\), the number of \(L\)-bad words of length
\(d\) is at most \(2^d\cdot 2^{-e(C)L}\). Moreover, for every
\(\varepsilon>0\) there is \(L_0\) such that for \(L\ge L_0\) and
\(d=\lceil CL\rceil\) the number of \(L\)-bad words of length \(d\)
beginning with \(O\) is at most \(2^{d-1}\cdot 2^{-(e(C)-\varepsilon)L}\).

*Proof.* An \(L\)-bad word has \(u_d>-L\), i.e.
\(o_d>(d-L)/\log_2 3\ge p_Cd\) (as \(L/d\le 1/C\)). For a fair coin,
\(\Pr[\mathrm{Bin}(d,\tfrac12)\ge pd]\le e^{-dD(p\|1/2)}\) for
\(p\ge\tfrac12\), and \(D(\cdot\|\tfrac12)\) is increasing on
\([\tfrac12,1]\); \(p_C\ge\tfrac12\) for \(C\ge 5\). Hence the count is
at most \(2^de^{-dD(p_C\|1/2)}\le 2^de^{-CL\,D(p_C\|1/2)}=2^d2^{-e(C)L}\).
For the \(O\)-rooted count, the remaining \(d-1\) letters contain
\(o_d-1>(d-L)/\log_2 3-1=p'(d-1)\) odd letters with
\(p'=p_C-O(1/L)\); the same bound with \(d-1\) trials gives
\(2^{d-1}e^{-(d-1)D(p'\|1/2)}\), and
\((d-1)D(p'\|1/2)\ge(e(C)-\varepsilon)L\ln 2\) for \(L\) large.
\(\square\)

Lean: the first statement, in the exact form
\(\#\{w\ L\text{-bad},|w|=d\}\le 2^d\,2^{-e(C)L}\) for \(C\ge 5\),
\(d\ge CL\), \(d\ge 1\), is `LBad_count_le` in
`formal/Problems/Juggler/FateChernoff.lean`: the Markov tilt
`weight_markov` on the constant weight (`weightGen_one`,
\((1+x)^d\)), the value \(\exp(d\,h(p))\) at \(x=p/(1-p)\)
(`tilt_value`, `count_oddCount_ge_le_exp`), Gibbs' inequality
\(D(p\|\tfrac12)\ge 0\) (`klHalf_nonneg`), and \(p_C\in[\tfrac12,1)\)
from \(\log_2 3\le 8/5\) (`half_le_pC`, `pC_lt_one`). The \(O\)-rooted
statement with \(\varepsilon\) stays a human proof.

Numerically \(e(14)\approx0.299\), \(e(16)\approx0.389\), \(e(18)\approx0.480\), \(e(19)\approx0.527\), \(e(20)\approx0.574\),
\(e(21)=0.621\), \(e(25)=0.812\), \(e(30)=1.054\); \(e(C)\) grows
linearly in \(C\) with slope
\(D(1/\log_2 3\,\|\,\tfrac12)/\ln 2=0.050\).

### 8.3 The cylinder hypothesis and the bound

**Hypothesis \(\mathrm H(C,A)\) (log-log-depth cylinder bound).** For
all sufficiently large \(y\), with \(d=d(y)\), every word
\(w\in\{O,E\}^d\) that begins with \(O\) and is \(L(y)\)-bad satisfies
\[
\#[w]_y\ \le\ 2^{-(d-1)}\cdot\frac y2+\frac{y}{(\log y)^{A}} .
\]

Only an upper bound is asked, only at one depth per scale, and only
for the \(L(y)\)-bad words. Since \(2^{-(d-1)}y/2\asymp y(\log y)^{-C}\),
\(\mathrm H(C,A)\) with \(A>C\) says that no \(O\)-rooted cylinder of
depth \(d(y)\) whose envelope has not crossed the floor exceeds its fair
share by more than a relative \(O((\log y)^{C-A})\). The restriction is
essential: the older all-word version is false because already absorbed
starts can share a long terminating tail and overpopulate a cylinder
without contributing any live mass; see the
[absorbed-cylinder obstruction](../problems/juggler_absorbed_cylinder.md).
This obstruction does not refute \(\mathrm H(C,A)\) as stated here.

**Theorem 8.3 (Tao-type bound from the cylinder hypothesis).** Assume
\(\mathrm H(C,A)\) with \(C\ge 5\) and \(A>C+e(C)\). Then for every
\(\varepsilon>0\) and all sufficiently large \(y\),
\[
\begin{aligned}
\#\{n\text{ odd in }(y,2y]:n\notin R\}
&\le\#\{n\text{ odd in }(y,2y]:J^t(n)>N_0\ \forall t\le d(y)\}\\
&\le\frac y2\left(\frac{\log(2y)}{\log N_0}\right)^{-(e(C)-\varepsilon)}.
\end{aligned}
\]
In words: all but \(O(y(\log y)^{-e(C)+\varepsilon})\) odd starts in
\((y,2y]\) enter \([1,N_0]\) within \(d(y)=O(\log\log y)\) steps.

*Proof.* A failure never enters the verified floor, giving the
first inequality. A live start has a bad word by Lemma 8.1. Apply
Lemma 8.2 with \(\varepsilon/2\) in place of \(\varepsilon\). Every odd
start has an \(O\)-rooted word; by Lemma 8.2 the \(O\)-rooted bad words
number at most \(2^{d-1}2^{-(e(C)-\varepsilon/2)L(y)}\), and by
\(\mathrm H(C,A)\) each carries at most \(2^{-(d-1)}y/2+y(\log y)^{-A}\)
odd starts. Hence the count is at most
\[
\frac y2\,2^{-(e(C)-\varepsilon/2)L(y)}+2^{d-1}\,\frac{y}{(\log y)^A}
\ \le\ \frac y2\Bigl(\frac{\log 2y}{\log N_0}\Bigr)^{-(e(C)-\varepsilon/2)}
+\Bigl(\frac{\log 2y}{\log N_0}\Bigr)^{C}\frac{y}{(\log y)^{A}},
\]
using \(2^{d-1}\le 2^{CL}\). The second term is
\(O(y(\log y)^{C-A})=o(y(\log y)^{-e(C)})\) because \(A>C+e(C)\). For large \(y\), both terms fit inside
the displayed bound with exponent \(e(C)-\varepsilon\), using
the remaining \(\varepsilon/2\) slack. \(\square\)

Lean: the exact skeleton, in `formal/Problems/Juggler/FateChernoff.lean`.
`oddFailures_subset_bad_cylinders` is Lemma 8.1 in covering form: with
every start up to \(N_0\) reaching \(1\), an odd \(n\in(y,2y]\) that does
not reach \(1\) lies in the cylinder of a word whose every prefix fails
the integer envelope comparison \(N_0^{2^t}<(2y)^{3^{o_t}}\)
(`EnvelopeBad`); `LBad_of_envelopeBad` identifies those words as
\(L(y)\)-bad with \(L(y)=\log_2(\log 2y/\log N_0)\);
`oddFailures_card_le` is the union bound, and
`oddFailures_card_le_chernoff` composes it with Lemma 8.2: if every
\(L(y)\)-bad cylinder of depth \(d\ge CL(y)\) holds at most \(M\)
starts, the odd failures in \((y,2y]\) number at most
\(2^d\,2^{-e(C)L(y)}M\). `oddFailures_card_le_explicit` substitutes
\(d=\lceil CL(y)\rceil\) and the bound of \(\mathrm H(C,A)\) at the
scale \(y\), for \(O\)-rooted words only (`cylinder_even_root_empty`):
with \(\Lambda=\log 2y/\log N_0\), the odd failures in \((y,2y]\)
number at most \(y\,\Lambda^{-e(C)}+2\Lambda^{C}y(\log y)^{-A}\), at
every \(y\ge 2\) and without \(\varepsilon\). The displayed form
follows by absorbing the factor \(2\) into \(\Lambda^{\varepsilon}\)
and the second term into the first for \(A>C+e(C)\); that absorption
is not formalized. Corollary 8.4 uses only the exponent.

**Corollary 8.4 (the conjecture from a cylinder bound).** If
\(\mathrm H(C,A)\) holds for some \(C\ge 14\) and \(A>C+e(C)\), then
every positive integer reaches \(1\). Using only the machine-checked
Theorem 5.19, \(C\ge 16\) suffices.

*Proof.* Theorem 8.3 gives the hypothesis of Theorem 7.2 with
\(e=e(C)-\varepsilon\ge e(14)-\varepsilon>13/50\), since
\(e(14)\approx0.299\); with Theorem 5.19 alone the threshold is
\(3/8<e(16)\approx0.389\), while \(e(15)\approx0.344\). The earlier
routes needed \(C\ge19\) (\(\lambda^{**}\), \(e(19)\approx0.527\)), and
the pairing-only intermediate \(C\ge 20\) (\(e(20)=0.574>0.5520\)).
\(\square\)

Lean: `cylinder_bound_implies_conjecture` in
`formal/Problems/Juggler/FateCylinderCorollary.lean`: if
\(\mathrm H(C,A)\) holds at all large scales (`CylinderBound`, the
displayed bound on every \(O\)-rooted \(L(y)\)-bad cylinder of depth
\(d(y)\)) with \(C\ge 5\) and \(A>C+e(C)\), and the contagion bound of
Theorem 5.3 holds for the failure set with an exponent \(\lambda\)
satisfying \(1-\lambda<e(C)\), then every positive integer reaches
\(1\). The step from the explicit bound of Theorem 8.3 to the rate
\(y(\log y)^{-e}\) of Theorem 7.2, for any \(e<e(C)\), is
`oddFailures_eventually_le`: \(\Lambda\ge\log y/\log N_0\) turns the
first term into \((\log N_0)^{e(C)}y(\log y)^{-e(C)}\),
\(\Lambda\le 2\log y/\log N_0\) turns the second into
\(2(2/\log N_0)^Cy(\log y)^{C-A}\), and both exponent gaps are
positive. The numerical thresholds \(C\ge14\) and \(C\ge16\) are
statements about \(e(C)\) at \(13/50\) and \(3/8\) and stay with the audit.

### 8.4 Constants

The least integer depth constant in this sufficient criterion is \(C=14\) (\(e(14)\approx0.299>13/50\)), and \(C=16\) (\(e(16)\approx0.389>3/8\)) using only Theorem 5.19; the earlier route \(\lambda^{**}\) needed \(C=19\).
With the certified floor \(N_0=3.5\cdot 10^8\), the table below keeps
\(C=20\) as a conservative a-fortiori display:

| \(y\) | \(L(y)\) | \(d(y)\) | exact fair-coin bad probability | \((\log y)^{-0.6}\) | least depth for rate \(0.6\) |
|---|---|---|---|---|---|
| \(10^{20}\) | \(1.25\) | \(25\) | \(0.065\) | \(0.100\) | \(19\) |
| \(10^{100}\) | \(3.55\) | \(72\) | \(0.017\) | \(0.038\) | \(56\) |
| \(10^{1000}\) | \(6.87\) | \(138\) | \(0.0038\) | \(0.0096\) | \(117\) |

The bad probability is the fair-coin probability that a walk of
length \(d(y)\) never reaches \(-L(y)\), by dynamic programming over
the walk (unconditioned first letter; conditioning on
\(u_1=\log_2 3-1\) roughly doubles the finite-depth values and leaves
the exponent unchanged); the last column is the least depth at which
it drops below \((\log y)^{-0.6}\) — about \(17\,L(y)\). With the Lean
floor \(N_0=260\) the depths grow by about \(38\) letters. For
comparison, Paper B controls depth \(4\) (all words) and the two words
of depth \(5\) on dyadic blocks with power savings, relative errors about
\(y^{-1/24}\), \(y^{-1/48}\) and \(y^{-1/128}\); the
hypothesis asks for the bad cylinders at depth \(d(y)\to\infty\) with
relative error \(o(1)\) — weaker in rate than a power saving, unbounded
in depth.

Lean: a certified instance of the side condition, in
`formal/Problems/Juggler/FateCertified.lean`. The constants above are
an audit script; for one concrete \(C\) the script can be removed from
the chain entirely. A logarithm is certified by an integer power
comparison — if \(E\le e\) and \(x^n\le E^m\) then \(n\log x\le m\)
(`Certified.log_le_of_pow_le`, and three siblings) — so with Mathlib's
\(2.718<e<2.719\), six comparisons (\(2^{10}\le2.718^{7}\),
\(2.719^{2}\le2^{3}\), \(2^{84}\le3^{53}\), \(3^{94}\le2^{149}\),
\(2.719^{19}\le(3049/2500)^{100}\), \((50/39)^{4}\le2.718\)) give
\(\log 2\le\tfrac7{10}\) and \(\tfrac{84}{53}\le\log_23\le\tfrac{149}{94}\),
hence \(p_{30}\in[0.6098,0.61]\), hence
\(D(p_{30}\|\tfrac12)\ge0.018312\) and
\(e(30)>\tfrac{39}{50}\) (`Certified.chernoffExponent_thirty_gt`), with
\(e(30)<\tfrac{13}{10}\) in the other direction. So
`Certified.cylinder_bound_thirty` is Corollary 8.4 at \(C=30\) with
every constant a numeral: a cylinder bound \(\mathrm H(30,A)\) at all
large scales with \(A\ge32\), above a certified floor, gives the
conjecture, and nothing in its proof reads a table.
`Certified.pressure_thirty` and `Certified.one_sided_thirty` do the
same for Theorem 9.2's and Theorem 9.1's criteria (the latter at the
fair share \(q=\tfrac12\), where the one-sided exponent is the Chernoff
one, `Certified.oneSidedExponent_half`, and \(A\ge52\) suffices by
`Certified.logb_tilt_thirty_le`). The least \(C\) with
\(e(C)>\tfrac{27}{40}\) is \(23\), unchanged by the drop from
\(\tfrac7{10}\): \(e(22)=0.668392\) misses the lower threshold too, and
\(e(23)=0.716046\) clears both. The paper's own thresholds
\(e(C)>13/50\) at \(C=14\) and \(e(C)>3/8\) at \(C=16\) are statements
about the contagion exponents; both stay with the audit.

## 9. Weaker forms of the hypothesis

Theorem 8.3 asks for a fair-share upper bound on every envelope-bad
cylinder at one depth. Lower bounds and control of cylinders after their
envelope has crossed the floor are not needed. This section gives the
sufficient conditions, including a single moment bound, and records what that form does not need.

### 9.1 One-sided odd-share control

**Hypothesis \(\mathrm H_q(C,A)\).** For all sufficiently large \(y\),
every \(1\le t<d(y)\) and every \(L(y)\)-bad word
\(w\in\{O,E\}^t\),
\[
\#\{n\in[w]_y:\ \mathrm{word}_{t+1}(n)=wO\}\ \le\ q\,\#[w]_y+\frac{y}{(\log y)^{A}} .
\]
(The depth-\(0\) cylinder is all odd starts, whose next letter is \(O\)
with share \(1\); the hypothesis starts at depth \(1\). As in
Section 8.3, no condition is imposed after an envelope crossing.)

**Theorem 9.1 (one-sided form).** Let \(0<q<\log 2/\log 3=0.6309\),
\(\mu=1-q\log_2 3>0\), \(C>1/\mu\), and
\(e_q(C)=2(C\mu-1)^2/(C(\log_2 3)^2\ln 2)\). Under
\(\mathrm H_q(C,A)\) with \(A>C+e_q(C)\), for every \(\varepsilon>0\) and
all large \(y\),
\[
\#\{n\ \text{odd}\in(y,2y]:\ n\notin R\}\ \le\ \frac y2\Bigl(\frac{\log 2y}{\log N_0}\Bigr)^{-(e_q(C)-\varepsilon)} .
\]
Hence \(e_q(C)>13/50\) implies the conjecture, by Theorem 7.2; the
least \(C\) is \(14\) at \(q=\tfrac12\), \(28\) at \(0.55\), \(132\) at
\(0.60\), \(866\) at \(0.62\) (at the machine-checked threshold \(3/8\):
\(16\), \(34\), \(175\), \(1201\); at the earlier \(1-\lambda^{**}\):
\(19\), \(41\), \(223\), \(1586\)).

*Proof.* Let \(n\) be uniform on the \(N_y=y/2+O(1)\) odd integers of
\((y,2y]\). Bounded endpoint factors are absorbed using
\(\varepsilon\)-slack. Follow
its actual word until the first prefix that is not \(L(y)\)-bad, and
after that crossing append synthetic letters \(E\). Let
\(\widehat{\mathcal F}_t\) be the filtration of these stopped words,
\(\widehat X_t\) the indicator that the synthetic next letter is \(O\),
and
\(\widehat u_t=(\log_2 3-1)+
\sum_{1\le s<t}(\widehat X_s\log_2 3-1)\). On a bad atom the stopped
word is the actual word, so \(\mathrm H_q\) applies; on a crossed atom
\(\widehat X_t=0\). Thus, with
\(\eta_t=(\mathbb P(\widehat X_t=1\mid\widehat{\mathcal F}_t)-q)^+\),
each bad atom \([w]\) has
\(\eta_t\le y(\log y)^{-A}/\#[w]\), while every crossed atom has
\(\eta_t=0\). There are at most \(2^t\) atoms, so
\(\mathbb E[\eta_t]\ll 2^t(\log y)^{-A}\) and
\(\mathbb E[\sum_{1\le t<d}\eta_t]\ll (\log 2y/\log N_0)^{C}(\log y)^{-A}\).
Since
\(\mathbb E[\widehat u_{t+1}-\widehat u_t\mid\widehat{\mathcal F}_t]
\le-\mu+\eta_t\log_2 3\),
the process
\(M_t=\widehat u_t-\widehat u_1-
\sum_{1\le s<t}\mathbb E[\widehat u_{s+1}-\widehat u_s
\mid\widehat{\mathcal F}_s]\)
is a martingale with increments in an interval of length \(\log_2 3\),
and \(\widehat u_d\le \widehat u_1+M_d-(d-1)\mu+
\log_2 3\sum_{s<d}\eta_s\). Fix
\(\kappa\in(0,1)\). If \(n\notin R\), the contrapositive of Lemma 8.1
gives \(u_t>-L\) for every \(t\le d\). Thus no crossing occurred,
\(\widehat u_d=u_d>-L\), and hence
either \(\log_2 3\sum_s\eta_s>\kappa(d-1)\mu\), an event of probability
\(O((\log y)^{C-A})\) by Markov's inequality, which is
\(o((\log y)^{-e_q(C)+\varepsilon})\) under the stated condition, or
\(M_d>a:=(1-\kappa)(d-1)\mu-L-\widehat u_1
\ge L((1-\kappa)C\mu-1)-\log_2 3\).
By the Azuma--Hoeffding inequality,
\(\mathbb P(M_d>a)\le\exp(-2a^2/((d-1)(\log_2 3)^2))\le 2^{-L(e_q^{(\kappa)}(C)-o(1))}\)
with \(e_q^{(\kappa)}(C)=2((1-\kappa)C\mu-1)^2/(C(\log_2 3)^2\ln 2)\to e_q(C)\)
as \(\kappa\to 0\). \(\square\)

Lean: exact form, in `formal/Problems/Juggler/FateOneSided.lean`, by
exponential moments and without the martingale, carrying out the
remark after Proposition 9.3. `OneSided.badMass` is the tilted mass
\(\sum_{|w|=t,\ w\ L\text{-bad}}\#[w]\,x^{o(w)}\) of the bad
cylinders of depth \(t\); bad words are prefix-closed
(`OneSided.LBad_of_LBad_append`) and a cylinder splits into its two
children (`OneSided.cylinder_split`), so \(\mathrm H_q\) on the bad
parents gives the affine recursion
\(\mathrm{badMass}(t+1)\le a_q\,\mathrm{badMass}(t)+(x-1)\,\mathrm{err}\,(2x)^t\),
\(a_q=1+(x-1)q\), for \(1\le t<d\) (`OneSided.badMass_succ_le`, under
`OneSided.OneSidedShare`, the hypothesis with its additive error
\(\mathrm{err}\) left symbolic), which unrolls to
\(xa_q^{t}N+(x-1)\,\mathrm{err}\,t\,(2x)^t\) (`OneSided.badMass_le`).
Lemma 8.1 and the Markov tilt put every odd failure in a bad cylinder
of depth \(d\) with at least \(p_Cd\) odd letters
(`OneSided.oddFailures_card_le_badMass`), so
`OneSided.one_sided_bound` is the bound
\((xa_q^{d-1}N+(x-1)\,\mathrm{err}\,(d-1)(2x)^{d-1})/x^{p_Cd}\) at
every \(y\ge1\), every \(d\ge\max(1,CL(y))\) and every tilt
\(x\ge1\), with no \(\varepsilon\); at the re-centring tilt
\(x=p_C(1-q)/(q(1-p_C))\) the main term is
\((x/a_q)\,N\,e^{-dD(p_C\|q)}\) (`OneSided.one_sided_bound_kl`, on
`OneSided.tilt_pow_ratio` and `tilt_exponent_eq_kl`), the exponent
\(e^{\rm Ch}_q(C)\) of Proposition 9.3. The error term carries
\((2x)^{d-1}/x^{p_Cd}\) where the Markov step above carries \(2^d\):
the tilt is paid on the error too, so its absorption into
\(y(\log y)^{-r}\) needs \(A>C(1+(1-p_C)\log_2x)+r\) in place of
\(A>C+r\). That absorption, the substitution
\(d=\lceil CL(y)\rceil\) and the displayed form with \(\varepsilon\)
are not formalized.

So no lower bound on odd shares and no vanishing error are needed: if
no \(L(y)\)-bad cylinder of depth below
\(28\log_2(\log 2y/\log N_0)\) sends more than \(55\%\) of its members
to an odd state, every positive integer reaches \(1\) (depth
\(34\log_2(\log 2y/\log N_0)\) using only Theorem 5.19).

**The barrier word (observation; this hypothesis is doubtful).** Unlike
\(\mathrm H(C,A)\), which is asked at the single depth \(d(y)\),
\(\mathrm H_q(C,A)\) is asked at *every* depth below \(d(y)\), and the
shallow depths carry an obstruction of the same shape as the
[absorbed-cylinder one](../problems/juggler_absorbed_cylinder.md).
Consider the *barrier word* \(w=OE^{t-1}\): one odd letter, then even
letters, with \(t\) maximal subject to badness. Its prefix walk is
\(u_s=\log_23-s\), so \(w\) is \(L(y)\)-bad exactly while
\(t<L(y)+\log_23\), and its depth is \(O(L(y))\), far inside the
window. On \([w]\) the map is the plain composite
\(G=\lfloor\cdot^{1/2}\rfloor^{t-1}\lfloor n^{3/2}\rfloor\), which is
monotone, and its value sits in \((N_0,N_0^2)\) at every scale — one
more even letter would cross the floor, one fewer leaves the value
below its square. So the image \(G((y,2y])\) is an interval of about
\(v_0\log v_0/\log y\) integers with \(v_0\) bounded, and it narrows to
a point: computed exactly, its width is
\(126,91,6760,3271,1609,799,3,3,2,3,1\) at
\(y=10^{7},10^{15},10^{25},10^{50},10^{100},10^{200},10^{435},10^{1000},
10^{2000},10^{5000},10^{20000}\). At \(y\approx10^{20000}\),
\(G(y+1)=G(2y)=4593\), an odd number: *every* member of \([OE^{13}]\)
has next letter \(O\), and an explicit \(20000\)-digit witness is given
in [the dossier](../problems/juggler_barrier_collapse.md). Then
\(\#[wO]=\#[w]\), so \(\mathrm H_q(C,A)\) requires
\((1-q)\#[w]\le y(\log y)^{-A}\), that is \(\#[w]\le10^{-88}y\) at
\(A=C=19\), against a fair share \(2^{-14}=6.1\cdot10^{-5}\): a deficit
of \(84\) orders of magnitude, growing without bound with \(y\). What
is not established is a lower bound on \(\#[w]\) — a bounded-depth
nested-floor parity count, not formalized and not proved here — so this
is not a refutation. But \(\mathrm H_q(C,A)\) should not be presumed to
hold, and Theorem 9.1 and its corollaries are stated conditionally for
that reason. The pressure and no-momentum forms of Section 9.2 are
untouched: they constrain an average over the live mass, not each
cylinder.

Lean: the consequence, in `formal/Problems/Juggler/FateOneSidedCorollary.lean`,
in the pattern of Corollary 8.4. `OneSided.OneSidedBound` is
\(\mathrm H_q(C,A)\) at a scale, `OneSided.oneSidedExponent` the
exponent \(e^{\rm Ch}_q(C)=CD(p_C\|q)/\ln2\) of Proposition 9.3, and
`OneSided.oddFailures_le_of_one_sided` the absorption of the exact
bound above into \(y(\log y)^{-e}\) for all large \(y\), every
\(e<e^{\rm Ch}_q(C)\) and \(A>C(1+\log_2x)+1+e\) at the re-centring
tilt \(x\), on Gibbs' inequality \(D(p_C\|q)\ge0\)
(`OneSided.klDiv_nonneg`) and \(e^{-dD}\le\Lambda^{-e^{\rm Ch}_q(C)}\),
\((2x)^{d-1}\le\Lambda^{C(1+\log_2x)}\) for \(d=\lceil CL(y)\rceil\)
(`OneSided.exp_le_rpow_scale`, `OneSided.pow_le_rpow_scale`). Then
Theorem 7.2: `OneSided.implies_conjecture_of_contagion` keeps the
contagion bound as a hypothesis at an exponent \(\lambda\) with
\(1-\lambda<e\), `OneSided.one_sided_implies_conjecture` discharges it
through the unconditional Theorem 5.3 at exponent \(\tfrac{13}{40}\), so
that \(\mathrm H_q(C,A)\) at all large scales with
\(e^{\rm Ch}_q(C)>\tfrac{27}{40}\) gives the conjecture with nothing else
assumed, and `OneSided.exact_share_implies_conjecture` is the remark
above with no error term, where \(A\) disappears. The condition on
\(A\) is sufficient, not the paper's \(A>C+e_q(C)\): the exact form
pays the tilt on the error and bounds \(d\) crudely. The numerical
forms, the least \(C\) at each \(q\), are not formalized.

### 9.2 The pressure form

Let \(N=y/2\), let \(\tau(n)=\min\{t\ge1:J^t(n)\le N_0\}\), with
\(\min\emptyset=\infty\), be the
entrance time into the floor, call \(n\) *live at depth \(t\)* if
\(\tau(n)>t\), and write \(o_t(n)\) for the number of odd letters among
\(n,J(n),\dots,J^{t-1}(n)\). By Lemma 8.1, \(\tau(n)>t\) implies
\(u_t(n)>-L(y)\). The stopping is essential: \(J(1)=1\) is odd, so an
orbit that has reached \(1\) has an all-\(O\) tail and the unstopped
odd count of every start in \(R\) grows linearly. For \(\theta>0\) put
\(a_\theta=\tfrac12(1+e^{\theta})\).

**Hypothesis \(\mathrm P_\theta(C)\) (live pressure).** For all
sufficiently large \(y\), with \(d=d(y)\),
\[
\frac1N\sum_{\substack{n\ \mathrm{odd}\in(y,2y]\\ \tau(n)>d}}e^{\theta\,o_d(n)}
\ \le\ a_\theta^{\,d}\,e^{o(d)} .
\]

**Theorem 9.2 (pressure form).** Assume \(\mathrm P_\theta(C)\) with
\(C\ge 5\) and \(\theta=\theta_C=\log\bigl(p_C/(1-p_C)\bigr)\). Then for
every \(\varepsilon>0\) and all large \(y\),
\[
\#\{n\ \mathrm{odd}\in(y,2y]:\ \tau(n)>d(y)\}
\ \le\ \frac y2\Bigl(\frac{\log 2y}{\log N_0}\Bigr)^{-(e(C)-\varepsilon)},
\]
the bound of Theorem 8.3. Hence \(\mathrm P_{\theta_C}(C)\) with
\(C\ge 14\) implies the conjecture using Theorem 1, and with
\(C\ge 16\) using only Theorem 5.19.

*Proof.* If \(\tau(n)>d\) then \(u_d>-L\), i.e. \(o_d\ge p_Cd\). Hence
\[
\#\{\tau>d\}\le\#\{\tau>d,\ o_d\ge p_Cd\}
\le e^{-\theta p_Cd}\sum_{\tau(n)>d}e^{\theta o_d(n)}
\le N\,e^{-\theta p_Cd}a_\theta^{\,d}e^{o(d)} .
\]
At \(\theta=\theta_C\), \(\theta p_C-\log a_\theta=D(p_C\|\tfrac12)\),
so the count is \(\le N\exp(-dD(p_C\|\tfrac12)(1-o(1)))\le N2^{-(e(C)-\varepsilon)L}\).
\(\square\)

Lean: exact form, in `formal/Problems/Juggler/FatePressure.lean`, on the
live weight of `LiveCountWeight` (starts in \(\{1,\dots,N\}\) that stay
above \(N_0\) for \(d\) steps). `livePressure` is
\(\sum_{n\ \mathrm{live}}x^{o_d(n)}\) as the generating function of the
live weight; `live_count_le_pressure` is the Markov step
\(\#\{\text{live},\,o_d\ge k\}\le\text{pressure}/x^k\);
`live_oddCount_ge` is Lemma 8.1 on live starts (\(o_d\ge p_Cd\) for
\(d\ge CL(N)\)); and `live_count_le_of_pressure` says: if the pressure
at the tilt \(x=p_C/(1-p_C)\) is at most \(Na_\theta^dE\), the live
starts number at most \(N\exp(-dD(p_C\|\tfrac12))E\), by the identity
\(a_\theta^d/x^{p_Cd}=e^{-dD(p_C\|1/2)}\) (`tilt_value`). The
substitution \(E=e^{o(d)}\) and \(d=\lceil CL\rceil\) that gives the
displayed bound is not formalized.

For \(1\le t<d\) let \(\mu_{\theta,t}\) be the probability measure on
the starts live at depth \(t\) with density proportional to
\(e^{\theta o_t(n)}\), and let
\(s_\theta(t)=\mu_{\theta,t}(J^t(n)\ \text{odd})\) be the *tilted odd
share*: the probability that the next letter is \(O\) when odd-heavy
live prefixes are up-weighted exponentially. If the live set is
empty, define \(s_\theta(t)=0\); subsequent live moments are then
zero.

**Hypothesis \(\mathrm M_{\theta,q}(C)\) (no momentum).** For all large
\(y\), \(\sum_{t=1}^{d(y)-1}\bigl(s_\theta(t)-q\bigr)^+=o(d(y))\).

**Proposition 9.3.** \(\mathrm M_{\theta,1/2}(C)\) implies
\(\mathrm P_\theta(C)\). More generally, for \(0<q<1\) and a fixed \(\theta>0\),
\(\mathrm M_{\theta,q}(C)\) gives
\[
\#\{\tau>d\}\le
N\exp\{-d[\theta p_C-\log(1-q+qe^\theta)-o(1)]\}.
\]
If \(0<q<p_C<1\) and the hypothesis is assumed at the optimizing tilt
\(\theta=\theta_{C,q}:=\log\frac{p_C(1-q)}{q(1-p_C)}\), this becomes
\(N\exp(-dD(p_C\|q)(1-o(1)))\), with exponent
\(e_q^{\rm Ch}(C)=C\,D(p_C\|q)/\ln 2\), at least the Azuma exponent of
Theorem 9.1. Its least \(C\) at \(q=0.5,0.55,0.60,0.62\) is
\(14,27,128,820\) at the threshold \(13/50\) (\(16,34,168,1135\) at
\(3/8\); \(19,41,214,1496\) at the earlier \(1-\lambda^{**}\)).

*Proof.* Dropping the condition \(\tau>t+1\) in favour of \(\tau>t\)
only enlarges the sum, so
\[
\sum_{\tau>t+1}e^{\theta o_{t+1}}\le\sum_{\tau>t}e^{\theta o_{t+1}}
=\Bigl(\sum_{\tau>t}e^{\theta o_t}\Bigr)\bigl(1+(e^{\theta}-1)s_\theta(t)\bigr).
\]
With \(a_{\theta,q}=1+(e^\theta-1)q\) and \(c_\theta=(e^\theta-1)/a_{\theta,q}\),
\(1+(e^\theta-1)s\le a_{\theta,q}\exp\bigl(c_\theta(s-q)^+\bigr)\).
Telescoping from \(t=1\) gives
\(\sum_{\tau>d}e^{\theta o_d}\le Ne^{\theta}a_{\theta,q}^{\,d-1}\exp\bigl(c_\theta\sum_{t<d}(s_\theta(t)-q)^+\bigr)\),
which is \(\mathrm P_\theta\) at \(q=\tfrac12\). For general \(q\), the
exponential Markov step gives
\(\theta p_C-\log a_{\theta,q}\) at the same fixed \(\theta\). Assuming
\(\mathrm M_{\theta,q}\) at
\(\theta=\log\frac{p_C(1-q)}{q(1-p_C)}\) gives \(D(p_C\|q)\).
\(\square\)

Lean: `weightGen_succ_le_share` (the one-depth step),
`one_add_le_exp_excess`, `weightGen_le_pressure` (the telescoped bound)
and `count_le_pressure` (the exponential Markov step), in
`formal/Problems/Juggler/TiltedShare.lean`, on the word-weight
framework of `RateFreeDensity`; `tilt_exponent_eq_kl` is the identity
at the re-centring tilt.

Lean: the consequences of Theorem 9.2 and Proposition 9.3, in
`formal/Problems/Juggler/FatePressureCorollary.lean`, in the pattern of
Corollary 8.4. A failure never enters the floor, so the odd failures of
\((y,2y]\) are live starts of \(\{1,\dots,2y\}\) at every depth
(`Pressure.oddFailures_subset_live`); `Pressure.PressureBound` is
\(\mathrm P_\theta(C)\) at a scale with \(e^{o(d)}\) quantified as
\((\log y)^\varepsilon\), and `Pressure.NoMomentumBound` is
\(\mathrm M_{\theta,q}(C)\) on the live weight at the re-centring tilt
with the \(o(d)\) as \(\delta d\). The exact forms above bound the
failures by \(2y\,e^{-dD}(\log y)^\varepsilon\), with
\(D=D(p_C\|\tfrac12)\) for the pressure form and
\(D=D(p_C\|q)-c_x\delta\), \(c_x=(x-1)/a_{x,q}\), for the no-momentum
form (`Pressure.momentumExponent`); the shared absorption
`Pressure.absorb` turns that into \(y(\log y)^{-e}\) for every
\(e<CD/\ln2-\varepsilon\) and all large \(y\)
(`Pressure.oddFailures_le_of_pressure`,
`Pressure.oddFailures_le_of_noMomentum`). Then Theorem 7.2, with the
contagion bound as a hypothesis (`Pressure.pressure_conj_of_contagion`,
`Pressure.noMomentum_conj_of_contagion`) or discharged through the
unconditional Theorem 5.3 at exponent \(\tfrac{13}{40}\)
(`Pressure.pressure_implies_conjecture`,
`Pressure.noMomentum_implies_conjecture`): either hypothesis at all
large scales, with its exponent above \(\tfrac{27}{40}\), gives the
conjecture with nothing else assumed. The numerical forms are not
formalized.

### 9.3 Scope of the moment criterion

**(a) Any \(o(\log\log y)\) initial depths are free.** A letter
contributes a factor at most \(e^\theta\) to the moment, so bias —
however extreme — at any set of depths of size \(o(d(y))\) is absorbed
by the \(e^{o(d)}\). In particular the depth-five split (Paper B's
Corollaries 4.10 and 4.12) and every split to any fixed depth, or to depth
\(s_0(y)\) for any \(s_0=o(\log\log y)\), is irrelevant to the
reduction.

**(b) A tower comparison in a model population.** Suppose a
model cylinder \(O^t\) has size \(N\beta^{t-1}\). Its moment
relative to the fair *reference* total
\(Ne^\theta a_\theta^{t-1}\) is
\((\beta e^\theta/a_\theta)^{t-1}\). This ratio decays precisely
when \(\beta<(1+e^{-\theta})/2\), about \(0.836\) at
\(\theta_{19}\approx0.396\). Its count alone exceeds the reference
survival exponent only when \(\beta>2^{-e(C)/C}\), about \(0.981\)
at \(C=19\).

These are algebraic comparisons to a reference mass. They do not
bound \(s_\theta(t)\) in an actual stopped population, whose total
live mass may be much smaller. A model tower below \(0.836\) is
therefore not, by itself, a proof of the no-momentum hypothesis.

**(c) One-sidedness and aggregation.** \(\mathrm M_{\theta,q}\) bounds the accumulated positive excess
of a weighted average over depths. Under-populated odd continuations
can offset excess within the same depth; over-populated cylinders
contribute in proportion to their tilted weight. In Walsh terms,
\(e^{\theta X_s}=a_\theta+b_\theta(-1)^{J^s(n)}\) with
\(b_\theta/a_\theta=-\tanh(\theta/2)\), so the unstopped moment is
\[
\frac1N\sum_ne^{\theta o_d(n)}=a_\theta^{\,d}\Bigl(1+\sum_{\emptyset\ne T}(-\tanh\tfrac\theta2)^{|T|}\frac{W_T}{N}\Bigr),
\qquad W_T=\sum_n\prod_{s\in T}(-1)^{J^s(n)} :
\]
Walsh sums of high order are exponentially down-weighted
(\(\tanh(0.198)=0.196\) per letter), whereas \(\mathrm H(C,A)\) asks for
a separate supremum bound on each \(L(y)\)-bad cylinder at the target
depth.

**(d) Other sufficient statistics.** The proof of Theorem 9.1
also works if the odd-share bound fails only on bad atoms of total
probability \(O((\log y)^{-B})\) at each depth, with
\(B>e_q(C)\): the expected accumulated excess is
\(O(d(\log y)^{-B})\), and Markov's inequality absorbs it.

Lean: this variant, on the exponential-moment proof, in
`formal/Problems/Juggler/FateOneSidedAtoms.lean`.
`OneSided.OneSidedShareExc` allows at each depth an exceptional set
of words of total cylinder mass at most \(\mathrm{exc}\) on which the
share bound may fail; an exceptional bad atom sends at most its whole
mass to its odd child, which costs \((x-a_q)\#[w]x^{o(w)}\) in the
tilted mass, so the recursion of Theorem 9.1's Lean proof reads
\(\mathrm{badMass}(t+1)\le a_q\,\mathrm{badMass}(t)+(x-1)\bigl(\mathrm{err}\,(2x)^t+(1-q)\,\mathrm{exc}\,x^t\bigr)\)
(`OneSided.badMass_succ_le_exc`), with the exact bound
`OneSided.one_sided_bound_exc` and its re-centred form
`OneSided.one_sided_bound_kl_exc`. With
\(\mathrm{exc}=y(\log y)^{-B}\) the absorption
(`OneSided.oddFailures_le_of_exc`) needs \(B>C\log_2x+1+e\), against
\(A>C(1+\log_2x)+1+e\) for the error: the exceptional atoms are not
doubled at each depth. `OneSided.exc_implies_conjecture` runs this
weakest one-sided form to the conjecture with nothing else assumed
when \(e^{\rm Ch}_q(C)>\tfrac{27}{40}\), and
`OneSided.exc_conj_of_contagion` with the contagion bound as a
hypothesis. The condition on \(B\) is sufficient and not the
\(B>e_q(C)\) of the Markov absorption above, which is not restated.

For comparison, let \(D(w)=\#[wO]-\tfrac12\#[w]\),
\(\mathcal C_t=\sum_{|w|=t}\#[w]^2\), and let \(W_T\) be the
Walsh sums on the same full set of odd starts. Parseval gives the
exact identities
\[
\sum_w D(w)^2=2^{-t-2}\sum_{S\subseteq\{0,\ldots,t-1\}}
 |W_{S\cup\{t\}}|^2
 =\tfrac12\mathcal C_{t+1}-\tfrac14\mathcal C_t.
\]
Lean: the second equality,
\(\sum_wD(w)^2=\tfrac12\mathcal C_{t+1}-\tfrac14\mathcal C_t\), is
`CylinderEnergy.sum_bias_sq` in
`formal/Problems/Juggler/FateCylinderEnergy.lean`, for an arbitrary
finite set of starts; it rests on the cylinder splitting
\(\#[w]=\#[wE]+\#[wO]\) (`CylinderEnergy.wordCount_split`) and is
otherwise the algebra of
\((b-\tfrac{a+b}2)^2=\tfrac{a^2+b^2}2-\tfrac{(a+b)^2}4\). The
Parseval equality with the Walsh sums is not formalized; no Walsh
transform appears in that file.

An additional quantitative bound on these sums can supply an
exceptional-atom estimate. No rate-independent equivalence with
the restricted bad-cylinder hypothesis is asserted. Full-population
fair collision bounds also face the absorbed-cylinder obstruction
of Section 8.3.

Lean: the supply, in `formal/Problems/Juggler/FateEnergyAtoms.lean`,
for the energy of the \(L(y)\)-bad words. `Energy.badEnergy` is
\(\sum_{w\ \text{bad}}D(w)^2\) over the odd starts of \((y,2y]\), and
`Energy.biasEnergy` the sum over all words, equal to
\(\tfrac12\mathcal C_{t+1}-\tfrac14\mathcal C_t\) (`Energy.biasEnergy_eq`,
on `CylinderEnergy.sum_bias_sq`). A bad atom violating
\(\#[wO]\le q\#[w]\) for \(q>\tfrac12\) has \(D(w)>(q-\tfrac12)\#[w]\),
so the squared masses of the bad violators sum to at most the bad
energy over \((q-\tfrac12)^2\), and Cauchy--Schwarz over at most
\(2^t\) atoms gives
\(\bigl(\sum_{\text{bad violators}}\#[w]\bigr)^2\le2^t\,\mathrm{badEnergy}/(q-\tfrac12)^2\)
(`Energy.mass_violators_le`). Hence
\(\mathrm{badEnergy}_t\le(q-\tfrac12)^2\,\mathrm{exc}^2/2^t\) at every
depth \(1\le t<d\) is the one-sided hypothesis with exceptional atoms
of mass \(\mathrm{exc}\) and no error term
(`Energy.oneSidedShareExc_of_energy`), and
`Energy.energy_implies_conjecture` runs it to the conjecture: the bad
energy bound with \(\mathrm{exc}=y(\log y)^{-B}\) at the depths below
\(\lceil CL(y)\rceil\) at all large scales (`Energy.EnergyBound`),
\(\tfrac12<q<p_C\), \(B>C\log_2x+1+e\) and \(\tfrac{27}{40}<e<e^{\rm Ch}_q(C)\),
and nothing else. The restriction to bad words is forced: the
unrestricted energy (`Energy.badEnergy_le_biasEnergy`) is dominated by
absorbed orbits, whose cylinders are fully biased. The exact
enumeration of Section 11 then finds the bad energy itself at its
worst-case value \(\tfrac14\sum_{w\ \text{bad}}\#[w]^2\) from depth
\(16\)--\(20\) at every computable scale, because bad words that have
dipped to a bounded value collapse onto single deterministic futures;
the reduction stands, the hypothesis has no numerical support, and the
per-cylinder forms it feeds inherit the warning.

Lean: the collapsed component, in
`formal/Problems/Juggler/FateCollapse.lean`, the exact layer of the
observation that the collapsed mass, taken as a whole, is nearly fair.
For a finite set of starts, `Collapse.fiber` counts the starts whose
\(t\)-th iterate is a given value, and the next-letter bias of the
starts whose iterate lands in a window \([a,b]\) of values
(`Collapse.windowBias`) is the alternating sum
\(-\sum_{v=a}^{b}(-1)^v\,\mathrm{fiber}(v)\) (`Collapse.windowBias_eq_sum`),
hence at most the total variation of the fiber profile over the window
plus one fiber (`Collapse.abs_windowBias_le`, by summation by parts).
One step of the map sums fibers over preimages, the even numbers of
\([v^2,(v+1)^2)\) plus at most one odd preimage (`Collapse.fiber_succ_eq`,
on Lemma 3.1's even block in fiber form), and the even branch smooths:
with the depth-\(t\) profile between \(m_v\) and \(M_v\) on the double
block \([v^2,(v+2)^2)\), consecutive block sums differ by at most
\((v+1)(M_v-m_v)+2M_v\) (`Collapse.blockSum_sub_le`). Hence
`Collapse.collapse_bias_le`: the bias of a collapsed window at depth
\(t+1\) is at most \(\sum_v\bigl((v+1)(M_v-m_v)+2M_v\bigr)\) plus twice
the mass arriving through odd preimages plus one fiber. With a smooth
profile, \(M_v-m_v\) of order \(\bar f/v\) on a block of size
\(\bar fv\), the first term is \(O(\bar f)\) per value against a window
mass of \(\bar fv\) per value: the collapsed mass entering through the
even branch is fair up to a relative \(O(1/v)\), and the excess share
of the moment criterion sits in the odd branch and in the high walkers.
Runs of even letters are self-smoothing: a sandwich
\(m\le\mathrm{fiber}(t,\cdot)\le M\) on \([v^2,(v+1)^2)\) with odd branch
at most \(P\) gives \(vm\le\mathrm{fiber}(t+1,v)\le(v+1)M+P\)
(`Collapse.fiber_succ_sandwich`), so after two even steps the bias of
a window at depth \(t+2\) is bounded by the depth-\(t\) sandwich with
the relative oscillation not amplified and a loss of a relative
\(O(1/w)\) at the final scale (`Collapse.collapse_bias_two_step`);
iterated, the relative oscillation at the end of an even run is the
one at its start plus \(O(1/w)\) at the last scale. What the even run
cannot repair is the oscillation it starts with, the profile after
the preceding odd run: its first even step is the share law of
Section 4, and its block average is Proposition 4.4. Not here: any
bound on the variation of a fiber profile beyond that propagation,
and the parity of the odd-preimage mass, which is the share law at
bounded scale.

**(e) Bounded-depth statistics and the walk model.** Fix
\(k\). The probability measure on parity words that is fair to depth
\(k\) and all-\(O\) afterwards satisfies every cylinder-count
statement of depth \(\le k\) exactly, and under it a positive
proportion of model walks never crosses the barrier. An argument for the Tao-type
bound that used only depth-\(\le k\) cylinder statistics of the
Juggler map and the walk logic would prove the same bound for that
measure. Thus finite-depth statistics plus the envelope walk alone are
insufficient. This model example does not rule out a proof using
additional arithmetic properties of the Juggler map.

### 9.4 Where the difficulty lies

\(\mathrm P_\theta(C)\) says that the exponentially tilted distribution
of live parity words of length \(d\asymp\log_2\log y\) has the fair
pressure \(\log a_\theta\): odd-heavy live words — those with about
\(e^\theta/(1+e^\theta)\approx 60\%\) odd letters, the words the tilt
selects — are not over-populated at an exponential rate in \(d\).
Typical such words contain odd runs of length \(\ge 4\), so the nested
towers of height \(\ge 4\) that stop Paper B at depth five sit inside
almost every relevant cylinder; but no individual cylinder is required
to split fairly, only the tilted average over the \(\approx 2^{0.97d}\)
typical cylinders at each depth. This is a statement about averaging
over cylinders at unbounded depth — a mean over characters, not a
supremum — of a kind for which analytic number theory sometimes has
tools where pointwise bounds fail. We record the question and do not
pursue an analytic approach here.

### 9.5 Scale-averaged pressure is sufficient

A cumulative pressure estimate suffices even when individual scales
have large spikes. Fix \(C>1\), \(\theta>0\), \(0<q<1\), and
\(\eta\ge0\). Put \(a=1-q+qe^\theta\),
\(r=C(\theta p_C-\log a)/\log2\), and at \(y=2^k\) define
\[
Z_k=\sum_{\substack{n\text{ odd}\in(2^k,2^{k+1}]\\
                  \tau(n)>d(2^k)}}e^{\theta o_{d(2^k)}(n)},\qquad
\rho_k=\frac{Z_k}{2^{k-1}a^{d(2^k)}}.
\]
Choose a fixed \(k_0\) above the verified target.

**Theorem 9.4 (scale-average criterion).** Suppose, for every
\(\varepsilon>0\),
\[
\sum_{k=k_0}^{K}\rho_k\ll_\varepsilon K^{1+\eta+\varepsilon}.
\]
If \(r-\eta>13/50\), Theorem 5.20 implies universal termination;
with the machine-checked Theorem 5.19 in its place, \(r-\eta>3/8\)
suffices, and with the elementary Lean baseline, \(r-\eta>103/203\).
The cumulative arithmetic bound itself remains open.

*Proof.* A nonterminating start remains live and has
\(o_d>p_Cd\). Exponential Markov therefore bounds its odd
reciprocal mass in the \(k\)-th block by
\(O(\rho_k(k+1)^{-r})\). Summing the cumulative hypothesis on
dyadic groups of indices gives
\[
\sum_{k\le K}\rho_k(k+1)^{-r}=O(K^\beta)
\quad\text{for every }\beta>\max(1+\eta-r,0).
\]
The logarithmic boundary case is absorbed by the strict inequality.
The even-tree argument of Theorem 7.2 bounds total failure mass by
\(O((\log X)^\beta\log\log X)\). Choose
\(\max(1+\eta-r,0)<\beta<37/50\) and use Theorem 5.20 to
contradict a nonempty failure class. For the other two thresholds
replace 37/50 by 5/8 and by 100/203. \(\square\)

The baseline implication, with the actual stopped Juggler weights,
is `ScaleAverage.pressure_average_conjecture` in
`FateScaleAverage.lean`; its fourteen-theorem audit is separate from
the historical Paper C audit. The formal corollary
`ScaleAverage.pressure_average_conjecture_of_ooee` proves the 3/8
implication with `OOEEProductionBound` explicit, and
`FateOOEEWeighted.pressure_average_conjecture` discharges that premise,
so the 3/8 implication is kernel-checked with no contagion-side
hypothesis. The
reusable proof accepts any supplied contagion exponent; the 13/50
implication, through Theorem 5.20, is written. No estimate of the actual
cumulative pressure is asserted.

## 10. The free term and limits of the reductions

### 10.1 The free term is the infinite-depth live mass

Recall the free term \(\psi_F\) of (6.1). For odd \(n\),
\(n\in F\iff\lfloor n^{3/2}\rfloor\in F\) (Theorem 6.1), and
\(n\in F\iff\tau(n)=\infty\) since \([1,N_0]\subseteq R\). Let
\(\mathbb P^{\log}_x\) be the \(1/n\)-weighted measure on the odd
\(n\in(\sqrt x,x]\).

**Proposition 10.1 (normalized live limit).** Put
\[
q_{OO}(t)=\frac8t
 \sum_{\substack{\sqrt x<n\le x\\ \mathrm{word}_2(n)=OO}}\frac1n,
\qquad x=e^t.
\]
Whenever the conditioning set is nonempty,
\[
\psi_F(t)=q_{OO}(t)\lim_{d\to\infty}
 \mathbb P_x^{\log}(\tau(n)>d\mid\mathrm{word}_2(n)=OO).
\tag{10.1}
\]
The limit is decreasing. For large \(t\),
\(q_{OO}(t)=1+O(e^{-\delta t})\) for some \(\delta>0\).
If a hypothesis in Sections 8--9 gives a live-start bound with
rate \(r>0\), then, for every \(0<\varepsilon<r\),
\[
\psi_F(t)\ll_\varepsilon
 \left(\frac{t}{2\log N_0}\right)^{-(r-\varepsilon)}.
\tag{10.2}
\]
For the one-sided and no-momentum forms, the same proofs bound
live starts as well as failures. The rate is the case-dependent
rate in Theorem 4.

*Proof.* At fixed \(x\) the conditioning set is finite, and
\(F=\{n:\tau(n)=\infty\}\). Continuity for decreasing events
gives (10.1), including its normalization factor. The depth-two
parity estimate for odd starts gives \(OO\)-count
\(y/4+O(y^{1-\delta'})\) on dyadic blocks. Partial summation,
or the same exponential-sum bound on initial subintervals, gives
the asserted reciprocal-mass asymptotic for \(q_{OO}\).

Cover \((\sqrt x,x]\) by downward dyadic blocks, allowing one
partial block at the lower end. On \((y,2y]\) the reciprocal mass
of live starts is at most their count divided by \(y\), hence
\(O((\log y/\log N_0)^{-(r-\varepsilon)})\).
There are \(O(t)\) blocks and \(\log y\ge t/2-O(1)\).
Multiplication by \(8/t\), the definition of \(\psi_F\), proves
(10.2). No equality between an unweighted block ratio and its
reciprocal-weighted ratio is used. \(\square\)

This connects the free term with live counts. The decreasing limit
does not provide a rate of convergence in depth; the finite-depth
estimates remain additional sufficient hypotheses.

### 10.2 What the upper recursion proves

Equations (6.1) and the fiber upper bound give, for large \(t\),
\[
\varphi_F(t)\le\tfrac12\varphi_F(t/2)
 +\tfrac13\varphi_F(3t/4)+\tfrac14\psi_F(t)+O(e^{-\delta t}).
\tag{10.3}
\]
The coefficient is \(1/3\) with the proved upper share; the ideal
fiber model would replace it by \(1/4\). If \(c\) denotes either
coefficient, the homogeneous exponent \(e_c>0\) is the root of
\(\tfrac12 2^{e_c}+c(4/3)^{e_c}=1\). Numerically it is
\(0.3391\) for \(c=1/3\), and
\(1-\lambda_{\mathrm{ideal}}=0.5073\) for \(c=1/4\).
These values describe the upper comparison, not a proved exact
decay rate of a nonempty failure set.

**Corollary 10.2 (upper comparison).** If \(\psi_F(t)=O(t^{-r})\)
for some \(r>0\), then
\(\varphi_F(t)=O(t^{-a})\) for every
\(0<a<\min(r,e_c)\), using \(c=1/3\) in (10.3).
The ideal model has the analogous assertion with \(c=1/4\).
The upper inequality alone does not imply \(F=\emptyset\).

*Proof.* For such \(a\),
\(h=\tfrac12 2^a+c(4/3)^a<1\). Choose a large initial scale
\(T\) and then \(K\) so that \(\varphi_F(t)\le Kt^{-a}\) on
\([T/2,T]\), and so that the forcing in (10.3) is bounded by
\((1-h)Kt^{-a}\) for \(t\ge T\). Induction on intervals
\([T,(4/3)^jT]\) proves the bound. At the endpoint \(a=e_c\)
there is no slack; in particular an endpoint estimate cannot be
inferred by the same argument. A positive multiple of
\(t^{-e_c}\) satisfies the homogeneous comparison on a tail,
so that comparison alone does not force the function to vanish.
The lower contagion estimates and this upper comparison do not
establish a matching asymptotic. \(\square\)

### 10.3 The depth-uniformity budget

Section 9.3(e) limits what fixed-depth statistics plus the
envelope walk alone can prove. The form of Theorem 8.3 says how
uniform that information must be *along the cylinder-count route*.

**Proposition 10.3 (depth-uniformity budget).** Suppose the
available cylinder discrepancy bound is
\[
\left|\#[w]_y-2^{-(d-1)}y/2\right|
 \le K2^{\kappa d}y^{1-\delta_0 2^{-cd}},
\]
for the relevant bad words, with constants \(K,\delta_0,c>0\),
\(\kappa\ge0\), and a scale threshold independent of \(d\).
At \(d=C\log_2\log y+O(1)\), the resulting error majorant
after summing over at most \(2^d\) words is
\(o(y(\log y)^{-r})\) for every fixed \(r>0\) if and only if
\(cC<1\).

*Proof.* Divide the error majorant by \(y(\log y)^{-r}\) and
take logarithms. The result is
\[
O(1)+((\kappa+1)C+r)\log\log y
 -\Theta((\log y)^{1-cC}).
\]
It tends to \(-\infty\) exactly when \(cC<1\).
If \(cC\ge1\), this majorant is insufficient; the actual error
may still be much smaller. Without uniform control of the
prefactor and the scale threshold, a bound at every fixed depth
would not justify any conclusion at growing depth. \(\square\)

At \(C=14\), the least constant for Theorem 1's threshold, this
requires the saving exponent to lose less than a factor
\(2^{1/14}=1.051\) per depth; at \(C=28\), the one-sided constant at
\(q=0.55\), \(2^{1/28}=1.025\).
Weyl differencing loses a factor \(2^{c}\) with \(c\ge1\) per
differencing (Paper B's \(OOOEE\) estimate goes
\(\tfrac{31}{32}\to\tfrac{63}{64}\to\tfrac{127}{128}\) through two
differencings, \(c=1\) each), and with such a loss the cylinder-count
route reaches depth \(\approx\log_2\log y\) — one unit of \(L(y)\),
enough for the all-\(E\) word to reach the floor, not for the
Chernoff tail, which needs \(C\ge 5\) units. The proposition is
narrow by design: it concerns methods whose only available error
estimate deteriorates exponentially in the depth and are used through
the per-cylinder count of Theorem 8.3. A method that organizes its
errors differently, that proves a polylogarithmic relative saving
uniformly in the depth (as \(\mathrm H(C,A)\) asks), or that addresses
the pressure statement directly is not covered by it.

## 11. Numerical observations

The following archived numerical experiments accompany the theorems.
Orbit steps and integer counts use exact arithmetic; phases, weighted
statistics and fair-coin comparisons use floating-point arithmetic.
Random samples use fixed seeds
(`research.juggler_sequence.fate_contagion`,
`research.juggler_sequence.tao_reduction`; artifacts in Appendix B),
they do not establish asymptotic estimates and they enter no analytic proof. Detailed tables are kept
in the repository notes [14].

*Fibers, blocks, closure.* Over \(3375\le m<10^5\) and spot ranges at
\(10^6\) and \(10^7\), the mean of \(G_m/H_m\) is \(0.5000\), \(0.5004\),
\(0.5027\); the minimum on good fibers is \(0.328\) (\(m=1003635\),
\(\alpha_m\approx\tfrac13\)); no good fiber falls below
\(\tfrac13H_m-2\). On
the blocks \(m'\in[20,60)\cup[200,230)\cup[1000,1010)\cup\{3000,5000\}\)
the deviation of \(|U(m')|\) from its main term is at most
\(0.72\sqrt{|I(m')_{\rm odd}|}\), i.e. square-root scale.

*The share law and the extremes.* A complete census of \(\Phi(m)\) for
\(m\le2\cdot10^5\) (`research.juggler_sequence.oe_fiber_share`) finds
\(2481\) fibers with \(G_m=0\) and \(2508\) with \(G_m=H_m\), and
\(H_m\ge1\) throughout. The mean of \(G_m/H_m\) is \(0.498\) on the
decade \([10^2,10^3)\) and \(0.500\) on every decade above it, and the
empty rate falls
\(8.0,\,3.0,\,1.35,\,0.90\) per cent over the decades from \(10^2\) to
\(2\cdot10^5\), tracking \(1/H_m\). The archived sampling code uses \(\widehat\beta_m=\alpha_mH_m\),
whereas Lemma 4.5 uses \(\beta_m=\alpha_m(H_m-1)\).
Near \(10^6\), \(432\) fibers with
\(|\widehat\beta_m|\le1.2\) give mean absolute model error
\(0.0195\) against \(1/H_m=0.015\), and every extreme fiber found has
\(\widehat\beta_m\in[-0.79,0.15]\), inside the model window of Corollary 4.6(2). The
extremes sit \(\asymp m^{1/3}\) apart as Remark 4.8 predicts: in
\(m\in[10^5,1.2\cdot10^5)\), where that period is \(46.4\), their median
spacing is \(48\) and \(244\) of \(306\) gaps are one period. Empty
fibers occur singly or in adjacent pairs and never in threes. The
observed empty rate exceeds the \((25/108)/H_m\) of Corollary 4.6(3) by
about \(1.4\), and the sample is consistent with a discretization effect: of the \(297\) empty fibers in
\([10^5,1.3\cdot10^5)\), \(174\) have \(S(\widehat\beta_m,\theta_m)=0\) while
\(123\) have \(S>0\) and miss only because the fiber samples it at
\(31\) points. Consistently, the ratio falls \(1.49,\,1.44,\,1.36\)
across the last three decades. The closure
of the Lean-verified seed \([1,260]\) under the two productions of
Section 3, computed exactly up to \(10^9\), has density between
\(0.45\) and \(0.49\) on the complete dyadic blocks
\((2^k,2^{k+1}]\), \(16\le k\le28\). The last reported
block is truncated to \((2^{29},10^9]\); its density is \(0.4529\), against \(0.25\) for the \(E\)-only closure, and its
realized recursion coefficients at \(10^9\) are \(0.9998\) for \(E\)
(theory \(1\)) and \(0.3332\) for \(OE\) (reference \(\tfrac13\)).
The separate decomposition sample at \(x=10^6\) has
\(OO\)-type share \(0\) against reference share \(0.2987\).
This finite closure is not a two-way closed fate class; its omitted
production illustrates the \(OO\) term without establishing
an asymptotic property of \(F\).

*Survival above the certified floor.* Because every
\(n\le N_0=3.5\cdot 10^8\) reaches \(1\), the statistic "\(J^t(n)\le N_0\)
for some \(t\le d\)" is a finite computation, and its complement is the
live set of Theorem 8.3 (contained in the envelope-bad cylinders). For random odd starts in \((y,2y]\), the
fraction still above \(N_0\) after \(d\) steps is compared with the
odd-start fair-coin survival
\(\Pr[u_t>-L(y)\ \forall t\le d\mid u_1=\log_2 3-1]\):

| \(y\) | \(L(y)\) | \(d=11\) | \(d=21\) | \(d=31\) | \(d=36\) |
|---|---|---|---|---|---|
| \(10^{12}\) | \(0.526\) | \(0.221/0.221\) | \(0.082/0.084\) | \(0.037/0.038\) | \(0.027/0.028\) |
| \(10^{15}\) | \(0.841\) | \(0.251/0.267\) | \(0.100/0.106\) | \(0.044/0.047\) | \(0.032/0.035\) |
| \(10^{20}\) | \(1.249\) | \(0.295/0.309\) | \(0.135/0.138\) | \(0.068/0.068\) | \(0.049/0.049\) |
| \(10^{30}\) | \(1.826\) | \(0.442/0.439\) | \(0.175/0.175\) | \(0.098/0.095\) | \(0.075/0.070\) |
| \(10^{50}\) | \(2.558\) | \(0.554/0.554\) | \(0.267/0.264\) | \(0.148/0.143\) | \(0.101/0.097\) |

Entries are empirical/fair at the depths retained in the archived
record: \(40000\) starts at \(10^{12},10^{15},10^{20}\), and
\(20000\) at \(10^{30},10^{50}\). The sampler draws integers in
\((y,2y]\) and rounds even draws up to the next odd integer; this
differs from uniform odd sampling only at the two endpoints, with
total variation \(1/y\). A resource cap is conservatively recorded
as no observed descent, so empirical survival is an upper bound
for the sampled live fraction when a cap is reached.

The separate pressure runs use \(40000\) starts at each of
\(10^{20},10^{30},10^{50}\), with no capped orbits. At these scales,
the recorded extrema of \(s_\theta(t)\) over \(1\le t\le40\)
and \(\theta\in\{0.396,0.6\}\) are approximately \(0.4728\)
and \(0.5337\). At the four recorded depths \(10,20,30,40\),
the live-moment ratio to the fair-coin comparison ranges from
\(0.9521\) to \(1.0812\), using outward rounding.
The archived \(10^{12}\) pressure run has one capped orbit;
its unknown later letters are omitted by that estimator. It is
excluded from this pressure comparison and cannot certify an
upper bound on the full live moment. These finite observations
do not establish the hypotheses of Section 9 at depths tending
to infinity.

*Exact cylinder energies (observation).* An exact enumeration of every
odd start of \((y,2y]\) to depth \(30\) at \(y=10^4,10^5,10^6,10^7\)
(`research.juggler_sequence.cylinder_energy_measure`, no sampling)
records the bias energy \(\sum_wD(w)^2\) over all words, over the
\(L(y)\)-bad words and over the live starts, against the fair-coin value
\(N/4\) and the worst case \(\tfrac14\sum_w\#[w]^2\). Over all words the
worst case is reached by depth \(16\)--\(22\) at every scale, the
absorbed-cylinder obstruction of Section 8.3 in numbers. Over the
\(L(y)\)-bad words it is reached by depth \(16\)--\(20\) as well, on
cylinders of up to \(11939\) members at \(10^7\): a bad word whose walk
has dipped near \(-L(y)\) has collapsed onto a bounded value above the
floor, and its cylinder's later letters are the deterministic orbit of
that value. The mass of bad atoms violating \(\#[wO]\le0.55\,\#[w]\)
falls with the scale in the dense window (\(0.47\), \(0.26\), \(0.12\),
\(0.05\) of the bad mass at depth \(10\)) and is a constant \(0.42\)--\(0.49\)
at depth \(20\). These finite observations do not test the hypotheses
of Sections 8--10 at their own scales; they show that their
per-cylinder forms live, at every computable scale, in a regime where
cylinders are parity-constant.

*The excess of the bad cylinders (observation).* The same enumeration
measures the quantity \(\mathrm H_q(C,A)\) bounds, namely
\(\max_{w\ \text{bad}}(\#[wO]-q\#[w])\), at every depth of the
hypothesis's own window \(1\le t<d(y)\)
(`research.juggler_sequence.bad_cylinder_excess`). At these scales the
additive error is inert — \(y(\log y)^{-A}\) is below \(10^{-38}\) at
\(y=10^7\) for \(A\ge32\) — so the honest comparison is with a fair coin
on the same cylinder sizes, whose largest excess is
\(\sqrt{2\log W\cdot n_{\max}}/2\). The largest \(A\) the measured excess
permits over the window at \(C=19\) is \(2.62,2.84,2.61,1.59\) at
\(y=10^4,\dots,10^7\), against a fair-coin value of
\(2.62,2.86,3.10,3.34\): the map is indistinguishable from a coin at the
two smaller scales and measurably worse at the two larger. At a fixed
shallow depth the shares move the other way, the three largest bad
cylinders at depth \(4\) having odd shares \(0.53,0.53,0.52\) at \(10^4\)
and \(0.5001,0.4994,0.5008\) at \(10^7\), because the number of distinct
iterates a cylinder sits over widens with \(y\). What does not move with
\(y\) is the top of the window: the distinct iterates per bad cylinder at
\(t=d(y)-1\) are \(1.14,1.02,1.01,1.00\), so there the cylinders are
parity-constant at every scale measured, and the hypothesis reduces to
whether the mass of the largest such cylinder — a fraction of order
\(10^{-3}\) here, with no visible decay — falls below \((\log y)^{-A}\).
Three decades of \(y\) cannot see a \((\log y)^{-19}\); these observations
neither establish nor refute the hypotheses of Sections 8--10. The
backward computation of the barrier word, recorded with Theorem 9.1
above and in
[its dossier](../problems/juggler_barrier_collapse.md)
(`research.juggler_sequence.barrier_collapse`), reaches
\(y=10^{20000}\) and is what turns that measurement into a statement
about \(\mathrm H_q(C,A)\) at the scales where it is asserted.

## 12. Conclusions and open estimates

The contagion exponent is now \(37/50\), from five actual productions.
The first three, E, OE and OOEE, give \(5/8\) and are machine-checked
end to end. The two five-letter words enter through Paper B's
Theorem 6.3, the only input that is not formalized, and one that has
not been independently reviewed. The two-production exponent
\(100/203\) remains the elementary Lean baseline.

One sufficient remaining target is
\[
\#\{n\text{ odd in }(y,2y]:\tau(n)>\lceil CL(y)\rceil\}
 \ll y(\log y)^{-e},\qquad e>13/50,
\]
for a fixed \(C\) and all sufficiently large \(y\). This would
imply universal termination by Theorem 7.2; the machine-checked form
of that implication needs \(e>3/8\). No such arithmetic rate is proved. Universal termination alone gives no
uniform stopping-time bound here: Theorem 7.3 concerns eventual entry.

Live pressure and its scale-averaged form are sufficient routes to
the missing rate. The no-momentum hypothesis supplies a sufficient
condition for the pressure bound. The earlier localized Appendix C
and ideal-production models retain their stated hypotheses; they
do not limit the new exponent or establish further production
inequalities. No nontrivial cycle or unbounded orbit is excluded.

## Appendix A. Lean names

All in `formal/Problems/Juggler/FateContagion.lean` unless noted. The
root `formal/Problems/JugglerFatePaper.lean` imports exactly the
thirty-seven modules named here and builds with
`lake build Problems.JugglerFatePaper`
without `sorry` and without `native_decide`;
`formal/AxiomCheckPaperC.expected` records the axioms of every name
below. Lean certifies the exact combinatorial identities and the two
abstract lemmas listed here, not the analytic density estimates.

| Statement | Lean |
|---|---|
| backward closure | `BackwardClosed`, `backwardClosed_iterate` |
| Lemma 2.1, fate classes closed | `reachesOne_backwardClosed`, `not_reachesOne_backwardClosed`, `ancestor_backwardClosed`, `escapes_backwardClosed`, `reachesOne_floorPower`, `escapes_floorPower` |
| Lemma 2.1, trichotomy | `Periodic`, `periodic_of_repeat`, `fate_trichotomy` (from `cycles_or_escapes`) |
| Lemma 2.1, exclusion | `reachesOne_bounded`, `reachesOne_not_escapes`, `cycle_basin_bounded`, `cycle_basin_not_escapes`, `reachesOne_not_cycle_basin`, `periodic_iterate_mod` |
| Lemma 3.1 (even block) | `floorPower_even_block`, `even_block_mem`, `even_block_card` |
| Lemma 3.2 (\(OE\) fiber) | `sqrt_sqrt_eq_iff`, `floorPower_oe_fiber`, `oe_fiber_mem`, `oe_fiber_disjoint` |
| Theorem 6.1 (odd generation) | `ForwardClosed`, `reachesOne_forwardClosed`, `not_reachesOne_forwardClosed`, `escapes_forwardClosed`, `mem_iff_floorPower_mem`, `exists_odd_ancestor`, `exists_odd_ancestor_ge_three`, `nonempty_iff_odd_image_mem`, `odd_mem_iff` |
| Lemma 8.1 (envelope descent) | `iterate_le_of_envelope`, `mem_of_envelope_floor`, `reachesOne_of_itinerary_envelope`; power envelope `power_bound_word` (Paper A layer) |
| Lean floor \(N_0=260\), in `Problems/Juggler/TerminationFloor257.lean` | `reachesOne_of_lt_two_hundred_sixty_one` |
| Lemma 4.7 (cube fibers), in `Problems/Juggler/CubeFiber.lean` | `cube_fiber_range`, `cube_fiber_sqrt_even`, `cube_fiber_even_image`, `even_cube_fiber_full`, `cube_fiber_sqrt_odd`, `cube_fiber_alternating`, `odd_cube_fiber_alternating` |
| Shared counting of Lemmas 4.1, 4.1' and 4.3 (separated sequences in a window), in `Problems/Juggler/FateWindowCount.lean` | `WindowCount.StepGe`, `WindowCount.StepLe`, `WindowCount.span_ge`, `WindowCount.span_le`, `WindowCount.mono_of_stepGe`, `WindowCount.window_card_le`, `WindowCount.window_card_le_nat` |
| Proposition 4.4, the exact layer and the deduction from the exponential-sum bounds (the bounds are hypotheses), in `Problems/Juggler/FateBlockAverage.lean` | `BlockAverage.blockE`, `BlockAverage.oddBlock`, `BlockAverage.mem_oddBlock`, `BlockAverage.mem_oeFiber_iff_cell34`, `BlockAverage.U`, `BlockAverage.oddBlock_card_eq`, `BlockAverage.U_card_eq`, `BlockAverage.psi`, `BlockAverage.slowSum`, `BlockAverage.fastSum`, `BlockAverage.productSum`, `BlockAverage.four_card_U`, `BlockAverage.block_average_of_bounds`, `BlockAverage.block_average_bound`, `BlockAverage.psi_succ`, `BlockAverage.abs_psi`, `BlockAverage.oddBlock_filter_eq`, `BlockAverage.slowSum_eq_fibers`, `BlockAverage.oeFiber_card_succ_diff`, `BlockAverage.abs_alt_sum_le`, `BlockAverage.slowSum_abs_le`, `BlockAverage.card_Ico_block`, `BlockAverage.oddBlock_card_le`, `BlockAverage.oddBlock_card_ge`, `BlockAverage.oddBlock_quarter_close`, `BlockAverage.block_average_two_bounds`, `BlockAverage.block_average_asymptotic`, `BlockAverage.block_average_bound_two` |
| Section 5.1 without its exponential sums, and Theorem 5.3 at exponent 13/40 unconditionally, in `Problems/Juggler/FateProduction.lean` | `Production.sqrt_floor_exp`, `Production.floor_exp_ge_half`, `Production.family_E`, `Production.good_fiber_logMass_ge`, `Production.family_OE`, `Production.errE`, `Production.errOE`, `Production.errAdd`, `Production.two_le_exp`, `Production.one_div_floor_exp_le`, `Production.sum_Ioc_le_sum_Ioc_pred`, `Production.halfLogMass_split`, `Production.production_two`, `Production.rate2`, `Production.coef2`, `Production.err2`, `Production.rate2_ge`, `Production.rate2_le`, `Production.rate2_pos`, `Production.coef2_ge`, `Production.err2_nonneg`, `Production.err2_le`, `Production.production_two_sum`, `Production.zeta2_pos`, `Production.zeta2_antitone`, `Production.errors_le`, `Production.errors_vanish`, `Production.contagion_elementary`, `Production.logMass_contagion_elementary`, `Production.failures_logMass_ge`, `Production.conjecture_of_tao_rate`, `Production.conjecture_of_cylinder_bound` |
| Corollary 5.5(2), the log-mass clause at exponent 13/40, in `Problems/Juggler/FateProduction.lean` | `Production.failures_logMass_ge` |
| Section 5.7 and Appendix D, the production words and their prefix-freeness, in `Problems/Juggler/FateProductionWords.lean` | `FateProductionWords.Vword`, `FateProductionWords.Vword_length`, `FateProductionWords.Vword_oddCount`, `FateProductionWords.Vword_eq_odd_cons`, `FateProductionWords.Vword_prefix_iff`, `FateProductionWords.Vword_six_prefixFree`, `FateProductionWords.Vword_five` |
| Section 4.3, the exact layer of the share law (the expansion, the range, the integral), in `Problems/Juggler/FateShareLaw.lean` | `ShareLaw.taylor_three_halves`, `ShareLaw.xval_expansion`, `ShareLaw.xval_expansion_fiber`, `ShareLaw.phi`, `ShareLaw.phiRange`, `ShareLaw.phi_ge_min`, `ShareLaw.phi_le_chord`, `ShareLaw.phi_sub_le`, `ShareLaw.exists_phi_sub_eq`, `ShareLaw.phiRange_le_half_iff`, `ShareLaw.extremeMeasure`, `ShareLaw.extremeMeasure_eq_zero`, `ShareLaw.extremeMeasure_piece1`, `ShareLaw.extremeMeasure_piece2`, `ShareLaw.extremeMeasure_piece3`, `ShareLaw.extremeMeasure_piece4`, `ShareLaw.integral_extremeMeasure` |
| Section 10(d), the cylinder-splitting identity, in `Problems/Juggler/FateCylinderEnergy.lean` | `CylinderEnergy.itinerary_succ_append`, `CylinderEnergy.wordCount`, `CylinderEnergy.wordCount_split`, `CylinderEnergy.energy`, `CylinderEnergy.bias`, `CylinderEnergy.energy_succ`, `CylinderEnergy.sum_bias_sq` |
| Appendix D.1, the exact landing windows (D.1) and (D.2), in `Problems/Juggler/FateLandingWindow.lean` | `LandingWindow.cell34`, `LandingWindow.cell34_eq_floorPower_two`, `LandingWindow.le_cell34_iff`, `LandingWindow.cell34_lt_iff`, `LandingWindow.windowStart`, `LandingWindow.windowStart_exists`, `LandingWindow.windowStart_le_iff`, `LandingWindow.lt_windowStart_iff`, `LandingWindow.exact_endpoints`, `LandingWindow.setOf_cell34_mem_Ico`, `LandingWindow.exact_endpoints_iterate`, `LandingWindow.setOf_iterate_mem_Ico` |
| Lemma 4.1 (sweep), in `Problems/Juggler/FateSweep.lean` | `Sweep.cell`, `Sweep.sweep_cell`, `sweep_fract_lt_half`, `sweep_fract_ge_half`, `sweep_ceil`, `sweep_rep_le_half`, `sweep_rep_gt_half` |
| Lemma 4.1' (monotone pairing), in `Problems/Juggler/FateSweepMonotone.lean` | `Sweep.sweep_monotone_cell`, `sweep_monotone_fract_lt_half`, `sweep_monotone_fract_ge_half`, `sweep_monotone_ceil`, `sweep_monotone_rep_le_half`, `sweep_monotone_rep_gt_half` |
| Lemma 5.1 (recursion), in `Problems/Juggler/FateRecursion.lean` | `recursion_lemma` |
| Section 6.2, Proposition 6.3(i) and the exact layer of (6.1), in `Problems/Juggler/FateFirstLetter.lean` | `MinimalMember`, `minimalMember_odd`, `minimalMember_image_odd`, `minimal_failure_odd_odd`, `exists_minimal_failure`, `first_letter_trichotomy`, `first_letter_pieces_disjoint`, `first_letter_split`, `shellLogMass`, `shellLogMass_split`, `floorPower_odd_lt`, `floorPower_odd_injective`, `ooPiece`, `sum_image_ooPiece`, `card_image_ooPiece` |
| Lemma 8.2 (Chernoff count), in `Problems/Juggler/FateChernoff.lean` | `weightGen_one`, `count_oddCount_ge_le`, `count_oddCount_ge_real_le`, `entropyLog`, `klHalf`, `klHalf_eq`, `klHalf_nonneg`, `tilt_value`, `count_oddCount_ge_le_exp`, `count_oddCount_ge_le_kl`, `LBad`, `pC`, `chernoffExponent`, `logb_two_three_le`, `half_le_pC`, `pC_lt_one`, `LBad_oddCount_ge`, `LBad_count_le` |
| Theorem 8.3 (explicit form), in `Problems/Juggler/FateChernoff.lean` | `cylinder`, `oddFailures`, `EnvelopeBad`, `oddFailures_subset_bad_cylinders`, `oddFailures_card_le`, `LBad_of_envelopeBad`, `oddFailures_card_le_chernoff`, `scaleRatio`, `scaleL`, `depth`, `cylinder_even_root_empty`, `oddFailures_card_le_explicit` |
| Theorem 9.2 (pressure form), in `Problems/Juggler/FatePressure.lean` | `livePressure`, `live_count_le_pressure`, `envelopeBad_of_liveTo`, `LBad_of_liveTo`, `live_oddCount_ge`, `live_count_le_of_pressure` |
| Proposition 9.3 (pressure telescoping), in `Problems/Juggler/TiltedShare.lean` | `oddMass`, `tiltedShare`, `weightGen_succ_le_share`, `one_add_le_exp_excess`, `weightGen_le_pressure`, `count_le_pressure`, `NoMomentum`, `count_le_of_noMomentum`, `tilt_exponent_eq_kl`, `MeanShare`, `weightGen_le_of_meanShare`, `MeanShareOff`, `initial_depths_are_free`, `tower_ratio_lt_one` |
| Lemma 5.2 (seed), in `Problems/Juggler/FateSeed.lean` | `exists_ge_three_of_backwardClosed`, `seed_lemma`, `seed_constant_pos` |
| Theorem 7.2 (Tao-type rate, contagion as a hypothesis), in `Problems/Juggler/FateTaoReduction.lean` | `logMass_le_oddLogMass`, `oddLogMass_le_of_dyadic`, `tao_rate_implies_empty`, `tao_rate_implies_conjecture` |
| Corollary 8.4 (the conjecture from a cylinder bound), in `Problems/Juggler/FateCylinderCorollary.lean` | `CylinderBound`, `one_le_depth`, `chernoffExponent_nonneg`, `oddFailures_eventually_le`, `cylinder_bound_implies_conjecture` |
| Shared numerics of Lemmas 4.2, 4.3 and 8.2 (roots by powering, Bernoulli at a point), in `Problems/Juggler/FateNumerics.lean` | `Numerics.rpow_le_iff_pow`, `Numerics.le_rpow_iff_pow`, `Numerics.rpow_lt_iff_pow`, `Numerics.lt_rpow_iff_pow`, `Numerics.bernoulli_ge`, `Numerics.bernoulli_le` |
| Lemma 4.2 (fiber parity), in `Problems/Juggler/FateFiberParity.lean` | `FiberParity.xval`, `FiberParity.two_xval`, `FiberParity.floor_two_xval`, `FiberParity.cell_xval_even_iff`, `FiberParity.xval_step`, `FiberParity.xval_step_ge`, `FiberParity.xval_step_le`, `FiberParity.xval_step_mono`, `FiberParity.oeFiber`, `FiberParity.mem_oeFiber`, `FiberParity.oeFiber_eq_image`, `FiberParity.oeFiber_card`, `FiberParity.evenImageCount`, `FiberParity.fiber_ge_rpow`, `FiberParity.fiber_lt_rpow`, `FiberParity.rpow_four_thirds_succ_ge`, `FiberParity.rpow_four_thirds_succ_le`, `FiberParity.rpow_two_thirds_succ_le`, `FiberParity.oeFiber_card_ge`, `FiberParity.oeFiber_card_le`, `FiberParity.Am`, `FiberParity.alpha`, `FiberParity.eps`, `FiberParity.Good`, `FiberParity.eps_le`, `FiberParity.step_ge`, `FiberParity.step_le`, `FiberParity.fiber_parity_good` |
| Lemma 4.3 (thin fibers), in `Problems/Juggler/FateThinFibers.lean` | `FiberParity.span_ge_of_step`, `FiberParity.arc_count_le`, `FiberParity.Am_step_le`, `FiberParity.Am_step_ge`, `FiberParity.eps_antitone`, `FiberParity.bad_mem_arc`, `FiberParity.two_rpow_third_le`, `FiberParity.two_rpow_two_thirds_le`, `FiberParity.rpow_two_thirds_ge`, `FiberParity.eps_div_eps_double`, `FiberParity.Am_double_sub_le`, `FiberParity.bad_count_le`, `FiberParity.bad_block_logMass_le`, `FiberParity.bad_sum_dyadic_le`, `FiberParity.eps_pow_two_mul`, `FiberParity.two_rpow_neg_third_le`, `FiberParity.bad_logMass_le` |
| Theorem 5.3 given (5.2), Theorem 7.3, Corollary 8.4 through (5.2), in `Problems/Juggler/FateContagionBound.lean` | `productionRate`, `productionCoeff`, `productionRate_pos`, `productionRate_ge`, `productionRate_le`, `productionRate_le_one`, `productionCoeff_ge`, `productionCoeff_nonneg`, `zeta`, `zeta_antitone`, `le_rpow_div_of_pow_le`, `zeta_pos_49`, `seedConst`, `gA`, `gA_seed`, `logMass_ge_gA`, `contagion_of_production_inequality`, `logMass_contagion_of_production`, `oddFailures_eq_empty`, `tao_rate_iff_conjecture`, `conjecture_of_cylinder_bound_of_production` |
| Proposition 4.4 (its two exponential-sum bounds, the fast sum and the product sum; the exact layer, the slow sum, the block count and the deduction of (4.1) and of the asymptotic form from those two bounds are Lean), the share law 4.5 and Corollary 4.6 (the phase expansion, the range of the quadratic phase and the integral 25/108 are Lean, the equidistribution and the measure identifications are not), the production inequality (5.2) (its `E`-family and `OE`-fiber family are Lean with explicit errors and give Theorem 5.3 at exponent 13/40 unconditionally, and the averaged `OE` family of Section 5.8 gives it at 100/203; the block-average family and the ladder are not Lean and are no longer needed for the exponent), Corollaries 5.4 and 5.5 in the range \(100/203<\lambda\le37/50\) (at \(100/203\) both are Lean, in `Problems/Juggler/FateDyadicDensity.lean`), Sections 8--10 except Lemma 8.2, the explicit form of Theorem 8.3, Corollary 8.4, the exact form of Theorem 9.2 and Proposition 9.3, Appendix C; Theorem 5.3 in the range \(100/203<\lambda<\lambda_{\mathrm{ideal}}\), and Theorems 7.2, 7.3 and Corollary 8.4 with the contagion bound as a hypothesis outside the exponents of Sections 5.8--5.10 | human proofs |
| Theorem 9.1 (one-sided form, exact, by exponential moments), in `Problems/Juggler/FateOneSided.lean` | `OneSided.cylinder_split`, `OneSided.LBad_of_LBad_append`, `OneSided.sum_allWords_succ`, `OneSided.sum_pow_oddCount_le`, `OneSided.badWeight`, `OneSided.badWeight_nonneg`, `OneSided.badWeight_le_card`, `OneSided.badMass`, `OneSided.OneSidedShare`, `OneSided.badMass_succ_le`, `OneSided.card_cylinder_zero_le`, `OneSided.badMass_one_le`, `OneSided.badMass_le`, `OneSided.oddFailures_card_le_badMass`, `OneSided.one_sided_bound`, `OneSided.klDiv`, `OneSided.tilt`, `OneSided.tilt_ge_one`, `OneSided.tilt_pow_ratio`, `OneSided.one_sided_bound_kl` |
| Theorem 9.1's consequence (the conjecture from the one-sided hypothesis), in `Problems/Juggler/FateOneSidedCorollary.lean` | `OneSided.OneSidedBound`, `OneSided.OneSidedExact`, `OneSided.oneSidedExponent`, `OneSided.OneSidedShare.mono`, `OneSided.oneSidedBound_of_exact`, `OneSided.klDiv_nonneg`, `OneSided.exp_le_rpow_scale`, `OneSided.pow_le_rpow_scale`, `OneSided.oddFailures_le_of_one_sided`, `OneSided.implies_conjecture_of_contagion`, `OneSided.one_sided_implies_conjecture`, `OneSided.exact_share_implies_conjecture` |
| Section 9.2's consequences (the conjecture from the pressure and no-momentum hypotheses), in `Problems/Juggler/FatePressureCorollary.lean` | `Pressure.oddFailures_subset_live`, `Pressure.PressureBound`, `Pressure.NoMomentumBound`, `Pressure.momentumExponent`, `Pressure.absorb`, `Pressure.oddFailures_le_of_pressure`, `Pressure.pressure_conj_of_contagion`, `Pressure.pressure_implies_conjecture`, `Pressure.oddFailures_le_of_noMomentum`, `Pressure.noMomentum_conj_of_contagion`, `Pressure.noMomentum_implies_conjecture` |
| Section 10(d), Theorem 9.1 with exceptional atoms, in `Problems/Juggler/FateOneSidedAtoms.lean` | `OneSided.OneSidedShareExc`, `OneSided.oneSidedShareExc_of_share`, `OneSided.OneSidedBoundExc`, `OneSided.oneSidedBoundExc_of_bound`, `OneSided.badMass_succ_le_exc`, `OneSided.badMass_le_exc`, `OneSided.one_sided_bound_exc`, `OneSided.main_term_eq`, `OneSided.one_sided_bound_kl_exc`, `OneSided.pow_le_rpow_scale_gen`, `OneSided.tail_le`, `OneSided.oddFailures_le_of_exc`, `OneSided.exc_conj_of_contagion`, `OneSided.exc_implies_conjecture` |
| Section 10(d), the bias energy supplying the exceptional atoms, in `Problems/Juggler/FateEnergyAtoms.lean` | `OneSided.OneSidedShareExc.mono_err`, `Energy.bias`, `Energy.energyOn`, `Energy.biasEnergy`, `Energy.badEnergy`, `Energy.violators`, `Energy.badEnergy_le_biasEnergy`, `Energy.card_allWords`, `Energy.mass_violators_le`, `Energy.oneSidedShareExc_of_energy`, `Energy.wordCount_cylinder`, `Energy.biasEnergy_eq`, `Energy.EnergyBound`, `Energy.oneSidedBoundExc_of_energy`, `Energy.energy_conj_of_contagion`, `Energy.energy_implies_conjecture` |
| Section 10(d), the collapsed component, in `Problems/Juggler/FateCollapse.lean` | `Collapse.fiber`, `Collapse.window`, `Collapse.windowBias`, `Collapse.card_filter_window`, `Collapse.card_window`, `Collapse.windowBias_eq_sum`, `Collapse.abs_alt_sum_le`, `Collapse.Icc_eq_Ico`, `Collapse.abs_windowBias_le`, `Collapse.lt_sq_succ_of_floorPower_eq`, `Collapse.pre`, `Collapse.iterate_succ_eq`, `Collapse.fiber_succ`, `Collapse.pre_filter_even`, `Collapse.blockSum`, `Collapse.oddPart`, `Collapse.oddPart_nonneg`, `Collapse.fiber_succ_eq`, `Collapse.evenCount`, `Collapse.evenCount_le`, `Collapse.le_evenCount`, `Collapse.blockSum_sub_le`, `Collapse.sum_abs_oddPart_sub_le`, `Collapse.collapse_bias_le`, `Collapse.fiber_succ_sandwich`, `Collapse.collapse_bias_two_step` |
| Section 8.4, the unconditional criteria at `C = 30` with every constant a numeral, in `Problems/Juggler/FateCertified.lean` | `Certified.e_ge`, `Certified.e_le`, `Certified.log_le_of_pow_le`, `Certified.le_log_of_pow_le`, `Certified.logb_two_le`, `Certified.le_logb_two`, `Certified.log_two_le`, `Certified.le_log_two`, `Certified.le_logb_three`, `Certified.logb_three_le`, `Certified.le_log_lo`, `Certified.le_log_hi`, `Certified.log_lo_le`, `Certified.log_hi_le`, `Certified.logb_three_pos`, `Certified.pC_thirty_ge`, `Certified.pC_thirty_le`, `Certified.klHalf_ge_of`, `Certified.klHalf_le_of`, `Certified.klHalf_thirty_ge`, `Certified.klHalf_thirty_le`, `Certified.chernoffExponent_thirty_gt`, `Certified.chernoffExponent_thirty_lt`, `Certified.cylinder_bound_thirty`, `Certified.pressure_thirty`, `Certified.klDiv_half`, `Certified.oneSidedExponent_half`, `Certified.logb_tilt_thirty_le`, `Certified.one_sided_thirty` |
| Lemma 5.14 (block lock), in `Problems/Juggler/FateBlockLock.lean` | `BlockLock.gridRes`, `BlockLock.fract_grid`, `BlockLock.gridRes_mul_inj`, `BlockLock.grid_reindex`, `BlockLock.grid_half_count`, `BlockLock.grid_near_count`, `BlockLock.span_bounds`, `BlockLock.block_count`, `BlockLock.block_chain`, `BlockLock.block_lock` |
| Lemma 5.15 (fiber lock), in `Problems/Juggler/FateFiberLock.lean` | `FiberParity.evenImageCount_eq_fract`, `FiberParity.eps_mul_Hlen_le`, `FiberParity.exists_coprime_approx`, `FiberParity.fiber_block_lock`, `FiberParity.fiber_lock` |
| The resonance count behind Theorem 5.16, in `Problems/Juggler/FateResonanceCount.lean` | `FiberParity.Resonant`, `FiberParity.resonant_mem_arc`, `FiberParity.Am_window_le`, `FiberParity.shifted_arc_count_le`, `FiberParity.resonance_count_one`, `FiberParity.resonance_count_le`, `FiberParity.resonance_count_le'` |
| Theorem 5.16 (poor-fiber tail) and the non-poor fiber bound of Corollary 5.17, in `Problems/Juggler/FatePoorTail.lean` | `FiberParity.Poor`, `FiberParity.oeFiber_nonempty`, `FiberParity.resonant_mono`, `FiberParity.poor_resonant`, `FiberParity.poor_count_le`, `FiberParity.poor_count_le'`, `FiberParity.poor_block_logMass_le`, `FiberParity.poor_sum_dyadic_le`, `FiberParity.poor_logMass_le`, `FiberParity.nonpoor_fiber_logMass_ge` |
| Theorem 5.18 and its consequences (Section 5.8), in `Problems/Juggler/FatePoorProduction.lean` | `Production.family_OE_averaged`, `Production.errOEavg`, `Production.errAddAvg`, `Production.production_two_averaged`, `Production.coef2avg`, `Production.err2avg`, `Production.coef2avg_ge`, `Production.coef2avg_nonneg`, `Production.err2avg_nonneg`, `Production.err2avg_le`, `Production.production_two_averaged_sum`, `Production.errorsAvg_le`, `Production.errorsAvg_vanish`, `Production.zeta2avg_antitone`, `Production.contagion_averaged`, `Production.zeta2avg_pos`, `Production.logMass_contagion_averaged`, `Production.failures_logMass_averaged`, `Production.conjecture_of_tao_rate_averaged`, `Production.conjecture_of_cylinder_averaged` |
| Corollary 5.4 and Corollary 5.5 at the fate classes (Section 5.5), in `Problems/Juggler/FateDyadicDensity.lean` | `Density.blockCount`, `Density.block_logMass_le`, `Density.block_index`, `Density.halfLogMass_le_blocks`, `Density.exists_block_of_shell`, `Density.natDensity_of_shell_bound`, `Density.natDensity_averaged`, `Density.reachesOne_logMass_averaged`, `Density.reachesOne_natDensity_averaged`, `Density.failures_natDensity_averaged`, `Density.basin_logMass_averaged`, `Density.basin_natDensity_averaged`, `Density.escapes_logMass_averaged`, `Density.escapes_natDensity_averaged` |

The supplementary modules of Theorems 5.19 and 5.20 lie outside this
barrel: `FateOEWeighted`, `FateOOEEAssembly`, `OOEEMixedModes`,
`OOEEResonanceTail` and `FateOOEEWeighted` for Theorem 5.19, and
`DepthFiveFibreGeometry`, `FateOOOEEAssembly`, `FateDepthFiveAssembly`
and `FateDepthFiveWeighted` for Theorem 5.20. The axiom checks
`formal/AxiomCheckOOEEWeighted.lean`,
`formal/AxiomCheckOOEECountPoorTail.lean`,
`formal/AxiomCheckDepthFiveAssembly.lean` and
`formal/AxiomCheckDepthFiveWeighted.lean` print the axioms of the cited
theorems, whose dependencies include the other modules; only the three
axioms above occur. Each is run with `lake env lean <file>` in `formal`.
Their sources and audits are pinned in the release manifest,
`docs/theory/paper_c_release.json`.

## Appendix B. Constants and artifacts

*Exponents.* Roots of \(2^{-\lambda}+\sum_ic_ie_i^{\lambda}=1\):

| recursion | terms \((c_i,e_i)\) | root |
|---|---|---|
| elementary sweep only | \((\tfrac2{21},\tfrac34)\) | \(0.1385\) |
| block average only (\(\lambda^*\)) | \((\tfrac13,\tfrac38)\) | \(0.3774\) |
| block average + sweep (adversarial \(1/7\)) | \((\tfrac5{21},\tfrac38),(\tfrac2{21},\tfrac34)\) | \(0.4051\) |
| block average + pairing (named intermediate) | \((\tfrac19,\tfrac38),(\tfrac29,\tfrac34)\) | \(0.4480\) |
| + \(OEOEE\) (named intermediate; elementary, audited) | \(\ldots,(\tfrac1{27},\tfrac9{32})\) | \(0.4801\) |
| + \(V_3=OEOEOEE\) (named intermediate; elementary, audited) | \(\ldots,(\tfrac1{81},\tfrac{27}{128})\) | \(0.4891\) |
| + \(V_4=OEOEOEOEE\) (named intermediate; elementary, audited) | \(\ldots,(\tfrac1{243},\tfrac{81}{512})\) | \(0.4916\) |
| + \(V_5=OEOEOEOEOEE\) (named intermediate; elementary, audited) | \(\ldots,(\tfrac1{729},\tfrac{243}{2048})\) | \(0.4924\) |
| + \(V_6=OEOEOEOEOEOEE\) (\(\lambda^{**}\), earlier finite-production route; elementary, audited) | \(\ldots,(\tfrac1{2187},\tfrac{729}{8192})\) | \(0.4926\) |
| pairing + \(OOEEE\) (\(\lambda^{***}\), Appendix C, conditional) | pairing terms and \((\tfrac19,\tfrac9{32})\) | \(0.5392\) |
| depth-two ideal-share model | \((\tfrac13,\tfrac34)\) | \(0.4927\) |
| two productions at the averaged coefficient, \(\eta_0\downarrow0\) (\(\lambda_{\mathrm{ideal}}\), Theorem 5.18; Lean to \(100/203\)) | \((\tfrac13-\tfrac23\eta_0,\tfrac34)\) | \(0.4927\) |
| pairing + \(OOEEE\) + \(OOOEE\), \(OOEOE\) on even blocks, localized (closed: fibers \(P^{5/32}\); the averaged route is Theorem 5.20) | pairing terms, \((\tfrac19,\tfrac9{32})\) and \((\tfrac2{27},\tfrac{27}{64})\) | \(0.6066\) |
| three actual productions (Theorem 5.19; Lean) | \((\tfrac{33}{100},\tfrac34),(\tfrac{11}{100},\tfrac9{16})\) | \(0.6266\) |
| five actual productions (Theorem 5.20; Paper B's Theorem 6.3) | \(\ldots,(\tfrac1{14},\tfrac{27}{32})\) | \(0.7406\) |
| pairing + \(OEOEE\) + \(OOEEE\) (model comparison) | pairing terms and \((\tfrac4{27},\tfrac9{32})\) | \(0.5665\) |
| conditional infinite \(V_k=(OE)^{k-1}OEE\) model | \(\ldots,(3^{-(k+2)},(\tfrac34)^k\tfrac38)_{k\ge1}\) | \(0.4927\) |
| conditional infinite \(V_k\) model and \(OOEEE\) | | \(0.5769\) |
| conditional \(O\)-runs \(\le2\), pairing share (Section 5.7) | transfer matrix | \(0.6247\) |
| conditional \(O\)-runs \(\le2\), ideal-share model | transfer matrix | \(0.7180\) |
| conditional \(O\)-runs \(\le3\), pairing share | transfer matrix | \(0.7095\) |
| conditional \(O\)-runs \(\le3\), ideal-share model | transfer matrix | \(0.8414\) |
| abstract ceiling, all \(O\)-runs at the ideal share (Proposition 5.12) | \(2^{-\lambda}+\tfrac13(\tfrac32)^{\lambda}=1\) | \(1\) |

Theorem 5.19 attains \(5/8\), below the root \(0.6266\) of the three
actual productions, and Theorem 5.20 attains \(37/50\), below the root
\(0.7406\) of the five; their exact certificates are in Sections 5.9 and
5.10 and in Lean. Arb encloses the two roots as
\([0.62655175640058022882\pm6.4\cdot10^{-21}]\) and
\([0.74057159102112395859\pm5.0\cdot10^{-21}]\).

*Depth constants.* At the current thresholds, \(13/50\) from Theorem 5.20
and \(3/8\) from Theorem 5.19, the least integer values are these; Arb
certifies each value and the failure of the integer below it.

| criterion | Theorem 5.20, rate \(13/50\) | Theorem 5.19, rate \(3/8\) |
|---|---|---|
| fair Chernoff | 14 | 16 |
| one-sided Azuma, \(q=0.5,0.55,0.60,0.62\) | 14, 28, 132, 866 | 16, 34, 175, 1201 |
| optimized pressure, same \(q\) | 14, 27, 128, 820 | 16, 34, 168, 1135 |

The historical least integer values below use the three
explicitly named rate thresholds; the threshold \(1-\lambda_{\mathrm{ideal}}=0.5073\)
of the second route gives the same integers as \(0.5074\) in every
column; intermediate \(V_2\) through
\(V_5\) have complementary thresholds \(0.5199\), \(0.5109\),
\(0.5084\), and \(0.5076\), respectively.

| criterion | \(\lambda^{**}\), rate \(0.5074\) | pairing, rate \(0.5520\) | \(\lambda^{***}\), rate \(0.4608\) |
|---|---|---|---|
| fair Chernoff | 19 | 20 | 18 |
| one-sided Azuma, \(q=0.5,0.55,0.60,0.62\) | 19, 41, 223, 1586 | 20, 44, 240, 1715 | 18, 39, 206, 1451 |
| optimized pressure, same \(q\) | 19, 41, 214, 1496 | 20, 43, 230, 1618 | 18, 38, 198, 1369 |

Depth \(d(y)=\lceil 20L(y)\rceil\)
(the conservative a-fortiori table) with
\(N_0=3.5\cdot 10^8\): \(25\) at \(10^{20}\), \(72\) at \(10^{100}\),
\(138\) at \(10^{1000}\), \(204\) at \(10^{10000}\).

Decimal values in the tables are rounded; all strict inequalities
use the roots of the displayed defining equations.

*Artifacts* (repository `sneakyweasel/btlab`; SHA-256):

- `data/research/juggler/fate_contagion/summary.json`

  SHA-256: `d322b8549e2239c5fc78279c7a579332766a3287811f73ee4d225d6eb9e5cc7b`

- `data/research/juggler/tao_reduction/summary.json`

  SHA-256: `2316e5339e3670d283c1983a5b5b0c11bc92101ab327c477072b7897619a587f`

- `formal/Problems/Juggler/FateContagion.lean`

  SHA-256: `834198a6b0e8cc13c9fb91d9ad938f62ce5e783a3cc9009fb38334c913d5b7e2`

- `formal/Problems/Juggler/CubeFiber.lean`

  SHA-256: `2b0add4108651218c43fb741a207d3d6860525a2ad13ad1341ece9fc5c37f8e9`

- `formal/Problems/Juggler/TiltedShare.lean`

  SHA-256: `7dcafa45a2a0e9bca182a713b495d791cf812e4c70d6472c67bf85b0b736aef4`

- `formal/Problems/Juggler/FateRecursion.lean`

  SHA-256: `e6d050acc924867abcf5c03b4a3e59b62363f40bbba452e2ced83afe474dd435`

- `formal/Problems/Juggler/FateFirstLetter.lean`

  SHA-256: `a383c715010cb1e7323359a414aeaa99242550f59f7213049cc528232e37875a`

- `formal/Problems/Juggler/FateBlockAverage.lean`

  SHA-256: `5cef5c273577376b72799732865415a91c6b91f8bdb06e79bd398d9c478d0b07`

- `formal/Problems/Juggler/FateProduction.lean`

  SHA-256: `7cc24ff9f95692ead6b594aa703677910daf4936f24becce7b13da2c4105df2e`

- `formal/Problems/Juggler/FateProductionWords.lean`

  SHA-256: `a712db485e4c48029ce9a9afcad1cfea1240f4bb4dda1cb7537661ae1f3fdb3e`

- `formal/Problems/Juggler/FateOneSided.lean`

  SHA-256: `7ae0aa4cab061a24ef51eff381a0f4bbd4e4569ae2578f04e4c3677b5999bddc`

- `formal/Problems/Juggler/FateOneSidedCorollary.lean`

  SHA-256: `481b4cecbebd7291d551b814f733b9cfd78dec50a936a31fd9ab6544408c714e`

- `formal/Problems/Juggler/FatePressureCorollary.lean`

  SHA-256: `cdd1ca9cbb59c4bb0a5fb24702f12bb8e27c21365f9b28e515819f874e9b437e`

- `formal/Problems/Juggler/FateOneSidedAtoms.lean`

  SHA-256: `db2601560b54b95a5ac5b2f5f16c0d83e3b4cf4182f1d20795c47db26c0a9ce3`

- `formal/Problems/Juggler/FateEnergyAtoms.lean`

  SHA-256: `e98ccccbb25140d41ede236466f7e0f522c433a4c80fcaa330abfb1388653b1a`

- `formal/Problems/Juggler/FateCollapse.lean`

  SHA-256: `56ba2f731fdd02ea1d19a6e6ef909534947c8c30b48828c72f8009901ed06e06`

- `formal/Problems/Juggler/FateCertified.lean`

  SHA-256: `ff47a23462fb591264125859b9d511bb2cec046da7a71fbad5d17b35a5581c90`

- `formal/Problems/Juggler/FateShareLaw.lean`

  SHA-256: `a229f4fa4cf48cb5b003c746672947eec10bf93d7287ad7eecaa3f84d5236e7c`

- `formal/Problems/Juggler/FateCylinderEnergy.lean`

  SHA-256: `274cd6b960bdd1de8c1b637bd2dee86c8cbe67e883e25937812dadcbe98d6a0b`

- `formal/Problems/Juggler/FateLandingWindow.lean`

  SHA-256: `ef28985363d3b855e0a9ec4b8fba687855d34ab8cf1ff9b355a50e9377e29545`

- `formal/Problems/Juggler/FateWindowCount.lean`

  SHA-256: `9d790163433899c73993a24b434ff20ae45aba3dbe47b717507dba840307b6a3`

- `formal/Problems/Juggler/FateSweep.lean`

  SHA-256: `a5ede4a6d25cec71d6b6c7fb99e577df3335366175dd22f361581456669a72cc`

- `formal/Problems/Juggler/FateChernoff.lean`

  SHA-256: `3b808649443805fa3dd41b89333afe886f3cbc7e36f1bdae23f6c93fe95a7032`

- `formal/Problems/Juggler/FatePressure.lean`

  SHA-256: `f69ad74fcaed87b692451113cf72eeadc1182efc0ac8121e255e6b079bf2bbf2`

- `formal/Problems/Juggler/FateCylinderCorollary.lean`

  SHA-256: `e2ffc98f56268a31826b86f54115e0fed949e62651d05936d545cd829761b4d2`

- `formal/Problems/Juggler/FateNumerics.lean`

  SHA-256: `8340b3a8a4ff2ce35bd77b7697ca95b9d36e5d61ea4173782287d0839b381737`

- `formal/Problems/Juggler/FateFiberParity.lean`

  SHA-256: `bf2b1c6058c3d00f0f9cf24f11bb7bee7a17a75375c2ddc7223e065621e64131`

- `formal/Problems/Juggler/FateThinFibers.lean`

  SHA-256: `3fbcd3e9f7adf13967e7494691aa8f62779630e0446fe81e813486947478cb74`

- `formal/Problems/Juggler/FateContagionBound.lean`

  SHA-256: `d8991fd05c076875a0e8fd75692a10bb31930c289a3812de07212b620645acca`

- `formal/Problems/Juggler/FateBlockLock.lean`

  SHA-256: `b4fdc02e5b41b8759156f5aa1b3f208854d2e6c994a3963e24aa164df498bed7`

- `formal/Problems/Juggler/FateFiberLock.lean`

  SHA-256: `f82aceb5a06642f7f55ea1b1bbee317ea487c46e97cbf52aecbd920dc9d10007`

- `formal/Problems/Juggler/FateResonanceCount.lean`

  SHA-256: `f39eca082166b63d15989946e8ae54279bb9a4b779d5440d0c970212883f4aa1`

- `formal/Problems/Juggler/FatePoorTail.lean`

  SHA-256: `773c579e2ba303dc49f1488020ea142b0b35ea26573707ebfd6afca7c4dd284b`

- `formal/Problems/Juggler/FatePoorProduction.lean`

  SHA-256: `0fc332ef6b54bebbe4de215b03ac582a2d0cc38d82a391d23856624599940283`

- `formal/Problems/Juggler/FateDyadicDensity.lean`

  SHA-256: `f5065c952302de36981e147f5ae95804eaa16d34a38459025a65e10b5a24e4fe`

- `formal/Problems/JugglerFatePaper.lean`

  SHA-256: `ce57dde1ab5f47f98277f4b870641f864727a4136b617627773e531e2b6753c2`

- `formal/AxiomCheckPaperC.expected`

  SHA-256: `b8569df4c76a94d8665940b04dba86739d773a796d8683e7801ede5c654ddc24`

- `src/research/juggler_sequence/fate_contagion.py`

  SHA-256: `27b94f873d4cc9fc4f424443db058c8b3f7c6217e9bdbde7cc17c984829e9c46`

- `src/research/juggler_sequence/tao_reduction.py`

  SHA-256: `7d4cc3e0dbf197232c084e0aa6fe89cff7deb77bdab2d52523f5bcfc58a9e14f`

- `docs/theory/figures/render_paper_c_figures.py`

  SHA-256: `bf0e053dfa143c903900ca81410502a1ba3b29b9d79d8ba067eb93d0598d00a0`

The archived records retain the parameter names and values of their
original runs (including the older pairing-only threshold). Current
exponents and depth constants are checked separately in
`data/research/juggler/paper_c_publication_review/validation.json`.
The numerical experiments of Section 11 use fixed random seeds. Their
code is run by `python -m research.juggler_sequence.fate_contagion` and
`python -m research.juggler_sequence.tao_reduction`. The current code
reports current rate constants; archived parameter labels are preserved
in the supplied JSON. The figures are regenerated by
`python docs/theory/figures/render_paper_c_figures.py`.

## Appendix C. An earlier conditional strengthening

This appendix depends on one analytic hypothesis beyond the main text.
No statement of Sections 1--12 uses it. It improved the constants of
Theorems 1, 3 and 4 over the earlier route \(\lambda^{**}\) and nothing
else; Theorems 5.19 and 5.20 now supersede it.

### C.1 The hypothesis

For odd \(n\) put \(m=\lfloor n^{3/2}\rfloor\), \(v=\lfloor m^{3/2}\rfloor\),
\(\psi(y)=(-1)^{\lfloor y\rfloor}\), and
\[
\psi_1=\psi(n^{3/2}),\qquad\psi_2=\psi(m^{3/2}),\qquad\psi_3=\psi(v^{1/2}),
\]
the signs of the parities of \(m\), of \(\lfloor m^{3/2}\rfloor\) and of
\(\lfloor v^{1/2}\rfloor\) — the second, third and fourth letters of the
itinerary of \(n\) along the branch \(OOE\).

**Hypothesis L (localized triple parity discrepancy with a slow
twist).** For every \(\varepsilon>0\) there is \(P_0\) such that for all
\(P\ge P_0\), every interval \(I\subseteq(P,2P]\) of length
\(Y\ge P^{1/2}\), every \((a,b,c)\in\{0,1\}^3\setminus\{(0,0,0)\}\), and
every integer \(\ell\) with \(|\ell|\le P^{1/24}\),
\[
\Bigl|\sum_{n\in I,\ n\ \mathrm{odd}}\psi_1^{a}\psi_2^{b}\psi_3^{c}\,e\bigl(\tfrac{\ell}{2}n^{9/16}\bigr)\Bigr|
\ \le\ Y\,P^{-1/24+\varepsilon}.
\]

*Status.* An earlier working draft of Paper B stated Hypothesis L as a
theorem. Its argument removed the twist by partial summation after the
Weyl differencing and ran a seven-step argument (exact linearization of
the nested floors, differencing with \(H=P^{1/12}\), a cell
decomposition, second-derivative tests per cell) over a sub-dyadic
interval, exhibiting the three absolute terms — two partial end cells
\(5.2P^{3/8}\), the pure passenger \(3.8P^{7/16}\), the majorant end
cells \(17P^{1/4}\) — that do not scale with the number of summands.
Paper B's published version [12] does not prove it and lists
localization to a prescribed short interval as open, so we keep the
statement as a hypothesis here and rely on nothing but the statement;
what *is* proved in this appendix is everything that follows from it.
(The derivation below followed that draft.)

### C.2 The \(OOEEE\) production on even blocks

For \(m'\ge 2\) let \(I(m')=[m'^{32/9},(m'+1)^{32/9})\), an interval of
length \(Y=\tfrac{32}9m'^{23/9}(1+O(1/m'))\) at scale \(P=m'^{32/9}\), so
that \(Y\asymp P^{23/32}\ge P^{1/2}\). Let
\[
\mathcal O(m')=\{n\ \text{odd}\in I(m'):\ \mathrm{word}_5(n)=OOEEE,\ J^5(n)=m'\}.
\]

**Lemma C.1 (transparent nesting at the fifth letter).** For odd
\(n\ge 3\), with \(m,v\) as above,
\(0\le n^{9/16}-v^{1/4}\le n^{-15/16}\). Consequently
\(\lfloor v^{1/4}\rfloor=\lfloor n^{9/16}\rfloor\) unless
\(\{n^{9/16}\}<n^{-15/16}\).

*Proof.* \(v\le m^{3/2}\le n^{9/4}\) gives \(v^{1/4}\le n^{9/16}\). For
the other direction, \(m\ge n^{3/2}-1\) and \(v\ge m^{3/2}-1\) give
\(v\ge(n^{3/2}-1)^{3/2}-1\ge n^{9/4}-\tfrac32n^{3/4}-1\), and then, by
the mean value theorem for \(u\mapsto u^{1/4}\) on \([v,n^{9/4}]\),
\(n^{9/16}-v^{1/4}\le(n^{9/4}-v)/(4v^{3/4})\le(\tfrac32n^{3/4}+1)/(4v^{3/4})\).
Since \(v\ge\tfrac12n^{9/4}\) for \(n\ge 3\), \(v^{3/4}\ge 2^{-3/4}n^{27/16}\),
and the bound is at most \(2^{3/4}(\tfrac32n^{3/4}+1)/(4n^{27/16})\le n^{-15/16}\)
for \(n\ge 3\). The floors of two numbers in \([n^{9/16}-n^{-15/16},n^{9/16}]\)
differ only if an integer lies in that interval, i.e. if
\(\{n^{9/16}\}<n^{-15/16}\). \(\square\)

**Lemma C.2 (the exceptional set is small).** Let
\(\mathcal E(I)=\{n\ \text{odd}\in I:\ \{n^{9/16}\}<n^{-15/16}\}\). For
\(I\subseteq(P,2P]\) of length \(Y\ge P^{1/2}\),
\(|\mathcal E(I)|\ll YP^{-1/16}\).

*Proof.* \(\mathcal E(I)\subseteq\{n\ \text{odd}\in I:\ \{n^{9/16}\}\in[0,P^{-15/16})\}\).
By the Erdős--Turán inequality [15, Theorem 2.5], for any \(H\ge 1\),
\[
|\mathcal E(I)|\ \le\ \tfrac Y2P^{-15/16}+C\Bigl(\frac YH+\sum_{h=1}^{H}\frac1h\Bigl|\sum_{n\in I\ \mathrm{odd}}e(hn^{9/16})\Bigr|\Bigr).
\]
Write \(n=2k+1\) and \(F_h(k)=h(2k+1)^{9/16}\); then
\(F_h'(k)=\tfrac98h(2k+1)^{-7/16}\) is monotone with
\(0<F_h'\le\tfrac98hP^{-7/16}\le\tfrac12\) for \(h\le H:=\tfrac49P^{7/16}\),
so the Kusmin--Landau inequality [13, Theorem 2.1] gives
\(|\sum_ke(F_h(k))|\ll 1/\min F_h'\ll P^{7/16}/h\). Hence
\(|\mathcal E(I)|\ll YP^{-15/16}+YP^{-7/16}+P^{7/16}\), and
\(P^{7/16}\le YP^{-1/16}\) for \(Y\ge P^{1/2}\). \(\square\)

**Lemma C.3 (a Fourier expansion of the fifth letter).** Let
\(J=\lfloor P^{1/24}\rfloor\). There are coefficients \(b_q\), \(0<|q|\le J\),
with \(|b_q|\ll 1/|q|\), and a nonnegative trigonometric polynomial
\(\Delta_J\) of degree \(J\) with all coefficients at most \(1/(J+1)\),
such that for every real \(y\),
\(\bigl|\psi(y)-\sum_{0<|q|\le J}b_qe(qy/2)\bigr|\le 2\Delta_J(y/2)\).
Moreover, for \(I\subseteq(P,2P]\) of length \(Y\ge P^{1/2}\),
\[
\sum_{n\in I\ \mathrm{odd}}\Delta_J\bigl(\tfrac12n^{9/16}\bigr)\ll YP^{-1/24}+P^{7/16}\log P,
\qquad
\Bigl|\sum_{n\in I\ \mathrm{odd}}e\bigl(\tfrac q2n^{9/16}\bigr)\Bigr|\ll\frac{P^{7/16}}{|q|}\quad(0<|q|\le J).
\]

*Proof.* \(\psi(y)=2\cdot\mathbf 1[\{y/2\}<\tfrac12]-1\), and Vaaler's
theorem [10] approximates the indicator of \([0,\tfrac12)\) modulo \(1\)
by a trigonometric polynomial of degree \(J\) with coefficients
\(\ll 1/|q|\) and constant term \(\tfrac12\), with error at most a
majorant \(\Delta_J\) of the stated form; the constant terms cancel in
\(2\cdot\mathbf 1-1\). For the two sums, write \(n=2k+1\): the phase
\(\tfrac q2(2k+1)^{9/16}\) has derivative \(\tfrac{9q}{16}(2k+1)^{-7/16}\),
monotone, of absolute value between \(\tfrac9{16}|q|(2P)^{-7/16}\) and
\(\tfrac9{16}P^{1/24-7/16}<\tfrac12\), so Kusmin--Landau gives
\(\ll P^{7/16}/|q|\). The \(\Delta_J\) sum is its constant term,
\(\le Y/(J+1)\), plus \((J+1)^{-1}\sum_{0<|r|\le J}|\sum_ne(\tfrac r2n^{9/16})|\ll P^{7/16}\log J/J\).
\(\square\)

**Proposition C.4 (conditional on Hypothesis L).** For \(m'\ge 2\),
\[
|\mathcal O(m')|=\tfrac1{16}\#\{n\ \text{odd}\in I(m')\}+O_\varepsilon\bigl(|I(m')|\,m'^{-4/27+\varepsilon}\bigr),
\]
every \(n\in\mathcal O(m')\) has \(J^4(n)\in E(m')\), and for a
backward-closed \(A\) and \(m'\in A\), \(\mathcal O(m')\subseteq A\) with
log-mass at least \(\frac1{9m'}\bigl(1-O(m'^{-4/27+\varepsilon})\bigr)\).

*Proof.* Along \(OOEEE\) the states \(J^0(n),\dots,J^4(n)\) are \(n\)
(odd), \(m\) (odd), \(v\) (even), \(\lfloor v^{1/2}\rfloor\) (even),
\(\lfloor\sqrt{\lfloor v^{1/2}\rfloor}\rfloor=\lfloor v^{1/4}\rfloor\)
(even; the inner identity is the exact nesting of square roots,
Lemma 3.2), and \(J^5(n)=\lfloor\sqrt{J^4(n)}\rfloor\). If \(J^5(n)=m'\)
then \(J^4(n)\in[m'^2,(m'+1)^2)\) is even, i.e. \(J^4(n)\in E(m')\), so
\(n\in A\) by Lemma 3.1 and backward closure. For the count, let
\(I=I(m')\), \(P=m'^{32/9}\), \(Y=|I|\). For \(n\in I\setminus\mathcal E(I)\),
Lemma C.1 gives \(\lfloor v^{1/4}\rfloor=\lfloor n^{9/16}\rfloor\), and
\(n\in I\) means \(n^{9/16}\in[m'^2,(m'+1)^2)\); hence for such \(n\)
with \(\mathrm{word}_5(n)=OOEEE\), \(J^4(n)=\lfloor n^{9/16}\rfloor\in[m'^2,(m'+1)^2)\)
and \(J^5(n)=m'\) automatically. Therefore
\[
\bigl|\,|\mathcal O(m')|-\#\{n\ \text{odd}\in I:\ \mathrm{word}_5(n)=OOEEE\}\,\bigr|\le|\mathcal E(I)|\ll YP^{-1/16}
\]
by Lemma C.2. Next, for odd \(n\) the indicator of \(OOEEE\) is
\(\tfrac1{16}(1-\psi_1)(1+\psi_2)(1+\psi_3)(1+\psi_4)\) with
\(\psi_4=\psi(v^{1/4})\): the factor \(1-\psi_1\) enforces \(m\) odd, so
that \(J^2(n)=v\) and \(\psi_2\) is its parity sign; \(1+\psi_2\)
enforces \(v\) even, so that \(J^3(n)=\lfloor v^{1/2}\rfloor\) and
\(\psi_3\) is its sign; \(1+\psi_3\) enforces \(J^3(n)\) even, so that
\(J^4(n)=\lfloor v^{1/4}\rfloor\) and \(\psi_4\) is its sign. Expanding
the product gives the main term \(\tfrac1{16}\#\{n\ \text{odd}\in I\}\)
and fifteen sign sums \(\pm\tfrac1{16}\sum_n\psi_1^a\psi_2^b\psi_3^c\psi_4^d\),
\((a,b,c,d)\ne 0\).

*Sums with \(d=0\).* These are Hypothesis L with \(\ell=0\): each is
\(\le YP^{-1/24+\varepsilon}\).

*Sums with \(d=1\).* Replace \(\psi_4=\psi(v^{1/4})\) by
\(\psi(n^{9/16})\): by Lemma C.1 the two agree off \(\mathcal E(I)\), so
the change is \(\le 2|\mathcal E(I)|\ll YP^{-1/16}\). Then expand
\(\psi(n^{9/16})\) by Lemma C.3:
\[
\sum_n\psi_1^a\psi_2^b\psi_3^c\,\psi(n^{9/16})
=\sum_{0<|q|\le J}b_q\sum_n\psi_1^a\psi_2^b\psi_3^c\,e\bigl(\tfrac q2n^{9/16}\bigr)
+O\Bigl(\sum_n\Delta_J\bigl(\tfrac12n^{9/16}\bigr)\Bigr),
\]
using \(|\psi_i|=1\) for the error. If \((a,b,c)\ne 0\), each inner sum
is Hypothesis L with \(\ell=q\), \(|q|\le J\le P^{1/24}\), and
\(\sum_q|b_q|\ll\log P\), so the total is \(\ll YP^{-1/24+\varepsilon}\log P\).
If \((a,b,c)=0\) the inner sums are the pure sums of Lemma C.3,
\(\ll P^{7/16}/|q|\), and their total against \(|b_q|\ll 1/|q|\) is
\(\ll P^{7/16}\). The majorant term is \(\ll YP^{-1/24}+P^{7/16}\log P\)
by Lemma C.3.

Collecting, with \(P^{7/16}\log P\le YP^{-1/16}\log P\) for
\(Y\ge P^{1/2}\), every error is \(\ll YP^{-1/24+\varepsilon}\), and
\(P^{-1/24}=m'^{-4/27}\). For the log-mass, each \(n\in\mathcal O(m')\)
has \(1/n\ge(m'+1)^{-32/9}\), and
\(\tfrac1{16}\cdot\tfrac12\cdot\tfrac{32}9m'^{23/9}=\tfrac19m'^{23/9}\).
\(\square\)

### C.3 The improved exponent

**Theorem C.5 (conditional on Hypothesis L).** Theorem 5.3 holds for
every \(\lambda<\lambda^{***}\approx0.5392\), the root of
\[
2^{-\lambda}+\tfrac19\bigl(\tfrac38\bigr)^{\lambda}+\tfrac29\bigl(\tfrac34\bigr)^{\lambda}+\tfrac19\bigl(\tfrac9{32}\bigr)^{\lambda}=1 .
\]

*Proof.* Add to the three families of Section 5.1 a fourth: for
\(m'\in A\cap(x^{9/64},x^{9/32}-1]\), the set \(\mathcal O(m')\); then
\(I(m')\subseteq(\sqrt x,x]\) because \(m'^{32/9}>\sqrt x\) and
\((m'+1)^{32/9}\le x\). Its members are odd with odd
\(\lfloor n^{3/2}\rfloor\), hence disjoint from the even members and
from the \(OE\)-type members of the first three families, and distinct
\(m'\) give disjoint \(I(m')\). By Proposition C.4 the family has
log-mass at least
\(\tfrac19(1-\varepsilon_7(x))\bigl(g_A(9t/32)-2x^{-9/32}\bigr)\) with
\(\varepsilon_7\to 0\), so (5.2) gains the term
\((\tfrac19-\varepsilon_7)g_A(9t/32)\). Lemma 5.1 applies with the
additional pair \((e_4,c_4)=(\tfrac9{32},\tfrac19)\) and the new root.
\(\square\)

Relative to the route \(\lambda^{**}\), every constant of Sections 7--10
improved: the rate threshold of Theorems 7.2--7.3 became
\(e>1-\lambda^{***}\approx0.4608\); the least depth constant of
Corollary 8.4 and Theorem 9.2 was \(C=18\) (\(e(18)\approx0.480\)); in
the one-sided form \(C(0.5)=18\), \(C(0.55)=39\). Theorems 5.19 and 5.20
now give stronger constants without Hypothesis L (Appendix B). Pairing plus \(OOEEE\) sits at \(0.5392\), above the
depth-two ceiling \(0.4927\), because \(OOEEE\) is an extra
production. A further production from the words \(OOOEE\) and \(OOEOE\)
on even blocks, at coefficient \(\tfrac2{27}\) and scale \(\tfrac{27}{64}\),
would give \(\lambda\approx0.6066\) and \(C=17\) in this model (earlier
versions printed \(0.5561\), which no recursion of this form gives).
Those fibers have length \(P^{5/32}\), below the threshold of the
localized triple, and the trivial bound on the kernel proof of an
earlier draft of Paper B covers the whole interval, so no analogue of
Hypothesis L for that kernel estimate is available (fate-contagion note
§7.4). That
concerns this appendix's localized route only. The averaged route of
Section 5.10 needs no analogue of Hypothesis L: Paper B's Theorem 6.3
gives the fair share on almost every such fiber, and Theorem 5.20 uses
both words at exponent \(37/50\).
Hypothesis L concerns consecutive odd starts in an
interval and says nothing about the odd images \(S_{\rm odd}\); the
free term \(\psi_F\) is untouched by this appendix.

## Appendix D. The finite nested productions

This appendix gives the analytic input used in (5.10). Only the
fixed words \(V_k=(OE)^{k-1}OEE\), \(1\le k\le6\), are used.
Constants may depend on \(k\) and on an arbitrarily small
\(\varepsilon>0\); no numerical constant or estimate uniform in
an unbounded depth is asserted. The classical estimates are those
used in Proposition 4.4.

### D.1 Exact endpoints and smooth weights

Put \(F(u)=\lfloor u^{3/4}\rfloor\) and
\(\Phi(a)=\lceil a^{4/3}\rceil\). For integers \(a<b\),
\[
\{n:a\le F(n)<b\}=[\Phi(a),\Phi(b))\cap\mathbb Z.
\tag{D.1}
\]
If \(n\) has word \(V_k\), repeated use of Lemma 3.2 gives
\(J^{2i}(n)=F^i(n)\) for \(0\le i\le k\), followed by the
last even step. With \(w=F^{k-1}(n)\), its final state is
\(J^{2k+1}(n)=\lfloor w^{3/8}\rfloor\).
Thus the exact landing window over \(m\ge2\) is
\[
I_k(m)=[\Phi^{k-1}(a),\Phi^{k-1}(b))\cap\mathbb Z,
\quad a=\lceil m^{8/3}\rceil,\quad b=\lceil(m+1)^{8/3}\rceil.
\tag{D.2}
\]
It contains precisely the desired preimages after imposing the
parity conditions of \(V_k\). Let
\(s=(3/4)^{k-1}\), \(\rho_k=3s/8\), and \(P=m^{1/\rho_k}\).
The mean value theorem, applied successively to \(u^{4/3}\), gives
endpoint error \(O_k(P^{1-s})\) relative to the smooth window
\([m^{1/\rho_k},(m+1)^{1/\rho_k})\). Consequently
\[
|I_k(m)|=\rho_k^{-1}m^{1/\rho_k-1}(1+o(1)),
\quad
\frac{|I_k(m)\mathbin\triangle I_k^{\rm sm}(m)|}{|I_k^{\rm sm}(m)|}
 =O_k(P^{-5s/8}).
\tag{D.3}
\]
Here and below interval length and integer count differ by at most
a bounded endpoint error.

Lean: (D.1) is `LandingWindow.exact_endpoints` and
`LandingWindow.setOf_cell34_mem_Ico`, and the nested window (D.2) is
`LandingWindow.exact_endpoints_iterate`, in
`formal/Problems/Juggler/FateLandingWindow.lean`. There
\(F\) is `cell34` and \(\Phi(a)=\lceil a^{4/3}\rceil\) is
`windowStart`, the least \(n\) with \(a^4\le n^3\), which is what
the ceiling means in exact arithmetic; the two are a Galois connection,
and that is the whole proof. `cell34_eq_floorPower_two` is
\(J^2=F\) on an \(OE\) step. The smooth comparison (D.3), the
endpoint error and the multiplicities are not formalized.

We also need the multiplicity of an inner-layer integer after
earlier layers have been summed out. For a fixed \(i\ge1\), put
\(p_i=(4/3)^i\). Induction in (D.1) gives
\[
\Phi^i(u)=u^{p_i}+O_i(u^{p_i-4/3}).
\]
For \(i=1\) the error is \(O(1)\); each further inverse step
multiplies the previous error by \(O(u^{p_i/3})\), and its own
rounding error is smaller. Taking the difference at \(u+1\) and
\(u\), and then counting odd integers, shows that the number of
odd \(n\) with \(F^i(n)=u\) is
\[
\omega_i(u)=\tfrac12p_i u^{p_i-1}
 +O_i(u^{p_i-4/3}+1)
 =\tfrac12p_i u^{p_i-1}(1+O_i(u^{-1/3})).
\tag{D.4}
\]
The last form uses \(p_i\ge4/3\). This weight has a smooth
monotone main term and a pointwise power-saving error. On any
layer interval of scale \(W\), partial summation transfers bounds
for all initial partial sums to this main weight; the pointwise
error costs \(O_i(W^{-1/3})\) relative to the total mass.
At most two partial end fibers occur at each grouping step. Their
relative size is at most \(O_k(P^{-5s/8})\), or a stronger power,
since the shortest relative layer interval has length
\(W^{5/8}\).

### D.2 Averaged cancellation inside the short fibers

Let \(v\) range over consecutive integers in an interval at scale
\(W\), of length \(L\gg W^{5/8}\), contained in a fixed dyadic
range. Write
\(B_v=[v^{4/3},(v+1)^{4/3})\cap\mathbb Z\).
The following bound holds on either parity class of \(u\), and on
the full integer lattice:
\[
\sum_v\left|\sum_{u\in B_v}\psi(u^{3/2})\right|
 \ll L W^{1/3}W^{-1/6}(\log W)^2.
\tag{D.5}
\]
The same right side bounds the sum over any initial subinterval
of the displayed \(v\)-range.

To see this, use Vaaler at \(Q=\lfloor W^{1/6}\rfloor\).
A nonzero Fourier mode on a parity class has phase
\(q(2r+b)^{3/2}/2\). Its derivative at the beginning of a
\(v\)-fiber is
\(\alpha_q(v)=\tfrac32qv^{2/3}+O(qW^{-2/3})\), and changes by
\(O(qW^{-1/3})\) across that fiber. As a function of \(v\), the
leading frequency increases in steps comparable to
\(\delta=qW^{-1/3}\). The full lattice has the same estimates
with a different fixed leading constant.

Fibers whose derivative range meets an integer, or lies within a
constant multiple of \(\delta\) of one, are counted trivially.
In each unit frequency interval there are \(O(1)\) such fibers;
there are \(O(L\delta+1)\) unit intervals. They contribute
\(O(qL+W^{1/3})\), since a fiber has \(O(W^{1/3})\) points.
For the remaining fibers, Kusmin--Landau bounds the mode by the
reciprocal distance of its derivative range to the nearest integer.
Grouping those distances in intervals of length comparable to
\(\delta\) gives a harmonic sum. Including the two incomplete
unit intervals at the ends, the total for this mode is
\[
\ll qL+L\log W+W^{1/3}(1+q^{-1}\log W)
 \ll qL+L\log W.
\tag{D.6}
\]
The last step uses \(L\gg W^{5/8}\). On an initial subinterval
use its length in the first bound, and the full \(L\) to dominate
the endpoint terms; thus the bound needed for partial summation
is uniform. Summing (D.6) against coefficients \(O(1/q)\) gives
\(O(LQ+L(\log W)^2)\). The error majorant contributes
\(O(LW^{1/3}/Q+LQ+L\log W)\), by its \(O(1/Q)\)
coefficients. These prove (D.5). Bounded coefficients depending
only on \(v\) may be inserted after the inner absolute value.

In terms of the outer variable scale \(Z=W^{4/3}\), the
relative saving in (D.5) is \(Z^{-1/8}\), up to logarithms.
This averaged estimate does not assert cancellation on every
individual fiber, which Lemma 4.7 shows would be false.

### D.3 The final one-variable estimate

On an interval \(K\) of scale \(W\) and length
\(L\asymp W^{5/8}\), each nonconstant product of the three signs
\[
(-1)^u,\qquad \psi(u^{3/2}),\qquad \psi(u^{3/4})
\]
has sum \(O_\varepsilon(LW^{-1/6+\varepsilon})\). The same
majorant holds for every initial subinterval of \(K\).

If the fast sign occurs, expand the fast and slow waves at
\(Q=\lfloor W^{1/6}\rfloor\). A nonzero fast mode has phase
\((q u^{3/2}+r u^{3/4}+bu)/2\), with \(b\in\{0,1\}\),
\(q\ne0\), and \(|q|,|r|\le Q\). Its second derivative has
constant sign and magnitude comparable to \(|q|W^{-1/2}\).
The second-derivative test bounds the sum by
\[
\ll L|q|^{1/2}W^{-1/4}+|q|^{-1/2}W^{1/4}.
\]
The coefficient sums, the two majorants and their bounded product
give
\[
\ll (LW^{-1/4}Q^{1/2}+W^{1/4}+L/Q)(\log W)^2
 \ll LW^{-1/6}(\log W)^2.
\]
For the slow majorant, the derivative is
\(\asymp |r|W^{-1/4}\), below \(1/2\), so Kusmin--Landau
gives the needed \(O(W^{1/4}/|r|)\) mode bound.

If only the slow wave occurs, pairing consecutive level sets of
\(\lfloor u^{3/4}\rfloor\) gives
\(O(LW^{-1/4}+W^{1/4})\). With the extra sign \((-1)^u\),
each level set instead has alternating sum \(O(1)\), giving
the same bound. The lone sign \((-1)^u\) sums to \(O(1)\).
All arguments retain these majorants on initial subintervals,
including their partial end cells. These estimates also apply
with the smooth weights (D.4).

### D.4 Assembly for the six words

For \(w_i=F^i(n)\), the indicator of \(V_k\) on odd starts is
\[
2^{-2k}(1+\psi(n^{3/2}))
 \prod_{i=1}^{k-1}(1-(-1)^{w_i})(1+\psi(w_i^{3/2}))
 (1+\psi(w_{k-1}^{3/4})).
\tag{D.7}
\]
For \(k=1\) the product is empty. Every factor records the
corresponding next parity after the preceding restrictions, so
(D.7) is an exact indicator identity; the iterates \(w_i\) are
never replaced by a single floor of a power of \(n\).

Expand (D.7). Its constant term gives \(2^{-2k}\) times the
number of odd integers in \(I_k(m)\). For each other term,
select the earliest layer with a remaining sign. Earlier layers
sum to the weight (D.4), including its negligible remainder.
If that layer has a fast sign and is not the final layer,
group by the next-layer integer and apply (D.5). An additional
sign \((-1)^u\) is handled by splitting into its two parity
classes. All later-layer factors are constant on the grouped
fiber and have magnitude at most one. If that layer has only
\((-1)^u\), sum alternately within each next-layer fiber;
partial summation gives an error at most a constant times the
smooth weight per fiber, saving a factor \(Z^{-1/4}\) at layer
scale \(Z\). If no earlier sign remains, apply Section D.3
on the final layer.

The scale of layer \(i\) is \(Z_i=P^{(3/4)^i}\), and its
interval length has order \(Z_i^{1-\rho_k/(3/4)^i}\).
The final layer has relative length \(5/8\); every preceding
layer has a longer relative interval. Thus all applications above
meet their length condition. The weakest fast-layer saving is
\(Z_{k-2}^{-1/8}=P^{-s/6}\), and the final-layer estimate saves
\(Z_{k-1}^{-1/6}=P^{-s/6}\). For \(k=1\) only Section D.3
is needed. The weight and endpoint errors in D.1 are smaller.
There are finitely many terms for each \(k\le6\), so
\[
\#\{n\in I_k(m):\mathrm{word}_{2k+1}(n)=V_k\}
 =2^{-2k}\#\{n\in I_k(m):n\text{ odd}\}
 +O_{k,\varepsilon}(|I_k(m)|P^{-s/6+\varepsilon}).
\tag{D.8}
\]
The location and length of the fiber, together with
\(s/(6\rho_k)=4/9\), turn this into the two-sided logarithmic
mass estimate
\[
\sum_{\substack{n\in I_k(m)\\\mathrm{word}_{2k+1}(n)=V_k}}\frac1n
 =\frac{3^{-k}}m\left(1+O_{k,\varepsilon}
 (m^{-4/9+\varepsilon})\right).
\tag{D.9}
\]
For shell sums, discard the bounded number of terminal source
integers whose exact fiber meets a shell boundary. The upper
endpoint perturbation in (D.3) is smaller than a source step
at that endpoint, and the lower endpoint is treated identically.
Their reciprocal source mass is exponentially small in the shell
logarithm. Summing (D.9) therefore gives the claimed coefficient
\(3^{-k}\) at source scale \(\rho_k t\), with vanishing errors.
Finally the prefix-free words give disjoint source sets, and the
subtraction in (5.9) proves (5.10). This completes the analytic
input to Theorem 5.3. \(\square\)

## Appendix E. Actual OOEE poor-fiber tail

This appendix supplies the written analytic input to Theorem 5.19.
It derives the short-interval estimate needed for the actual nested
floors, with all four parity guards. It does not invoke Paper B's
global estimate as an unproved localization.

### E.1 Statement and exact objects

For positive integers n put

\[
 O(n)=\lfloor n^{3/2}\rfloor,\quad Q(n)=\lfloor\sqrt n\rfloor,
 \quad a(n)=n+(n\bmod2),\quad
 w(n)=\log\frac{a(n)+1}{a(n)-1}.
\]

Let \(F_m\) contain exactly those n for which n and O(n) are odd,
\(O^2(n)\) and \(Q(O^2(n))\) are even, and \(Q^2(O^2(n))=m.\) Thus \(F_m\) is the
actual OOEE predecessor fibre, with all four parity guards. Write

\[
 W_m=\sum_{n\in F_m}w(n),\qquad R_m=W_m/w(m).
\]

**Theorem E.1 (poor-fibre tail).** For every fixed \(0<\eta<1/9,\)

\[
 \sum_{m\ge U:\ R_m<1/9-\eta}\frac1m
       \ll_\eta U^{-7/9}\qquad(U\ge1).
 \tag{E.1}
\]

The implied constant and the onset of the estimates may depend on eta.
No numerical onset is asserted. The proof also applies to the set
where \(|R_m-1/9|>\eta.\) It does not claim uniform convergence at every target.
The exact empty fibres in the branch dossier are consistent with (E.1).

Set \(B(a)=ceil(a^{2/3})\) and \(A_m=B(B(m^4)).\) The formal, unguarded
preimage of m under \(Q^2\) \(O^2\) is exactly

\[
 I_m=[A_m,A_{m+1})\cap\mathbb N.
 \tag{E.2}
\]

Indeed \(O(n)\ge a\) iff \(n^3\ge a^2,\) and \(Q^2(v)=m\) iff \(m^4\le v<(m+1)^4.\)
The ceilings give

\[
 m^{16/9}\le A_m\le m^{16/9}+2.
\]

Consequently, with \(P=m^{16/9}\) and \(H_m\) the number of odd integers in \(I_m,\)

\[
 |I_m|=\frac{16}{9}m^{7/9}+O(1),\qquad
 H_m=\frac89m^{7/9}+O(1),\qquad I_m\subseteq[P,2P]
 \tag{E.3}
\]

for all sufficiently large m. Interval length here means the difference
of its real endpoints; integer counts differ by at most a constant.
On odd n in \(I_m,\) \(w(n)=2/P\) times 1+O(1/m), uniformly. Also
\(w(m)=2/m\) times 1+O(1/m). Writing \(C_m=|F_m|\) gives

\[
 R_m=\frac89\frac{C_m}{H_m}+O(m^{-7/9}).
 \tag{E.4}
\]

The larger error \(m^{-7/9},\) rather than \(m^{-1},\) retains the integer
rounding in \(H_m.\) All constants in (E.2)--(E.4) are absolute.

### E.2 Classical analytic inputs

Write \(e(t)=\exp(2\cdot \pi\cdot i\cdot t).\) We use the following classical forms on arbitrary
real intervals, retaining an absolute endpoint term when necessary:

- If f' is monotone and stays at distance at least lambda from every
  integer, the Kusmin--Landau bound is \(O(1+\lambda^{-1}).\)
- If \(\lambda\le |f''|\le C\) lambda, then the second-derivative bound on an
  interval of length L is \(O_C(1+L\) \(sqrt(\lambda)+\lambda^{-1/2}).\)
- For N consecutive terms of modulus at most one and integer \(1\le D\le N,\)
  van der Corput differencing bounds the square of their sum by
  \(O(N^2/D+(N/D)\) \(sum_{1\le h<D}|T_h|),\) with overlap correlations \(T_h.\)
- The one- and three-dimensional Erdős--Turán--Koksma inequalities bound
  unnormalized interval or box discrepancy by the count divided by K,
  plus the finite Fourier sums weighted by the product of
  \(1/\max(1,|k_j|),\) for frequencies at most K.

These are the same tools as in [Paper B, Sections 3--4](juggler_parity_discrepancy_note.md).
For accessible statements and a proof of the differencing inequality, see
[Jammes, Section 2](https://math.univ-cotedazur.fr/~pjammes/publications/diviseurs95.pdf).
The second-derivative bound is also stated as Theorem E.10 in
[Bergelson--Richter](https://people.math.osu.edu/bergelson.1/BR_DensityCoprime.pdf).
The discrepancy reference is Kuipers--Niederreiter, \(\cdot Uniform\) Distribution
of \(Sequences\cdot ,\) Chapter 2, already indexed as
`kuipers-niederreiter-1974-uniform-distribution`.
No qualitative Hardy-field or global-count localization is used.

The finite differencing bullet is now kernel-checked, with constants
2 and 4 and exact overlap length N-h, in
[WeylDifferencing.lean](../../formal/BTCalculus/WeylDifferencing.lean).
Its exponential-sum specialization works directly on the odd lattice.
The [proof mapping](finite_weyl_differencing_note.md) distinguishes
this classical input from its phase-specific application. The
[first-derivative estimate](first_derivative_power_cancellation_note.md)
and the [quantitative second-derivative test](second_derivative_cancellation_note.md)
are now also kernel-checked. The latter has constants 4 and 8 on the
unit lattice, and 8 and 4 on the odd lattice. Uniform curvature of the
actual carry-cell phases and their unweighted \(O(P^{3/8})\) sums are now
kernel-checked in `OOEECurvature.lean`, including the growing shift range
and explicit floor conditions. The [proof mapping](juggler_ooee_curvature_note.md)
retains the extra endpoint required by the derivative test. The
[mixed-mode proof](juggler_ooee_mixed_modes_note.md) now supplies the carry
partition, weighted sums, Fourier errors, original phase comparison and
differencing. Pure slow modes and three-coordinate discrepancy are not
formalized as such; the Lean route to the production
(`OOEEResonanceTail`, `FateOOEEWeighted`) proves a count form of the
tail by its own argument.

### E.3 The short mixed estimate

For real \(x\ge 3\) define \(X(x)=x^{3/2},\) \(Z(x)=x^{9/8};\) for integer n put
\(M(n)=floor(X(n)),\) \(Y(n)=M(n)^{3/2}.\)

**Lemma E.2 (fixed mixed modes).** Fix constants \(K,L_0\ge 1.\) For every
integer triple (i,j,k) with \(\max(|i|,|j|,|k|)\le K\) and \((i,j)\ne (0,0),\)
and every interval I in [P,2P] of length at most \(L_0\) \(P^{7/16},\)

\[
 \sum_{n\in I,\ n\text{ odd}}
 e\left(\tfrac i2 X(n)+\tfrac j2 Y(n)+\tfrac k2 Z(n)\right)
       \ll_{K,L_0} P^{13/32}.
 \tag{E.5}
\]

K is fixed independently of P. This lemma expressly excludes the pure
slow modes (0,0,k). No estimate uniform in growing K is asserted.

#### E.3.1 The carry approximation on a short interval

Let \(b(t)={t}-1/2.\) For integer \(R\ge 2\) set

\[
 b_R(t)=-\sum_{1\le|r|\le R}\frac{e(rt)}{2\pi i r},\qquad
 E_R(t)=\min\{1,(R\|t\|)^{-1}\},
\]

with \(E_R=1\) at integers. The ordinary truncated Fourier series satisfies
\(b=b_R+O(E_R),\) including at integers; Paper B Lemma 4.3 proves this
pointwise assertion. We re-estimate its total error at the current length.

For any interval J in [P,3P] of length at most \(L_0\) \(P^{7/16},\)
the second-derivative test on the odd lattice gives

\[
 \left|\sum_{n\in J,\ n\text{ odd}} e(rX(n))\right|
 \ll_{L_0} P^{3/16}|r|^{1/2}+P^{1/4}|r|^{-1/2}+1.
 \tag{E.6}
\]

Here \(x=2t+1\) only changes fixed curvature constants. Apply the
one-dimensional discrepancy inequality with \(R=floor(P^{1/8}).\) Its
error is at most

\[
 O\left(P^{7/16}/R+P^{3/16}R^{1/2}+P^{1/4}+\log(2R)\right)
       =O(P^{5/16}).
\]

Splitting distances to the nearest integer into dyadic ranges starting
at 1/R therefore gives

\[
 \sum_{n\in J,\ n\text{ odd}} E_R(X(n))
          \ll_{L_0} P^{5/16}\log P.
 \tag{E.7}
\]

For clarity: at distance at most z there are O(z \(P^{7/16}+P^{5/16})\)
points. Each dyadic range contributes \(O(P^{7/16}/R)\) from its length,
while the discrepancy contribution forms a geometric sum. This also
counts exact integer values of X. The same bound holds for X(n+2h)
by translation of the odd interval. No dyadic exceptional set has been
multiplied by a short-interval length ratio.

#### E.3.2 Differencing, with a bounded number of carry cells

Suppose \(j\ne 0.\) Conjugating if necessary, take \(u=j/2>0;\) then \(1/2\le u\le K/2.\)
Use odd-lattice shifts 2h with \(1\le h\le D=floor(P^{1/16}).\) The overlap
interval still has length \(O_{L_0}(P^{7/16}).\) Write

\[
 \theta=\{X(n)\},\quad \delta(x)=X(x+2h)-X(x),\quad
 g(n)=M(n+2h)-M(n).
\]

The one-signed linearization, proved by factorization in Paper B Lemma 7.1,
is

\[
 Y(n)=\tfrac32 M(n)n^{3/4}-\tfrac12n^{9/4}+E(n),\qquad
 0\le E(n)\ll n^{-3/4}.
\]

It gives the exact identity

\[
 \Delta_hY(n)=A_h(n)+\tfrac32g(n)(n+2h)^{3/4}
       -\tfrac32\theta\Delta_h(n^{3/4})+\Delta_hE(n),
 \tag{E.8}
\]

where \(Delta_h\) \(f(x)=f(x+2h)-f(x)\) and

\[
 A_h(x)=\tfrac32x^{3/2}\Delta_h(x^{3/4})
                         -\tfrac12\Delta_h(x^{9/4}).
\]

Removing the last two terms of (E.8) from the exponential costs at most

\[
 O_K\left(hP^{7/16-1/4}+P^{7/16-3/4}\right)=O_K(P^{1/4}).
 \tag{E.9}
\]

The function delta is increasing and \(\delta'=O(hP^{-1/2}).\) Its floor
therefore cuts the overlap interval into

\[
 O_{L_0}(1+hP^{7/16-1/2})=O_{L_0}(1)
 \tag{E.10}
\]

cells, including the partial endpoint cells. On each cell freeze \(G=floor(\delta)\)
and let \(z=\delta-G.\) Then \(0\le z<1\) is monotone, G is of order h sqrt(P), and

\[
 g=G+\kappa,\qquad
 \kappa=z+b(X(n))-b(X(n+2h))\in\{0,1\}.
 \tag{E.11}
\]

Define the smooth cell phases

\[
 F_{G,\epsilon}(x)=u A_h(x)+\tfrac{3u}{2}(G+\epsilon)(x+2h)^{3/4}
        +\tfrac i2\delta(x)+\tfrac k2\Delta_hZ(x),\quad \epsilon=0,1.
\]

The exponential remaining after (E.9) equals, exactly,

\[
 (1-z)e(F_{G,0})+z e(F_{G,1})+
 (b(X(n))-b(X(n+2h)))(e(F_{G,1})-e(F_{G,0})).
 \tag{E.12}
\]

This follows by substituting (E.11) into
\((1-kappa)e(F_{G,0})+kappa\) \(e(F_{G,1}).\) There is no independence assumption.

#### E.3.3 Every local error term

The identity \(A_h(x)=x^{9/4}\) a(2h/x), with
\(a(t)=(3/2)((1+t)^{3/4}-1)-(1/2)((1+t)^{9/4}-1),\) has \(a(0)=a'(0)=0.\)
Writing \(a(t)=t^2\) \(a_2(t),\) whose first two derivatives are bounded near zero,
shows \(A_h''=O(h^2\) \(P^{-7/4}).\) Thus on each fixed cell

\[
 F_{G,\epsilon}''(x)=-\frac9{32}u(G+\epsilon)(x+2h)^{-5/4}
     +O_K(h^2P^{-7/4}+hP^{-3/2}+hP^{-15/8}).
 \tag{E.13}
\]

Its curvature is comparable to u h \(P^{-3/4},\) with a fixed sign and
bounded ratio, uniformly in \(h\le P^{1/16}.\) The second-derivative estimate
and partial summation for z and 1-z bound the first two terms of (E.12) by

\[
 O_{K,L_0}\left(P^{7/16}(uh)^{1/2}P^{-3/8}
                         +(uh)^{-1/2}P^{3/8}+1\right)
       =O_{K,L_0}(P^{3/8}).
 \tag{E.14}
\]

The endpoint term \(P^{3/8}\) is retained. There are only \(O_{L_0}(1)\) cells.

Replace the two b functions in (E.12) by \(b_R.\) By (E.7) and
\(|e(F_1)-e(F_0)|\le 2,\) their total remainder is \(O(P^{5/16}\) log P),
even after the partition. Each nonzero Fourier mode now has phase
\(F_{G,\epsilon}+rX(x)\) or \(F_{G,\epsilon}+rX(x+2h).\) Its curvature is comparable
to \(|r|P^{-1/2}:\) the competing curvature divided by that quantity is
\(O_K(h\) \(P^{-1/4}/|r|)=O_K(P^{-3/16}).\) Hence the modes, summed with their
O(1/|r|) coefficients over \(1\le |r|\le R=P^{1/8},\) cost

\[
 O_{K,L_0}\left(P^{3/16}R^{1/2}+P^{1/4}+\log(2R)\right)
                 =O_{K,L_0}(P^{1/4}).
 \tag{E.15}
\]

Combining (E.9), (E.14), (E.7), and (E.15), every overlap correlation obeys
\(|T_h|=O_{K,L_0}(P^{3/8}).\) In particular, the carry error is smaller than
this bound; log P is absorbed by the gap \(3/8-5/16=1/16.\)

If the odd count N in I is at least D, differencing gives

\[
 |S|^2\ll_{K,L_0} P^{7/8-1/16}+P^{7/16+3/8}
                     =O_{K,L_0}(P^{13/16}).
 \tag{E.16}
\]

If \(N<D\) the trivial estimate is already stronger. This proves (E.5) for \(j\ne 0.\)
If \(j=0\) and \(i\ne 0,\) the undifferenced smooth phase has curvature comparable
to \(|i|P^{-1/2},\) since the k term has curvature \(O_K(P^{-7/8}).\) Its sum
is \(O_{K,L_0}(P^{1/4}),\) which also proves (E.5). This completes Lemma E.2.

### E.4 The pure slow modes and the actual last guard

Let \(V(n)=floor(Y(n)).\) Uniformly for n in [P,2P],

\[
 |\sqrt{V(n)}-n^{9/8}|\ll P^{-3/8}.
 \tag{E.17}
\]

Indeed replacing sqrt(floor(Y)) by \(sqrt(Y)=M^{3/4}\) costs \(O(P^{-9/8});\)
replacing \(M=X-theta\) by X in the 3/4 power costs \(O(P^{-3/8}).\) The mean
value theorem applies on positive intervals bounded below by constant
multiples of the relevant powers. Thus replacing Z by sqrt(V) in a
fixed-frequency exponential sum costs \(O_K(P^{1/16}),\) negligible in (E.5).
We use (E.17) for exponential sums, not to assert equality of floor parities.

Put \(\alpha_m=(9/8)m^{2/9}.\) In the odd coordinate \(n=2t+1,\)
the derivative of \((k/2)n^{9/8}\) is \((9k/8)n^{1/8}.\) On \(I_m\) it differs
from k \(\alpha_m\) by at most

\[
 C_0 |k|m^{-7/9}
 \tag{E.18}
\]

for an absolute \(C_0.\) This follows from (E.3) and the derivative bound
for \(x^{1/8},\) since \(P^{-7/8}\) \(P^{7/16}=m^{-7/9}.\) The derivative is monotone.

For fixed integers \(K\ge 1\) and real \(C>2\) \(C_0\) K, suppose

\[
 \|k\alpha_m\|>C m^{-7/9}\quad(1\le k\le K).
 \tag{E.19}
\]

For sufficiently large m the derivative of each pure slow phase stays
in one interval between consecutive integers and at distance at least
\((C/2)m^{-7/9}\) from them. Kusmin--Landau gives

\[
 \left|\sum_{n\in I_m,\ n\text{ odd}}e\left(\tfrac k2 Z(n)\right)\right|
       \ll m^{7/9}/C+1\ll H_m/C+1.
 \tag{E.20}
\]

Negative k follow by conjugation. Equation (E.17) gives the same bound
with an additional \(O_K(P^{1/16})\) for the actual sqrt(V) phase.

### E.5 Joint parity, resonance inclusion, and the tail

Apply three-dimensional box discrepancy to the actual points

\[
 \left(\{X(n)/2\},\{Y(n)/2\},\{\sqrt{V(n)}/2\}\right),
                  \qquad n\in I_m,\ n\text{ odd}.
\]

The box [1/2,1) times [0,1/2) times [0,1/2) specifies exactly the three
remaining OOEE guards. Its volume is 1/8. Half-open boundaries encode
integer-floor parity exactly, including square and cube coincidences.

For fixed K and C as above and m satisfying (E.19), Lemma E.2 controls every
mode with \((i,j)\ne (0,0),\) and (E.20) controls the pure slow modes. Therefore

\[
 \left|C_m/H_m-1/8\right|
   \le A/K+A\log(2K)/C+O_{K,L_0}(P^{-1/32})
                         +O_K(P^{-3/8})+O_K(H_m^{-1}),
 \tag{E.21}
\]

where A is absolute; fixed logarithmic frequency weights are absorbed in
the indicated constants. For any \(\epsilon>0,\) first choose K so the first
term is less than epsilon/3; then choose \(C>2\) \(C_0\) K so the second is less
than epsilon/3; finally choose m large so the remaining terms total less
than epsilon/3. This order keeps K and C independent of m.

Together with (E.4), this proves: for every \(\eta>0\) there are fixed
\(K_\eta,C_\eta\) and \(m_\eta\) such that

\[
 m\ge m_\eta,\ |R_m-1/9|>\eta
 \quad\Longrightarrow\quad
 \exists\,1\le q\le K_\eta:\quad
       \|q\alpha_m\|\le C_\eta m^{-7/9}.
 \tag{E.22}
\]

For example, take \(\epsilon=\eta/4\) and enlarge \(m_\eta\) until the error in (E.4)
is at most eta/4. Strict poor inequalities \(R_m<1/9-\eta\) are contained
in this absolute-deviation set.

For fixed q, the derivative of q \(\alpha_m\) is \((q/4)m^{-7/9}.\)
On [M,2M), each window within \(C_\eta\) \(M^{-7/9}\) of an integer has
preimage length at most 8 \(C_\eta\) \(2^{7/9}/q.\) There are
O(q \(M^{2/9}+C_\eta+1)\) possible integer levels. Counting integers in
these bounded intervals, then summing over \(q\le K_\eta,\) gives

\[
 \#\{M\le m<2M:\ m\text{ satisfies the right side of (E.22)}\}
                \ll_\eta M^{2/9}.
 \tag{E.23}
\]

The same bound for deficient targets follows beyond \(m_\eta;\) increasing
its constant absorbs the finite initial set. Division by M and summation
over dyadic blocks starting at U yields (E.1). This proves Theorem E.1.

### E.6 What the coefficient now supplies

For any subset A of the positive integers, any finite target cutoff X,
and fixed \(0<\eta<1/9,\) Theorem E.1 and \(w(m)\le 4/m\) give

\[
 \sum_{m\in A,\ m\le X} W_m
    \ge (1/9-\eta)\sum_{m\in A,\ m\le X}w(m)-C_\eta.
 \tag{E.24}
\]

The constant is independent of A and X. Separate the poor targets and
use their bounded total w-mass; all \(W_m\) are nonnegative. Fibres for
different targets are disjoint. If A is backward closed under the actual
Juggler map, every source in these fibres also belongs to A.


The physical source cutoffs and three-production recursion are proved
in Section 5.9. This appendix is the written argument, pending
independent review. The production it feeds is also kernel-checked, by
its own formal route: `OOEEMixedModes` for the mixed modes,
`OOEEResonanceTail` for the summable count-poor tail and
`FateOOEEWeighted` for the production at coefficient \(11/100\).

## Acknowledgments and use of AI

Large language models assisted the development of this work, including the
prose, proposed proof arguments, the Lean formalizations, and the computations.
AI assistance is not independent mathematical validation. The formalization
covers only the results identified in Section 1.4 and Appendix A. The author is
responsible for the statements, proofs, code, and the decision to make this
version public.

## Availability and version

This is version 1.3.0 of Paper C, of 24 September 2026. It is a preprint
and has not been refereed. It raises the contagion exponent to 37/50
(Section 5.10), using Theorem 6.3 of Paper B, and lowers the sufficient
rate threshold to 13/50. It records that the log-mass bound of Theorem
5.19, at 5/8 with the threshold 3/8, is now kernel-checked, and it
updates the depth constants, the proof-status map, the comparisons of
Appendix B and the citations of Paper B. Version 1.2.0, prepared on 22
September 2026 and not deposited, added the written OOEE poor-fiber
proof, contagion at 5/8, the scale-average criterion of Section 9.5, and
the corrected distinction between finite and unbounded stopping-word
moments in Section 5.7. Earlier Zenodo versions are 1.1.0
([doi:10.5281/zenodo.22865705](https://doi.org/10.5281/zenodo.22865705)) of
21 September 2026, which added Section 5.8 with its Lean layer, the corresponding
rows of Section 1.4 and Appendices A and B, the remarks of Sections 5.7, 6.3 and
7.1, and the exponent \(\lambda_{\mathrm{ideal}}\) in the statements, and
1.0.0 ([doi:10.5281/zenodo.22678165](https://doi.org/10.5281/zenodo.22678165)) of
9 September 2026. The concept DOI
[10.5281/zenodo.22678164](https://doi.org/10.5281/zenodo.22678164) resolves to the
latest version; the record of version 1.1.0 is at
<https://zenodo.org/records/22865705>.
The author's ORCID is
[0009-0004-1939-3382](https://orcid.org/0009-0004-1939-3382).
A later revision goes up through the record's new-version operation, which
keeps the concept DOI, rather than as a new deposit.
The changes between versions are listed in the build guide,
`PAPER_C_BUILD.md`, in the repository. The accompanying
source package contains the Markdown and LaTeX sources, figures,
the local Lean dependency closure with its pinned toolchain,
numerical audit code, archived experiment records, and a manifest
of file hashes. The repository is
[sneakyweasel/btlab](https://github.com/sneakyweasel/btlab).
The original development notes remain historical records;
where their statements differ, the corrected proofs and scopes
in this version of Paper C govern this preprint.

## References

1. C. A. Pickover, *Computers and the Imagination: Visual Adventures
   Beyond the Edge*, St. Martin's Press, New York, 1991, ch. 40.
2. OEIS Foundation Inc., "Juggler sequence: if \(n\) even then
   \(\lfloor\sqrt n\rfloor\) else \(\lfloor n^{3/2}\rfloor\),"
   Sequence A094683 in *The On-Line Encyclopedia of Integer Sequences*,
   https://oeis.org/A094683 (accessed 9 September 2026).
3. J. C. Lagarias, "The \(3x+1\) problem and its generalizations,"
   *Amer. Math. Monthly* 92 (1985), 3–23.
   [doi:10.1080/00029890.1985.11971528](https://doi.org/10.1080/00029890.1985.11971528).
4. R. Terras, "A stopping time problem on the positive integers,"
   *Acta Arith.* 30 (1976), 241–252.
   [doi:10.4064/aa-30-3-241-252](https://doi.org/10.4064/aa-30-3-241-252).
5. C. J. Everett, "Iteration of the number-theoretic function
   \(f(2n)=n\), \(f(2n+1)=3n+2\)," *Adv. Math.* 25 (1977), 42–45.
   [doi:10.1016/0001-8708(77)90087-1](https://doi.org/10.1016/0001-8708(77)90087-1).
6. T. Tao, "Almost all orbits of the Collatz map attain almost bounded
   values," *Forum Math. Pi* 10 (2022), e12.
   [doi:10.1017/fmp.2022.8](https://doi.org/10.1017/fmp.2022.8).
7. I. Krasikov and J. C. Lagarias, "Bounds for the \(3x+1\) problem
   using difference inequalities," *Acta Arith.* 109 (2003), 237–258.
   [doi:10.4064/aa109-3-4](https://doi.org/10.4064/aa109-3-4).
8. J. C. Lagarias (ed.), *The Ultimate Challenge: The \(3x+1\)
   Problem*, American Mathematical Society, Providence, RI, 2010. [doi:10.1090/mbk/078](https://doi.org/10.1090/mbk/078).
9. E. W. Weisstein, "Juggler Sequence," *MathWorld — A Wolfram Web
   Resource*, https://mathworld.wolfram.com/JugglerSequence.html.
10. J. D. Vaaler, "Some extremal functions in Fourier analysis,"
    *Bull. Amer. Math. Soc. (N.S.)* 12 (1985), 183–216.
    [doi:10.1090/S0273-0979-1985-15349-2](https://doi.org/10.1090/S0273-0979-1985-15349-2).
11. P. Cochin, "Lower Bounds for Cycle Lengths in the Juggler Map"
    (Paper A), Zenodo version 1.0.2, 20 September 2026,
    [doi:10.5281/zenodo.22865237](https://doi.org/10.5281/zenodo.22865237); concept DOI
    [10.5281/zenodo.22676452](https://doi.org/10.5281/zenodo.22676452) for all versions;
    revision of 21 September 2026 at
    `docs/theory/juggler_finite_dynamics_note.md` in the repository
    https://github.com/sneakyweasel/btlab/.
12. P. Cochin, "Five-Step Descent Certificates for the Juggler Map: Parity Statistics of Nested Floor Powers" (Paper B), Zenodo version
    1.2.0, 24 September 2026,
    [doi:10.5281/zenodo.22946276](https://doi.org/10.5281/zenodo.22946276); concept DOI
    [10.5281/zenodo.22864933](https://doi.org/10.5281/zenodo.22864933) for all versions;
    `docs/theory/juggler_parity_discrepancy_note.md`, same repository. Its
    Theorem 6.3 and Appendix D are the input of Section 5.10.
13. S. W. Graham and G. Kolesnik, *Van der Corput's Method of
    Exponential Sums*, London Mathematical Society Lecture Note
    Series 126, Cambridge University Press, Cambridge, 1991. [doi:10.1017/CBO9780511661976](https://doi.org/10.1017/CBO9780511661976).
14. P. Cochin, research notes on fate contagion, the Tao-type
    reduction and the poor-fiber tail for the Juggler map, 2026;
    `docs/theory/juggler_fate_contagion_note.md`,
    `docs/theory/juggler_tao_reduction_note.md` and
    `docs/theory/juggler_oe_poor_fiber_tail_note.md`, same repository.
15. L. Kuipers and H. Niederreiter, *Uniform Distribution of
    Sequences*, Wiley-Interscience, New York, 1974.
