# Paper C: sources

Fate Contagion and Termination Criteria for the Juggler Map, Cochin, Philippe, version 1.3.0.
This archive preserves repository paths; extract it into an empty directory.

## Contents

- `docs/theory/juggler_fate_almost_all_note.md`, the canonical manuscript, with the generated LaTeX `docs/theory/cochin-juggler-fates.tex` and the PDF `preprints/juggler_fate_almost_all_note.pdf`.
- `docs/theory/paper_c_release.json`, the SHA-256 of all 148 inputs and 3 outputs, and `docs/theory/paper_c_zenodo.json`, the Zenodo metadata.
- `tools/build_paper.py` with `tools/papers/c.json`, the same builder every laboratory paper uses, and the template and layout filter in `tools/paper_c/`.
- 118 Lean files: the paper's local import closure and its axiom audits. Mathlib and the Lean toolchain are not included; Lake fetches the versions `formal/lake-manifest.json` pins.
- The written OOEE notes, the numeric and interval checkers, the figure script and figures, and the data files Appendix B lists by SHA-256.
- `SHA256SUMS.txt`, the digest of every other member.

Third-party software, private correspondence and unpublished manuscripts are not included. Links in the documents to other laboratory records refer to the repository https://github.com/sneakyweasel/btlab.

## Verify

Python 3.11 or later, standard library only. From the extracted root:

```text
python tools/build_paper.py C --check-release
```

The first command checks every input and output against the release manifest.

For the formal proofs, install elan, then from `formal/`:

```text
lake exe cache get
lake build Problems.JugglerFatePaper
lake env lean AxiomCheckPaperC.lean
```

## Rebuild

With Pandoc and XeLaTeX installed, `python tools/build_paper.py C` rebuilds the PDF, LaTeX, metadata and manifest. The build fixes `SOURCE_DATE_EPOCH`; with pandoc.EXE 3.6.3 and MiKTeX-XeTeX 4.18 (MiKTeX 26.5) it reproduces the PDF byte for byte.

## Scope

Theorem 5.20's contagion 37/50 rests on Paper B's Theorem 6.3, an AI-assisted written proof without independent review; the log-mass bound at 5/8 is kernel-checked. Neither universal termination nor the exclusion of nontrivial cycles or unbounded orbits is established.

The manuscript is licensed CC BY 4.0 and the software under the repository `LICENSE`.
