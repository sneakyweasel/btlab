# Paper E: sources

The Juggler Map and the 3n±1 Maps: Exact Coding and Arithmetic Obstructions, Cochin, Philippe, version 0.8.1.
This archive preserves repository paths; extract it into an empty directory.

## Contents

- `docs/theory/juggler_signed_collatz_note.md`, the canonical manuscript, with the generated LaTeX `docs/theory/cochin-juggler-signed-collatz.tex` and the PDF `preprints/juggler_signed_collatz_note.pdf`.
- `docs/theory/paper_e_release.json`, the SHA-256 of all 168 inputs and 3 outputs, and `docs/theory/paper_e_zenodo.json`, the Zenodo metadata.
- `tools/build_paper.py` with `tools/papers/e.json`, the same builder every laboratory paper uses, and the template and layout filter in `tools/paper_e/`.
- 110 Lean files: the paper's local import closure and its axiom audits. Mathlib and the Lean toolchain are not included; Lake fetches the versions `formal/lake-manifest.json` pins.
- The integer certificate of Theorem 5.1, `data/research/juggler/negative_preimage_density/grid_k12_certificate.json` (177147 weights), with its generator.
- The finite checker `tools/check_paper_e.py`, the written notes behind the analytic lemmas and Section 7.3, and citation records (metadata, not copies of the cited works).
- `SHA256SUMS.txt`, the digest of every other member.

Third-party software, private correspondence and unpublished manuscripts are not included. Links in the documents to other laboratory records refer to the repository https://github.com/sneakyweasel/btlab.

## Verify

Python 3.11 or later, standard library only. From the extracted root:

```text
python tools/build_paper.py E --check-release
python tools/check_paper_e.py
PYTHONPATH=src python tools/generate_signed_grid_certificate.py --check
```

The first command checks every input and output against the release manifest.
The checker recomputes every certificate row with integers, the grid phases, the small-orbit barrier, the examples and the exact comparisons, and checks that the saved Lean audit covers the declared inventory. On Windows PowerShell set `$env:PYTHONPATH = "src"` before the second command.

For the formal proofs, install elan, then from `formal/`:

```text
lake exe cache get
lake build Problems.JugglerCollatzPaper
lake env lean AxiomCheckJugglerCollatzPaper.lean
```

## Rebuild

With Pandoc and XeLaTeX installed, `python tools/build_paper.py E` rebuilds the PDF, LaTeX, metadata and manifest. The build fixes `SOURCE_DATE_EPOCH`; with pandoc.EXE 3.6.3 and MiKTeX-XeTeX 4.18 (MiKTeX 26.5) it reproduces the PDF byte for byte.

## Scope

Finite checks do not prove Theorem 4.1's infinite equidistribution statement; its Lean proof does. The divergence premise of Proposition 7.4 is open. Independent mathematical review is outstanding. Grid material adapted from M. Sharpe's repository keeps its MIT notice in the Lean sources.

The manuscript is licensed CC BY 4.0 and the software under the repository `LICENSE`.
