# Signed Collatz preimage density: a checked strict-grid proof

Status: **PROMOTE** (22 September 2026). The 3n-1 ancestor bound with
exponent 21/25 is now kernel-checked. The proof includes actual capped-tree
recurrences, a closed root domain for every positive target prime to 3,
the well-founded growth induction, an independent 177147-row integer
certificate, and interpolation to every sufficiently large natural cutoff.
The original assertion of automatic transfer by residue relabelling remains
withdrawn; the strict-grid argument supplies the missing height control.
The same day's mean-constraint follow-up proves a limit of this fixed
grid: at every finite residue level, either sign's positive certificate
with rate mu^50<=2 has mu<5069/5000, and hence exponent below 0.99.
The harmonic rate mu^50=2 is impossible. This is a certificate-method
limitation, not an upper bound on actual ancestor counts.

Branch of the [Collatz bridge](juggler_collatz_bridge.md). The exact
predecessor comparison is now kernel-checked in
[PreimageScale.lean](../../formal/Problems/Collatz/PreimageScale.lean).

## Problem

Does the known positive 3x+1 preimage-count exponent also follow for
the 3n-1 shortcut map from the residue program already implemented here?
The previous answer conflated its residue symmetry with validity of
the associated inequalities for actual height-truncated inverse trees.

## Exact statement

For g(n)=n/2 at even n and (3n-1)/2 at odd n, every positive target a
not divisible by 3 admits X_0 such that, for every natural X>=X_0,

\[
X^{21}\le N(a,X)^{25}.
\]

Here N counts positive starts at most X whose orbit reaches a while every
intermediate state stays at most X. The ordinary positive ancestor count
is at least N, so it also satisfies the bound. Equivalently there are at
least X^(21/25)=X^0.84 positive ancestors up to X for all large natural X.
The Lean declarations are `PreimageCertificate12.density_21_25` and
`PreimageCertificate12.ancestor_density_21_25`. Both compile without
additional hypotheses. The ledger retains `EXACT — HUMAN PROOF` pending
advisory statement-coverage review; the local kernel proof is complete.

The proof retains the sign-dependent scale comparison. For a=1 mod 3,
the odd predecessor c=(2a+1)/3 satisfies

\[
c>2a/3,\qquad
\frac{x}{c}=\frac{(x/a)(3/2)}{1+1/(2a)}.
\]

For the plus map, a=2 mod 3 gives c=(2a-1)/3<2a/3. Thus the nominal
child cutoff (x/a)(3/2)c is below x for plus, but above x for minus.
The residue classes transpose; this Archimedean inequality reverses.

## Current literature

[Krasikov–Lagarias, 2003](https://arxiv.org/abs/math/0205002) prove the
x^0.84 bound for positive targets under 3x+1. Section 2 defines the
height-truncated count and its residue-class infimum. Proposition 2.1
supplies the difference inequalities; Theorem 2.2 uses their validity,
positivity, and monotonicity. Theorem 6.1 supplies the numerical exponent.
The published theorem does not directly cover positive 3n-1 targets.

Their Sections 3–5 remove advanced terms and transfer feasible solutions
to a derived system. Invoking that machinery for minus still requires
a proof that the actual minus-tree counting functions satisfy suitable
inequalities. Equality of two formal programs is not that proof.

The [published 2003 version](https://www.impan.pl/shop/en/publication/transaction/download/product/81918)
also explicitly restricts Theorem 6.1 to positive targets. The older
[Applegate–Lagarias Part II preprint](https://dept.math.lsa.umich.edu/~lagarias/doc/applegateII.pdf)
states its 0.81 result in an integer-wide introduction, but its displayed
normalization (2.2) uses 2^y a, while (2.1) counts absolute heights.
That broad statement alone does not reconstruct the signed height step
needed here. We do not use it to certify the stronger 0.84 transfer.

**A different proof route.** M. Sharpe's
[KLGrid.lean](https://github.com/msharpe248/collatz/blob/main/lean/Collatz/KLGrid.lean)
uses a 1/50 grid and induction on 10t+floor(log2(a^498)) for positive
roots. The slight loss in the advanced shift makes this measure decrease;
working with individual roots avoids deletion inside residue minima.
We inspected that proof and its hypotheses, including the root's reaching
8. We did not rebuild or independently audit the external repository's
large density certificates. Its MIT cap table and method are attributed in
our [PreimageGrid.lean](../../formal/Problems/Collatz/PreimageGrid.lean).
The signed inequalities below are locally kernel-checked with their
different cutoff comparison and explicit root threshold.

## Branch budget

- **Target:** audit the scale inequalities behind the recorded transposition.
- **Novelty hypothesis:** residue symmetry omitted a signed height correction.
- **Falsifier:** a uniform justification of the same shifts in the source proof.
- **Already killed by?:** not the backward-mass obstruction, which concerns
  harmonic mass rather than this counting theorem.
- **Existing machinery:** the signed predecessor maps and original paper.
- **Maximum Phase-0 scope:** exact scale comparison, Lean proof, and claim correction.
- **Promotion criterion:** justified transfer or a precise verified missing premise.
- **Stop criterion:** no density conclusion from matching residues or solvers.

Follow-up scope: prove the three actual minus-tree recurrences and a
decreasing natural-number induction measure above a fixed root threshold.
The falsifier is a failed cutoff inclusion or measure decrease. This is
not the closed exact-shift transfer: a strict grid margin is retained.
Promotion requires statements about genuine height-truncated integer
trees. Stop before claiming a density exponent without a closed root
domain and a checked growth certificate.

Closed-domain phase (completed): close the root domain without classifying all
cycles. Kernel-check a finite orbit barrier, construct a large nonperiodic
fertile ancestor for every positive unit target, and prove closure and
eventual count transfer. The subsequent density phase supplied the growth
induction and the level-12 certificate recorded below.

Current follow-up scope: sum the exact finite residue rows, prove a
table-size-independent necessary inequality, and check its rate obstruction
in Lean. Stop after deciding whether increasing the table size alone can
reach the harmonic exponent. No new numerical weight search or grid change.

## Balanced-ternary formulation

Residues modulo 3^k describe integrality of backward branches. They do
not determine the height cutoff. No BT representation change is used.

## Why BT may be relevant

Only through ternary residue bookkeeping. No termination input follows.

## Candidate operations / invariants

Negation sends fertile classes 2 mod 3 to 1 mod 3 and permutes the
mod-9 classes 2,5,8 to 7,4,1. It also transposes the quotient indices
and the three lifts. The existing finite exact checks of this algebra
remain valid. The formal programs attach the same homogeneous shifts
to both signs; the missing premise is their application to actual counts.

## Experiments

`python -m research.juggler_sequence.negative_preimage_density` now
records the completed strict-grid exponent 21/25 and its checked integer
certificate. Its older homogeneous solver outputs remain explicitly labelled
residue-model comparisons. The archived high-k model values are historical
numerical results, not newly certified bounds.

The independent forward enumeration agrees with the backward BFS:

| Child target | Cutoff | Ancestors with whole path below cutoff |
|---|---:|---:|
| 13 | 103 | 12 |
| 13 | 105 | 13 |

The old wrong-sign regression had never tested its alleged identity:
for a=1 mod 3 its guard `(2*a-1) % 3 == 0` is always false. It now
reports that nonintegrality explicitly. The BFS also returns zero when
its root itself is outside the positive cutoff interval.

The grid checks cover all 50 rounding phases, and independently test
integer roots and capped inverse trees. Two boundary diagnostics are
retained: the grid cutoff itself fails at a=19, while a=4096 has the
smaller odd predecessor 2731. Thus a lower root threshold by itself is
not an invariant domain for a growth induction.

## Conjectures

`J-kl-preimage-density-transposes-to-3n-1` now records the complete
strict-grid proof with tag **EXACT — HUMAN PROOF**, named kernel-checked
Lean declarations, and advisory statement coverage pending. The earlier
return to conjecture status concerned the missing height argument;
the completed proof below resolves that gap.

## Counterexamples

Take a=19, c=13, x=103. The copied homogeneous shift gives child
cutoff 4017/38, between 105 and 106. It includes the genuine path
104 -> 52 -> 26 -> 13, which is excluded at cutoff 103.
Also x>=4a, so this is inside the original y>=2 regime.
The target is nonperiodic: 19 -> 28 -> 14 -> 7 -> 10 -> 5 -> 7.
Both facts are kernel-checked.

This refutes the proposed pointwise cutoff inclusion. It does not
refute every possible difference inequality for the residue infima:
additional terms or another normalization might compensate, but that
requires a separate proof. In particular, the counterexample does not
refute an eventual x^0.84 lower bound.

## Formalization

`PreimageScale.lean`, imported by `Problems.lean`, proves the exact
odd predecessor equations for both signs, their opposite comparisons
with 2a/3, the correction factor, and the reversed nominal-budget
inequalities for every positive real cutoff. `excluded_ancestor`
checks the finite path and its location; `nineteen_not_periodic`
checks all positive return times by a finite forward invariant set.
These initial lemmas do not themselves establish the density exponent.
The later growth, certificate, and cutoff modules complete that proof.
The all-level residue-program isomorphism is not claimed to be formalized.

The follow-up adds `inverseWord` for the real inverse letters
E(x)=2x and O(x)=(2x+1)/3. `inverseWord_affine` proves
f_w(x)=R_w x+B_w with R_w>0 and B_w>=0. These are formal real
itineraries; actual integer paths still need their branch guards.
`shifted_block_iff`, `shifted_blocks`, and `finite_expanding_shift`
prove the uniform correction below. `internal_prefix_height` also
controls intermediate states. `two_step_preimage` verifies that the
OE example is an actual predecessor at fertile integer targets.
`no_elementary_shift` proves why the same method cannot apply to both
single letters with their original multipliers.

`PreimageGrid.lean` defines the actual positive-integer capped inverse
tree and proves monotonicity, extension along bounded paths, uniqueness
of hitting times at a nonperiodic root, and disjointness of the two
subtrees. `count_four`, `count_odd`, and `count_doubled_odd` prove the
three pointwise recurrences below. `measure_children` proves all three
strict decreases, and `fertile_children` checks the residue selection.
These are bounds on actual counts, not a floating-point residue model.

`PreimageDomain.lean` constructs a closed root domain for every positive
target prime to 3. A finite kernel check bounds every orbit starting below
4096 strictly below 2^19. Every target has a nonperiodic fertile ancestor
above that barrier; all its ancestors therefore stay above 4096. The
domain is closed under the selected productions, and its capped counts
transfer to the original target after a fixed cutoff threshold.

Validation: full `lake build` passes (9028 jobs). The
[22-declaration audit](../../formal/AxiomCheckCollatzPreimageScale.expected)
uses only `propext`, `Classical.choice`, and `Quot.sound`. The focused
probe tests plus integration and ledger gates give 153 passes and
14 skips. The regenerated probe preserves 366 exact finite tree splits,
and reports 366 nonintegral wrong-sign expressions explicitly.

Grid follow-up validation: full `lake build` passes (9029 jobs), and
the [29-declaration grid audit](../../formal/AxiomCheckCollatzPreimageGrid.expected)
has only standard Lean dependencies. Exact independent checks cover all
rounding phases, actual signed roots, and capped integer subtrees. Focused,
integration, ledger, and registry tests give 162 passes and 14 skips.

Closed-domain validation: full `lake build` passes (9031 jobs), and the
[22-declaration domain audit](../../formal/AxiomCheckCollatzPreimageDomain.expected)
uses only standard Lean dependencies. Focused, integration, ledger, and
registry checks pass (163 passed, 14 skipped), including an independent finite
forward-invariant orbit union and a counterexample to the smaller 2^18
barrier. The local kernel proof is complete; advisory ledger coverage
remains pending.

## Results

The valid residue algebra is preserved. The earlier residue-only proof of
the counting theorem is withdrawn. The exact missing shift in the minus
odd branch is

\[
y+\log_2 3-1-\log_2(1+1/(2a)),
\]

with the same positive correction for the doubled odd branch, whose
nominal shift is y+log_2 3-2. Dropping this correction is unfavorable
to a lower bound. It tends to zero as a grows, but that observation
alone does not control repeated production steps or the infimum over
all targets in a residue class.

### Uniform correction for expanding blocks

For a finite family F of inverse words with every R_w>1, take

\[
K=1+\sum_{w\in F}\frac{B_w}{R_w-1}.
\]

Then B_w<=(R_w-1)K, hence f_w(x)+K<=R_w(x+K). Induction proves
for **every** finite concatenation W of these blocks, with any real x,

\[
f_W(x)+K\le R_W(x+K).
\]

Thus there is no factor growing with the number of blocks. This is
the standard affine-shift argument, now instantiated and kernel-checked
for the signed inverse words; it is not a new density theorem. For x>0
the endpoint is at most R_W x times 1+K/x, regardless of depth.
If an internal prefix u has length at most L and x>=0, the formal proof
also gives

\[
f_{Wu}(x)+1\le 2^L R_W(x+K).
\]

This matters for the whole-path cutoff, not just endpoint height.
For the blocks EE and OE, the maps are 4x and (4x+2)/3, and K=2
already works. The OE bound is equality. For every a=1 mod 3,
2(2a+1)/3 is an integer two-step ancestor of a.

The expansion hypothesis cannot be discarded. A common translation
for E and O individually would require K>=0 and K<=-1 simultaneously.
In particular, the contracting O production in the original residue
system is not covered by this block lemma.

### Actual counting inequalities with a strict grid margin

Let N(a,X) count positive n that reach a with every intervening state at
most X. Put C(t)=2^floor(t/50) r(t mod 50), using the explicit integer
table r in `PreimageGrid.lean`; its first value is 10000. For a>=4096
with a=1 mod 3 and b=(2a+1)/3, the exact comparisons are

\[
12288b\le8193a,\quad
8193C(t+29)\le12288C(t),\quad
16386C(t)\le12288C(t+21).
\]

Consequently, for every nonperiodic such root and all t>=0,

\[
\begin{aligned}
N(a,C(t+100)a)&\ge N(4a,C(t)4a),\\
N(a,C(t+100)a)&\ge N(4a,C(t)4a)+N(b,C(t+129)b),\\
N(a,C(t+100)a)&\ge N(4a,C(t)4a)+N(2b,C(t+79)2b).
\end{aligned}
\]

The first inequality does not need nonperiodicity or the lower root
threshold. To stay in fertile classes, use the second inequality when
a=1 mod 9, the third when a=7 mod 9, and just the first when a=4 mod 9.
The two odd-branch alternatives are not added together.

For M(t,a)=10t+floor(log2(a^498)), the kernel checks

\[
\begin{aligned}
M(t,4a)+4&\le M(t+100,a),\\
M(t+79,2b)+3&\le M(t+100,a),\\
M(t+129,b)+1&\le M(t+100,a).
\end{aligned}
\]

The decisive integer inequality is
2^291 * 8193^498 < 12288^498. It keeps a strict decrease after the
signed offset is included. This gives a viable way to handle the
advanced term without the older elimination/deletion proof.
The number 4096 is an auxiliary root threshold, not a new computational
termination floor for either map.

### A closed root domain for every positive unit target

The finite barrier is the statement that every n<4096 and every k>=0
satisfy g^k(n)<2^19. A finite kernel computation stops at a smaller
state or at the explicit forward-invariant set consisting of 0 and the
fifteen known cycle members; strong induction then bounds the whole orbit.
The proof does not claim these are all cycles. Independently, the union of
the small orbits contains 6418 states, is forward closed, and has maximum
417718; 2^19=524288 is a convenient strict bound.

For every positive target a coprime to 3, at most three doublings reach
a value z in residue 1 or 7 modulo 9. The two predecessors 2z and
(2z+1)/3 are distinct and both coprime to 3. They cannot both be periodic:
a deterministic map is injective on its periodic points. Select a
nonperiodic predecessor, double once if necessary to make it fertile,
then multiply it by 2^20. The resulting root r is nonperiodic, satisfies
r=1 mod 3 and r>2^19, and reaches a. This argument also works when a
lies on a cycle, without identifying that cycle.

Define D_r to consist of fertile positive ancestors of r. Every member
is at least 4096, since a smaller start can never cross the barrier.
Every member is nonperiodic, since it reaches a nonperiodic root.
The set contains r and is closed under 4n, the odd child when n=1 mod 9,
and the doubled odd child when n=7 mod 9. These are exactly the
productions used by the grid inequalities. Thus their root hypotheses
hold throughout the induction domain, including arbitrarily deep branches.

Finally the fixed path from r to a has a finite maximum height X_0.
For every X>=X_0, extending paths gives N(r,X)<=N(a,X). The growth bound
proved below therefore transfers to the original target. The domain
component itself does not estimate growth.

The known-cycle census means the three known cycles and their fifteen
members; it supplies no exhaustiveness theorem. Existing finite tree
split checks remain computational and must retain their noncycle scope.

### The complete growth certificate and cutoff argument

The integer table has 177147 weights, one for every fertile class modulo
3^12. Its rate per grid step is p/q=5059/5000, and its weights lie between
7307142888 and Cmax=10^12. Write cbar for the minimum over the three lifts
of an odd-child class. The kernel checks, on every relevant residue,

\[
\begin{aligned}
c_m p^{100}&\le c_{4m}q^{100} &&(m=4\bmod9),\\
c_m p^{100}&\le c_{4m}q^{100}+\bar c_{(4m+2)/3}p^{79}q^{21}
  &&(m=7\bmod9),\\
c_m p^{100}q^{29}&\le c_{4m}q^{129}+\bar c_{(2m+1)/3}p^{129}
  &&(m=1\bmod9).
\end{aligned}
\]

All weight indices are reduced modulo the appropriate power of 3.
`PreimageCertificate.weightSystem_of_rows` proves that these finite checks
give the inequalities for every actual fertile root, by selecting its
actual child's lift. No class-infimum deletion is used.

`PreimageGrowth.growth_root` inducts on M(t,a) over the closed domain and
proves the exact natural-number inequality

\[
c_a p^t q^{100}\le N(a,C(t)a)\,C_{\max}q^t p^{100}.
\]

At t=50j, C(t)=10000*2^j. Count monotonicity covers the cutoffs between
these dyadic values. The strict integer comparison

\[
2^{21}5000^{1250}<5059^{1250}
\]

absorbs the fixed root and normalization constants for all sufficiently
large cutoffs. This proves the exact exponent 21/25, not a rounded decimal
claim. The rate's decimal exponent 0.846207... is diagnostic only.

The [certificate data](../../data/research/juggler/negative_preimage_density/README.md)
and generator make all five generated Lean files reproducible. Four modules
check blocks of 256 rows with kernel reduction. The independent Python
verifier checks every inequality and rejects a corrupted positive weight
at residue 4. Full `lake build` passes (9040 jobs); the
[21-declaration audit](../../formal/AxiomCheckCollatzPreimageDensity.expected)
has only standard Lean dependencies. Focused probe, integration, ledger,
and registry checks pass: 165 passed, 14 skipped. The generated certificate,
ledger rendering, and branch index pass their consistency checks.

### The fixed grid has a common mean ceiling for both signs

The new [PreimageBalance.lean](../../formal/Problems/Collatz/PreimageBalance.lean)
checks an obstruction at **every** finite level, rather than testing larger
tables. At residue level ell>=2, let M=3^(ell-2), and index the 3M positive
weights by i. A minus fertile residue is m=3i+1; a plus fertile residue is
m=3i+2. Put S=sum_i c_i and

\[
L=\sum_{j=0}^{M-1}\min(c_j,c_{j+M},c_{j+2M}),\qquad 3L\le S.
\]

For minus, the fourfold production permutes indices by i->4i+1 modulo
3M, and the two odd productions permute child indices by j->2j and
j->4j+3 modulo M. For plus these maps are i->4i+2, j->2j+1 and j->4j;
the odd parent classes exchange places. All are permutations because
2 and 4 are coprime to powers of 3. The exact numerator identities,
permutations, and both enumerations of the full weight sum are proved
in Lean. Thus either sign's normalized rows imply

\[
S\le\mu^{-100}S+(\mu^{29}+\mu^{-21})L,
\qquad
1\le F(\mu):=\mu^{-100}+\frac{\mu^{29}+\mu^{-21}}3.
\]

The cleared inequality is 3 mu^100 <= 3+mu^129+mu^79. At the harmonic
rate mu^50=2, this would give mu^79>=3 and hence 2^79>=3^50. The
opposite strict integer inequality holds. This identifies the obstruction
as the grid's rounding slack, 79/50<log_2(3), not the sign of the map.

There is also a quantitative gap. F is convex on the positive reals,
and exact rational arithmetic checks

\[
F(5069/5000)<1,\qquad F(507/500)<1,
\qquad (5069/5000)^{50}<2<(507/500)^{50}.
\]

Consequently every such certificate in the at-most-linear rate range
0<mu, mu^50<=2 must have mu<5069/5000. The kernel additionally checks
(5069/5000)^5000<2^99, so its exponent gamma=50 log_2(mu) is strictly
below 99/100. The tighter displayed bound 50 log_2(5069/5000)
is approximately 0.98865345; that decimal is diagnostic, not the proof.
This is a convenient certified ceiling, not a claim of optimality.

`certificate_power_ceiling` covers both signs and every finite level;
`harmonic_rate_excluded` excludes the harmonic rate directly from the
integer rounding inequality. The common summation proof is factored as
`balanced_mean_bound`. Independent tests use actual predecessor residues
at levels 2, 3, 4 and 12, including the committed certificate, rather than
Lean's rewritten index formulas. They verify both affine permutations
and that each child-minimum sum is exactly L.

Validation: full `lake build` passes (9041 jobs). The
[29-declaration audit](../../formal/AxiomCheckCollatzPreimageBalance.expected)
uses only standard Lean dependencies. Focused probe, integration, ledger,
and registry checks give 170 passes and 14 skips. The original generated
certificate, ledger rendering, and branch index remain consistent.

**CLOSE** increasing the residue-table size alone as a route to the
harmonic exponent in this fixed 1/50 grid. The checked 21/25 density
bound remains valid. This does not disprove harmonic divergence of a
fate class: a lower bound weaker than linear counting could still prove
it, and a different grid or a direct harmonic argument has different
requirements. No fate-specific harmonic lower bound or Juggler pressure
estimate has been supplied. The earlier finite-mass ray is still only a
backward-closed counterexample; it does not settle the fate-class question.

## Open questions

The signed x^0.84 statement is no longer open here. Its proof does not
settle whether every 3n-1 orbit reaches one of the known cycles. The
original residue-only or deletion argument remains unsupported and is
unnecessary for the checked strict-grid proof.

The x^0.84 lower bound does not supply Juggler's required
divergent harmonic-mass estimate or its growing-depth pressure bound.

## Decision

**PROMOTE** the complete signed density theorem. The residue symmetry,
height correction, closed domain, growth induction, finite certificate,
and cutoff argument are now separate checked components. Automatic
analytic transfer from residue relabelling remains closed. No new
cycle exclusion, termination theorem, or computation floor follows, and
neither Paper C nor Paper D requires modification.

**CLOSE** the fixed-grid table-size upgrade to harmonic growth, by the
all-level mean obstruction above. The actual fate-specific harmonic
question and the Juggler growing-depth pressure estimate remain **PARK**.

## Publication assessment

The signed adaptation is complete in Lean, using M. Sharpe's attributed
root-induction method and an independently generated certificate. No
independent priority claim is made for the grid method. Publication would
need to distinguish this signed formalization from the established positive
Collatz density theorem and should retain the original proof correction.
