# Paper A: sources

Lower Bounds for Cycle Lengths in the Juggler Map, Cochin, Philippe, version 1.2.3.
This archive preserves repository paths; extract it into an empty directory.

## Contents

- `docs/theory/juggler_finite_dynamics_note.md`, the canonical manuscript, with the generated LaTeX `docs/theory/cochin-juggler.tex` and the PDF `preprints/juggler_finite_dynamics_note.pdf`.
- `docs/theory/paper_a_release.json`, the SHA-256 of all 132 inputs and 3 outputs, and `docs/theory/paper_a_zenodo.json`, the Zenodo metadata.
- `tools/build_paper.py` with `tools/papers/a.json`, the same builder every laboratory paper uses, and the template and layout filter in `tools/paper_a/`.
- 106 Lean files: the paper's local import closure and its axiom audits. Mathlib and the Lean toolchain are not included; Lake fetches the versions `formal/lake-manifest.json` pins.
- The finance probe and its three tables, the curvature probe with its controls, and the two descent-floor verifiers with their chunk and run records.
- `tools/check_paper_a_numeric.py`, the independent numerical recheck, and `docs/theory/paper_a_publication_check.json`, the release review.
- `SHA256SUMS.txt`, the digest of every other member.

Third-party software, private correspondence and unpublished manuscripts are not included. Links in the documents to other laboratory records refer to the repository https://github.com/sneakyweasel/btlab.

## Verify

Python 3.11 or later, standard library only. From the extracted root:

```text
python tools/build_paper.py A --check-release
python tools/check_paper_a_numeric.py --output paper_a_numeric_check.json
```

The first command checks every input and output against the release manifest.
The numerical recheck reproduces the four period cutoffs at the supplied floors; it does not rerun the descent-floor searches.

For the formal proofs, install elan, then from `formal/`:

```text
lake exe cache get
lake build Problems.JugglerPaper
lake env lean AxiomCheckPaperA.lean
```

## Rebuild

With Pandoc and XeLaTeX installed, `python tools/build_paper.py A` rebuilds the PDF, LaTeX, metadata and manifest. The build fixes `SOURCE_DATE_EPOCH`; with pandoc.EXE 3.6.3 and MiKTeX-XeTeX 4.18 (MiKTeX 26.5) it reproduces the PDF byte for byte.

## Scope

The descent floors are supplied computations, recorded with their chunk reports but not replayed here. Independent mathematical review and full-paper Lean verification are outstanding; the manuscript separates formal proofs, external theorems, written analysis and finite computations.

The manuscript is licensed CC BY 4.0 and the software under the repository `LICENSE`.
