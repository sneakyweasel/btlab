# Paper D: sources

No m-cycles of the 3n−1 map for m ≤ 61, Cochin, Philippe, version 1.1.2.
This archive preserves repository paths; extract it into an empty directory.

## Contents

- `docs/theory/collatz_3n_minus_1_m_cycles_note.md`, the canonical manuscript, with the generated LaTeX `docs/theory/cochin-3n-minus-1-m-cycles.tex` and the PDF `preprints/collatz_3n_minus_1_m_cycles_note.pdf`.
- `docs/theory/paper_d_release.json`, the SHA-256 of all 17 inputs and 3 outputs, and `docs/theory/paper_d_zenodo.json`, the Zenodo metadata.
- `tools/build_paper.py` with `tools/papers/d.json`, the same builder every laboratory paper uses, and the template and layout filter in `tools/paper_d/`.
- 1 Lean files: the paper's local import closure and its axiom audits. Mathlib and the Lean toolchain are not included; Lake fetches the versions `formal/lake-manifest.json` pins.
- The table probe, the independent recheck, the CUDA verifier and the floor records of the 2^51 certificate.
- `SHA256SUMS.txt`, the digest of every other member.

Third-party software, private correspondence and unpublished manuscripts are not included. Links in the documents to other laboratory records refer to the repository https://github.com/sneakyweasel/btlab.

## Verify

Python 3.11 or later, standard library only. From the extracted root:

```text
python tools/build_paper.py D --check-release
```

The first command checks every input and output against the release manifest.

For the formal proofs, install elan, then from `formal/`:

```text
lake exe cache get
lake build Problems.Collatz.NegativeMCycles
```

## Rebuild

With Pandoc and XeLaTeX installed, `python tools/build_paper.py D` rebuilds the PDF, LaTeX, metadata and manifest. The build fixes `SOURCE_DATE_EPOCH`; with pandoc.EXE 3.6.3 and MiKTeX-XeTeX 4.18 (MiKTeX 26.5) it reproduces the PDF byte for byte.

## Scope

The verification floor is a computation of this laboratory, recorded with its chunk reports and calibration; the floor search is not replayed here. Rhin's measure is the one external theorem. Independent review is outstanding.

The manuscript is licensed CC BY 4.0 and the software under the repository `LICENSE`.
