"""m-cycles of the 3n-1 map above the verified floor: the Simons-de Weger template, mirrored.

The map is ``g(y) = y/2`` (``y`` even), ``(3y-1)/2`` (``y`` odd) on the positive integers, the
shortcut 3n+1 map read on the negative integers. Its known cycles are ``1``, ``(5, 7, 10)`` and
the eleven-element cycle at ``17``; every start below ``2^51`` reaches one of them (CPU
certificate to ``2^44``, GPU sweep to ``2^51``, both under ``negative_floor_3x1``)
(``negative_floor_3x1``). An m-cycle is a cycle with ``m`` odd runs, equivalently ``m`` local
minima (the first element of each odd run). This probe runs the five-step template of
Simons-de Weger 2005 / Simons 2008 on this side, with the negative-side constants derived
in ``docs/theory/collatz_3n_minus_1_m_cycles_note.md``:

* **Run identity.** For odd ``y ≠ 1`` with ``a = v_2(y - 1)``: ``g^k(y) - 1 = (3/2)^k (y - 1)``
  for ``k ≤ a``, the first ``a`` iterates are odd and ``g^a(y)`` is even. Hence a run of ``a``
  odd steps starts at ``y ≥ 2^a + 1`` (the negative Lemma 8 of Hercher 2023).
* **Cycle equation.** On a cycle with ``K`` steps and ``o`` odd steps,
  ``Lambda := o log 3 - K log 2 = -sum over odd elements y of log(1 - 1/(3y)) > 0``, and a run
  from the local minimum ``y`` contributes at most ``1/(y - 1)``. So ``Lambda ≤ m/(x_min - 1)``
  for an m-cycle whose least element is ``x_min``.
* **Chaining.** With ``u = y - 1`` at successive local minima, ``u_{i+1} < u_i^delta / 2``,
  ``delta = log_2 3``, because the local maximum is at most ``u^delta + 1`` and at least one
  halving follows. Summing the run lengths ``a_i = v_2(u_i) ≤ log_2 u_i`` around the cycle,
  ``o ≤ B(m) log_2 u_1 - (B(m) - m)/(delta - 1)`` with ``B(m) = (delta^m - 1)/(delta - 1)``, and
  ``K < delta o``.
* **Crandall.** ``Lambda ≤ m/(x_min - 1)`` makes ``o/K`` a best approximation of
  ``log 2 / log 3`` from above, so ``K`` is at least the first admissible length ``K0(m)``,
  found exactly by the three-gap walk.
* **Rhin.** ``|u_0 + u_1 log 2 + u_2 log 3| >= H^{-13.3}`` for ``H = max(|u_1|, |u_2|) >= 2``
  (Rhin 1987, Proposition p. 160, (7), as printed); with ``(u_0, u_1, u_2) = (0, -K, o)`` and
  ``H = K`` the length, ``x_min - 1 < m / Lambda <= m K^{13.3}``; against the chaining this
  bounds ``K`` above by ``K3(m)``. (The form ``exp(-13.3 (0.46057 + log K))`` carried since
  Paper A is Simons-de Weger 2005 Lemma 12, the same bound at ``H = K + L`` in the odd count;
  ``RHIN_OFFSET`` restores it for comparison.)

For each ``m`` the admissible lengths ``K < K3(m)`` with ``Lambda(K) < m/(X0 - 1)`` are
enumerated exactly, and each is tested against the chaining: an m-cycle of length ``K`` needs
``2^{L_min(K, m)} < m / Lambda(K)``. No survivor means no m-cycle above the floor. The
statement is conditional on Rhin's effective measure, an external theorem, and on nothing
else; the finite parts are 80-digit arithmetic with the margins recorded.

Not a halt theorem: it excludes cycles of a given number of odd runs above a floor, on a map
this laboratory did not invent, and says nothing about the Juggler's own cycles.
"""

from __future__ import annotations

import json
from fractions import Fraction
from typing import Any

from mpmath import mp, mpf, exp, floor, log

from research.juggler_sequence.collatz_finance_mirror import (
    _x,
    continued_fraction,
    frac,
    lambda_juggler,
    negative_cycle_survivors,
)
from research.juggler_sequence.lean_paths import DATA_ROOT, DOCS_RESEARCH

DATA_DIR = DATA_ROOT / "negative_m_cycles"
JSON_PATH = DATA_DIR / "summary.json"
DOC_PATH = DOCS_RESEARCH / "juggler_negative_m_cycles.md"

CLASS_EXCLUDED = "NEGATIVE_M_CYCLES_EXCLUDED_BELOW_M"

_DPS = 80
#: the verified floor of the 3x-1 map
FLOOR_LOG2 = 51
#: the three cycles of the 3x-1 shortcut map on the positive integers
CYCLES: tuple[tuple[int, ...], ...] = ((1,), (5, 7, 10), (17, 25, 37, 55, 82, 41, 61, 91, 136, 68, 34))
#: Rhin 1987, Proposition p. 160, (7): |u0 + u1 log 2 + u2 log 3| >= H^(-13.3) for every
#: H = max(|u1|, |u2|) >= 2, with no further constant. Here u1 = -K, u2 = o, H = K. The form
#: the laboratory carried since Paper A, exp(-13.3 (0.46057 + log K_odd)), is the same bound
#: read at H = delta * K_odd, since 0.46057 = log delta; ``RHIN_OFFSET`` is kept at zero so
#: that H is the cycle length itself.
RHIN_EXPONENT = mpf("13.3")
RHIN_OFFSET = mpf("0")


def rhin_form() -> str:
    """The bound in force, spelled out for the summary and the rendered table."""
    if RHIN_OFFSET == 0:
        return (f"Lambda >= K^(-{RHIN_EXPONENT}), K the cycle length "
                "(Rhin 1987, Proposition (7), H = max(|u_1|, |u_2|) = K)")
    return (f"Lambda > exp(-{RHIN_EXPONENT} ({RHIN_OFFSET} + log K)), K the cycle length "
            "(Simons-de Weger 2005 Lemma 12 form)")
#: floors to table, with the label each is reported under; 301 * 2^50 is the floor of
#: Simons-de Weger 2005 (Roosendaal, November 2004), for a like-for-like comparison
FLOORS: tuple[tuple[int, str], ...] = (
    (2**40, "2^40"), (2**44, "2^44"), (2**48, "2^48"), (2**49, "2^49"), (2**50, "2^50"),
    (2**51, "2^51"), (2**56, "2^56"), (301 * 2**50, "301*2^50"), (2**60, "2^60"), (2**68, "2^68"),
)
#: the floor of Simons-de Weger 2005, at which their Lemma 18 is reproduced on their own side
SDW_FLOOR = 301 * 2**50
#: their Lemma 18(b): the (odd count, even count) pairs left at 69 <= m <= 72 and the floor,
#: in units of 2^50, at which each falls (they round up)
SDW_LEMMA_18B = {
    69: [((5750934602875680, 3364081086781987), 577)],
    70: [((5750934602875680, 3364081086781987), 585)],
    71: [((5750934602875680, 3364081086781987), 593), ((11985484530117643, 7011059003092348), 624)],
    72: [((5750934602875680, 3364081086781987), 602), ((11985484530117643, 7011059003092348), 633),
         ((17736419132993323, 10375140089874335), 309), ((18220034457359606, 10658036919402709), 667),
         ((24454584384601569, 14305014835713070), 706)],
}
#: the largest m tabled; beyond the excluded range the window is reported, not enumerated
M_MAX = 120
#: more admissible lengths than this in a window and the window is reported, not walked
WALK_CAP = 200_000


def shortcut(y: int) -> int:
    return y // 2 if y % 2 == 0 else (3 * y - 1) // 2


# ---------------------------------------------------------------------------------------------
# The exact identities, as Fractions, for the tests and the known cycles
# ---------------------------------------------------------------------------------------------

def v2(n: int) -> int:
    a = 0
    while n % 2 == 0:
        n //= 2
        a += 1
    return a


def run_length(y: int) -> int:
    """``v_2(y - 1)``: the number of consecutive odd steps from odd ``y ≠ 1``."""
    assert y % 2 == 1 and y != 1
    return v2(y - 1)


def odd_run(y: int) -> list[int]:
    """The odd run from ``y``: ``y, g(y), ...`` while odd, then the even landing value."""
    out = [y]
    while out[-1] % 2 == 1:
        out.append(shortcut(out[-1]))
    return out


def cycle_data(cycle: tuple[int, ...]) -> dict[str, Any]:
    """``K``, ``o``, the local minima with their runs, and the exact cycle equation."""
    K = len(cycle)
    odds = [y for y in cycle if y % 2 == 1]
    o = len(odds)
    minima = [cycle[i] for i in range(K) if cycle[i] % 2 == 1 and cycle[i - 1] % 2 == 0]
    if o == K:
        minima = [min(cycle)]
    product = Fraction(3) ** o
    for y in odds:
        product *= Fraction(3 * y - 1, 3 * y)
    return {
        "K": K, "o": o, "m": len(minima), "minima": minima,
        "runs": {y: run_length(y) for y in minima if y != 1},
        "cycle_equation_holds": product == Fraction(2) ** K,
    }


# ---------------------------------------------------------------------------------------------
# The template's constants
# ---------------------------------------------------------------------------------------------

def delta() -> mpf:
    return log(3) / log(2)


def tower_B(m: int) -> mpf:
    """``B(m) = (delta^m - 1)/(delta - 1)``: the sum of the run-length bounds around the cycle."""
    d = delta()
    return (d ** m - 1) / (d - 1)


def log2_xmin_lower(K: int, m: int) -> mpf:
    """``L_min(K, m)``: the chaining lower bound on ``log_2(x_min - 1)`` for an m-cycle of
    length ``K``, from ``o ≤ B log_2 u_1 - (B - m)/(delta - 1)`` and ``K < delta o``."""
    d = delta()
    B = tower_B(m)
    return (mpf(K) / d + (B - m) / (d - 1)) / B


def rhin_lower(K: int) -> mpf:
    """Rhin's lower bound on ``Lambda`` at height ``K``."""
    return exp(-RHIN_EXPONENT * (RHIN_OFFSET + log(mpf(K))))


def lambda_bound(m: int, X0: int) -> mpf:
    """The cycle-equation bound ``Lambda ≤ m/(X0 - 1)`` for an m-cycle above the floor."""
    return mpf(m) / (mpf(X0) - 1)


def K3(m: int) -> int:
    """The least integer ``K*`` such that ``2^{L_min(K, m)} ≥ 2 e^{13.3 RHIN_OFFSET} m K^{13.3}``
    for every ``K ≥ K*`` (the factor is ``2m`` with ``RHIN_OFFSET = 0``), which covers
    ``m/Lambda(K) + 1``; every m-cycle has length ``K < K*``. The function
    ``g(K) = L_min(K, m) - 13.3 log_2 K - log_2(2 e^{13.3 RHIN_OFFSET} m)`` is convex, has its
    minimum at ``K = 13.3 delta B(m) / log 2`` and is negative there, so it has one root beyond
    the minimum; ``K*`` is that root rounded up, confirmed at the integers ``K* - 1`` (negative)
    and ``K*`` (non-negative). Earlier versions evaluated ``L_min`` at ``int(K)`` inside a real
    bisection and returned one more than this."""
    with mp.workdps(40):
        c = log(2 * exp(RHIN_EXPONENT * RHIN_OFFSET) * m) / log(2)
        d = delta()
        B = tower_B(m)

        def g(K: mpf) -> mpf:
            return (K / d + (B - m) / (d - 1)) / B - RHIN_EXPONENT * log(K) / log(2) - c

        kmin = RHIN_EXPONENT * d * B / log(2)
        if not g(kmin) < 0:
            raise RuntimeError(f"the ceiling function is not negative at its minimum for m = {m}")
        lo, hi = kmin, 2 * kmin
        while g(hi) < 0:
            hi *= 2
            if hi > mpf(10) ** 60:
                raise RuntimeError("no Rhin ceiling below 1e60")
        for _ in range(300):
            mid = (lo + hi) / 2
            if g(mid) < 0:
                lo = mid
            else:
                hi = mid
        Kstar = int(mp.ceil(hi))
        while Kstar - 1 > kmin and g(mpf(Kstar - 1)) >= 0:
            Kstar -= 1
        while g(mpf(Kstar)) < 0:
            Kstar += 1
        if not (g(mpf(Kstar)) >= 0 > g(mpf(Kstar - 1)) and mpf(Kstar - 1) >= kmin):
            raise RuntimeError(f"ceiling bracket failed for m = {m}")
        return Kstar


# ---------------------------------------------------------------------------------------------
# The admissible lengths: the three-gap walk on the expanding side, with a deep convergent list
# ---------------------------------------------------------------------------------------------

def _returns(eps: mpf, terms: int = 70) -> tuple[int, int, mpf, mpf]:
    """Least ``q`` with ``frac(q x) < eps`` and least ``q`` with ``1 - frac(q x) < eps``."""
    a = continued_fraction(terms)
    p0, q0, p1, q1 = 0, 1, 1, 0
    conv = []
    for ai in a:
        p0, p1 = p1, ai * p1 + p0
        q0, q1 = q1, ai * q1 + q0
        conv.append((p1, q1))
    x = _x()
    best: dict[int, int | None] = {+1: None, -1: None}
    for i in range(1, len(conv)):
        (_, qp), (_, q) = conv[i - 1], conv[i]
        ai1 = a[i + 1] if i + 1 < len(a) else 1
        for j in range(0, ai1 + 1):
            Q = qp + j * q
            if Q <= 0:
                continue
            f = frac(Q * x)
            for side, val in ((+1, f), (-1, 1 - f)):
                if val < eps and (best[side] is None or Q < best[side]):
                    best[side] = Q
        if best[+1] is not None and best[-1] is not None and q > max(best[+1], best[-1]):
            break
    if best[+1] is None or best[-1] is None:
        raise RuntimeError("convergent list too short for this eps")
    return best[+1], best[-1], frac(best[+1] * x), 1 - frac(best[-1] * x)


def admissible_lengths(eps_frac: mpf, kmax: int, cap: int = WALK_CAP) -> list[int] | None:
    """All ``K ≤ kmax`` with ``1 - frac(K x) < eps_frac`` (the expanding side), in order, by
    the three-gap walk; ``None`` if more than ``cap`` would be produced."""
    with mp.workdps(_DPS):
        q1, q2, d1, d2 = _returns(eps_frac)
        up, dn, du, dd = q2, q1, d2, d1
        K, g, out = up, du, []
        while K <= kmax:
            out.append(K)
            if len(out) > cap:
                return None
            if g + du < eps_frac:
                K += up
                g += du
            elif g >= dd:
                K += dn
                g -= dd
            else:
                K += up + dn
                g += du - dd
        return out


def contracting_lengths(eps_frac: mpf, kmax: int, cap: int = WALK_CAP) -> list[int] | None:
    """All ``K ≤ kmax`` with ``frac(K x) < eps_frac`` (the contracting side, the 3n+1 map), by
    the same three-gap walk with the two returns exchanged."""
    with mp.workdps(_DPS):
        q_up, q_dn, d_up, d_dn = _returns(eps_frac)
        up, dn, du, dd = q_up, q_dn, d_up, d_dn
        K, g, out = up, du, []
        while K <= kmax:
            out.append(K)
            if len(out) > cap:
                return None
            if g + du < eps_frac:
                K += up
                g += du
            elif g >= dd:
                K += dn
                g -= dd
            else:
                K += up + dn
                g += du - dd
        return out


def lambda_positive(K: int) -> tuple[int, mpf]:
    """The 3n+1 side: ``o = floor(K x)`` and ``Lambda = K log 2 - o log 3 = log 3 * frac(K x)``."""
    with mp.workdps(_DPS):
        x = log(2) / log(3)
        o = int(floor(K * x))
        return o, K * log(2) - o * log(3)


def row_positive(m: int, X0: int) -> dict[str, Any]:
    """The same enumerate-and-test on the 3n+1 side: Simons-de Weger's Corollary 5 window,
    their Lemma 18 list, each length tested against Corollary 5 and Lemma 7 (whose constant
    ``c_m`` is algebraically the ``2^{-(B-m)/((delta-1)B)}`` of the chaining here). The
    positive-side shifts (``x + 1 >= 2^k`` in place of ``y - 1 >= 2^a``, and their ``b``) are
    below one part in ``X0`` and are not applied."""
    with mp.workdps(_DPS):
        eps_frac = lambda_bound(m, X0) / log(3)
        ceiling = K3(m)
        lengths = contracting_lengths(eps_frac, ceiling - 1)
        survivors = []
        for K in lengths or []:
            o, lam = lambda_positive(K)
            finance = mpf(m) / lam
            tower = 2 ** log2_xmin_lower(K, m)
            if tower < finance:
                survivors.append({"K": K, "o": o, "L": K - o, "log2_slack": float(log(finance / tower) / log(2)),
                                  "falls_when_X0_over_2_50": float((finance + 1) / 2 ** 50)})
        return {"m": m, "floor": X0, "K3_rhin_ceiling": ceiling, "walked": lengths is not None,
                "admissible_count": None if lengths is None else len(lengths), "survivors": survivors,
                "excluded": lengths is not None and not survivors}


def sdw_lemma18_reproduction() -> dict[str, Any]:
    """Rows 64..72 on the 3n+1 side at Simons-de Weger's floor, against their Lemma 18."""
    rows = {m: row_positive(m, SDW_FLOOR) for m in range(64, 73)}
    found = {m: {(s["o"], s["L"]) for s in rows[m]["survivors"]} for m in rows}
    theirs = {m: {pair for pair, _ in SDW_LEMMA_18B.get(m, [])} for m in rows}
    return {
        "floor": SDW_FLOOR,
        "rows": {str(m): rows[m] for m in rows},
        "none_for_64_to_68": all(rows[m]["excluded"] for m in range(64, 69)),
        "their_pairs_all_found": all(theirs[m] <= found[m] for m in rows),
        "extra_pairs": {str(m): sorted(found[m] - theirs[m]) for m in rows if found[m] - theirs[m]},
        "killing_floors": {str(m): [(pair, kill, next(s["falls_when_X0_over_2_50"] for s in rows[m]["survivors"]
                                                     if (s["o"], s["L"]) == pair))
                                    for pair, kill in SDW_LEMMA_18B[m]] for m in SDW_LEMMA_18B},
    }


# ---------------------------------------------------------------------------------------------
# The valley-count refinement: Lemmas 1, 2 and 3 used together instead of twice separately
# ---------------------------------------------------------------------------------------------
#
# Write ``b_i = log2 u_i`` for the conjugated local minima of an m-cycle above the floor.
# The note's three lemmas are three linear constraints and one objective on the same vector:
#
#     (floor)     b_i >= L0 = log2(X0 - 1)                      every minimum is above the floor
#     (chaining)  b_{i+1} <= delta b_i - 1                      Lemma 3
#     (odd steps) sum b_i >= o                                  Lemma 1, a_i <= b_i, summed
#     (objective) Lambda < sum 2^{-b_i}                         Lemma 2
#
# Lemma 2 relaxes this to ``Lambda < m 2^{-L0}`` by putting every minimum at the floor, and
# Lemma 3 relaxes it to ``L0 >= o / B(m)`` by ignoring the objective. Both relaxations are
# loose at once: a cycle cannot have all its valleys at the floor *and* carry o odd steps,
# because the chaining caps how fast the minima can climb away from the floor. Keeping the
# system intact is the transposition of the arrangement behind Hercher's Main Theorem 21.
#
# The bound is taken through a threshold. For any ``T >= L0``, the chaining limits how many
# minima can sit at or below ``T`` once the cycle has to carry ``o`` odd steps; those
# contribute at most ``2^{-L0}`` each to the objective and the rest at most ``2^{-T}`` each.
# Minimizing over ``T`` gives ``valley_cap``, and a length is excluded when its Lambda already
# exceeds it. At ``T = L0`` the bound is exactly Lemma 2, so it is never weaker.


def _valley_thresholds(m, o, delta_, mpf_):
    """T_r, where R(T) >= r exactly when T >= T_r:  T_r = (o + A_g)/(r + B_g), g = m - r,
    A_g = sum_{t=1..g} (delta^t - 1)/(delta - 1),  B_g = sum_{t=1..g} delta^t."""
    powers, p = [], mpf_(1)
    for _ in range(m + 1):
        p *= delta_
        powers.append(p)
    A = [mpf_(0)]
    Bs = [mpf_(0)]
    for g in range(1, m + 1):
        A.append(A[-1] + (powers[g - 1] - 1) / (delta_ - 1))
        Bs.append(Bs[-1] + powers[g - 1])
    return {r: (mpf_(o) + A[m - r]) / (r + Bs[m - r]) for r in range(m + 1)}


def _valley_cap_from(m, o, X0, delta_, mpf_, log_):
    """Lemma 6 minimised exactly. On [T_r, T_{r+1}) the bound is r 2^-L0 + (m-r) 2^-T, which
    falls with T, so each r is best just below T_{r+1}; r = m gives Lemma 2."""
    L0 = log_(mpf_(X0) - 1, 2)
    T = _valley_thresholds(m, o, delta_, mpf_)
    best = mpf_(m) * mpf_(2) ** (-L0)
    for r in range(m):
        Tr = T[r + 1]
        if Tr <= L0:
            continue
        best = min(best, r * mpf_(2) ** (-L0) + (m - r) * mpf_(2) ** (-Tr))
    return best


def valley_cap(m: int, o: int, X0: int) -> mpf:
    """Upper bound on ``sum 2^{-b_i}``, hence on ``Lambda``, for an m-cycle above ``X0``.

    Lemma 6 holds for every threshold ``T >= L0 = log2(X0 - 1)``. The bound is piecewise in
    ``T`` with breakpoints ``T_r``, and on each piece it falls with ``T``, so the exact
    minimum is read off the breakpoints. At ``T = L0`` it is Lemma 2's ``m / (X0 - 1)``, so
    the cap is never weaker."""
    with mp.workdps(_DPS):
        return _valley_cap_from(m, o, X0, delta(), mpf, lambda z, b: log(z) / log(b))


def valley_excluded(m: int, K: int, X0: int) -> bool:
    """Does the valley count exclude a length that the plain chaining leaves open?"""
    with mp.workdps(_DPS):
        o, lam = lambda_juggler(K)
        return lam >= valley_cap(m, o, X0)


def valley_refined(rows: list[dict[str, Any]], X0: int) -> dict[str, Any]:
    """Re-test every survivor of a floor's table against the valley cap."""
    out, excluded_through = [], 0
    still_open = None
    for r in rows:
        left = [s for s in r["survivors"] if not valley_excluded(r["m"], s["K"], X0)]
        row = {"m": r["m"], "survivors_before": len(r["survivors"]),
               "survivors_after": [s["K"] for s in left],
               "excluded": r["excluded"] or not left}
        out.append(row)
        if row["excluded"] and excluded_through == r["m"] - 1:
            excluded_through = r["m"]
        elif still_open is None and not row["excluded"]:
            still_open = r["m"]
    return {"excluded_through": excluded_through, "first_open_m": still_open, "rows": out}


# ---------------------------------------------------------------------------------------------
# One row of the table
# ---------------------------------------------------------------------------------------------

def row(m: int, X0: int) -> dict[str, Any]:
    """The template at ``(m, X0)``: the Rhin ceiling, the admissible lengths below it, and
    which of them survive the chaining."""
    with mp.workdps(_DPS):
        eps = lambda_bound(m, X0)
        eps_frac = eps / log(3)
        ceiling = K3(m)
        expected = float(eps_frac * ceiling)
        lengths = admissible_lengths(eps_frac, ceiling - 1) if expected < WALK_CAP / 2 else None
        survivors = []
        K0 = None
        margin = None
        plain_survivors, plain_margin = [], None
        if lengths is not None:
            K0 = lengths[0] if lengths else None
            for K in lengths:
                o, lam = lambda_juggler(K)
                finance = mpf(m) / lam                      # x_min - 1 ≤ this
                tower = 2 ** log2_xmin_lower(K, m)          # x_min - 1 > this
                chaining = log(finance / tower) / log(2)    # Theorem 8, first display
                valley = log(valley_cap(m, o, X0) / lam) / log(2)   # second display, Lemma 6
                slack = float(min(chaining, valley))
                if plain_margin is None or float(chaining) > plain_margin:
                    plain_margin = float(chaining)
                if tower < finance:
                    plain_survivors.append(K)
                if margin is None or slack > margin:
                    margin = slack
                if slack > 0:
                    survivors.append({
                        "K": K, "o": o, "Lambda": float(lam),
                        "xmin_minus_one_le": float(finance),
                        "xmin_minus_one_gt": float(tower),
                        "log2_slack": slack,                       # the better of the two displays
                        "log2_slack_chaining": float(chaining),
                        "log2_slack_valley": float(valley),
                    })
        return {
            "m": m,
            "floor": X0,
            "lambda_bound": float(eps),
            "K3_rhin_ceiling": ceiling,
            "expected_admissible": expected,
            "walked": lengths is not None,
            "admissible_count": None if lengths is None else len(lengths),
            "K0_least_admissible": K0,
            "closest_slack_bits": margin,
            "closest_slack_bits_without_lemma_6": plain_margin,
            "rhin_free_window": lengths is not None and not lengths,
            "survivors": survivors,
            "survivors_without_lemma_6": plain_survivors,
            "excluded": lengths is not None and not survivors,
        }


def table(X0: int, m_max: int = M_MAX, stop_after_failures: int = 6) -> list[dict[str, Any]]:
    """Rows ``m = 1, 2, ...`` at the floor ``X0``, stopping a few rows past the first ``m``
    that is not excluded."""
    rows, failures = [], 0
    for m in range(1, m_max + 1):
        r = row(m, X0)
        rows.append(r)
        if not r["excluded"]:
            failures += 1
            if failures >= stop_after_failures:
                break
    return rows


def excluded_through(rows: list[dict[str, Any]]) -> int:
    """The largest ``M`` with every ``m ≤ M`` excluded."""
    M = 0
    for r in rows:
        if r["excluded"] and r["m"] == M + 1:
            M = r["m"]
        else:
            break
    return M


# ---------------------------------------------------------------------------------------------
# Sanity: the template must not exclude the cycles that exist
# ---------------------------------------------------------------------------------------------

def known_cycles_survive() -> list[dict[str, Any]]:
    """With the floor set at each known cycle's least element, that cycle's ``(m, K)`` must
    pass the chaining test: the real cycles are witnesses that the inequalities are sound."""
    out = []
    for cycle in CYCLES[1:]:
        d = cycle_data(cycle)
        xmin = min(cycle)
        with mp.workdps(_DPS):
            o, lam = lambda_juggler(d["K"])
            finance = mpf(d["m"]) / lam
            tower = 2 ** log2_xmin_lower(d["K"], d["m"])
            out.append({
                "cycle_min": xmin, "K": d["K"], "o": d["o"], "m": d["m"],
                "o_matches_ceil": o == d["o"],
                "cycle_equation_holds": d["cycle_equation_holds"],
                "finance_holds": float(finance) >= xmin - 1,
                "tower_holds": float(tower) < xmin - 1 or xmin - 1 <= 1,
                "xmin_minus_one": xmin - 1,
                "finance_bound": float(finance),
                "tower_bound": float(tower),
            })
    return out


def run_identity_checks(limit: int = 4000) -> dict[str, Any]:
    """The run identity ``g^k(y) - 1 = (3/2)^k (y - 1)`` and ``a = v_2(y - 1)`` on every odd
    ``3 ≤ y < limit``, and the run reciprocal bound ``sum 1/(3 y_k - 1) ≤ 1/(y - 1)``."""
    worst_ratio = Fraction(0)
    checked = 0
    for y in range(3, limit, 2):
        a = run_length(y)
        run = odd_run(y)
        assert len(run) == a + 1, (y, a, run)
        u = Fraction(y - 1)
        for k, v in enumerate(run):
            assert Fraction(v - 1) == u * Fraction(3, 2) ** k, (y, k)
        recip = sum(Fraction(1, 3 * v - 1) for v in run[:-1])
        ratio = recip * (y - 1)
        worst_ratio = max(worst_ratio, ratio)
        checked += 1
    return {"checked": checked, "worst_recip_times_u": float(worst_ratio),
            "bound_holds": worst_ratio <= 1}


# ---------------------------------------------------------------------------------------------
# Payload, markdown, main
# ---------------------------------------------------------------------------------------------

def probe_payload() -> dict[str, Any]:
    tables = {}
    for X0, label in FLOORS:
        rows = table(X0)
        tables[label] = {
            "floor": X0,
            "excluded_through": excluded_through(rows),
            "rows": rows,
        }
    at_floor = tables[f"2^{FLOOR_LOG2}"]
    M = at_floor["excluded_through"]
    first_open = next((r for r in at_floor["rows"] if not r["excluded"]), None)
    mfree = negative_cycle_survivors(mpf(2 ** FLOOR_LOG2), 400_000_000)
    return {
        "map": "g(y) = y/2 (even), (3y-1)/2 (odd) on the positive integers; the shortcut 3n+1 map on the negatives",
        "known_cycles": [list(c) for c in CYCLES],
        "known_cycle_data": [{k: (v if k != "runs" else {str(a): b for a, b in v.items()})
                              for k, v in cycle_data(c).items()} for c in CYCLES],
        "floor_log2": FLOOR_LOG2,
        "rhin": {"exponent": float(RHIN_EXPONENT), "offset": float(RHIN_OFFSET),
                 "form": rhin_form()},
        "identity_checks": run_identity_checks(),
        "known_cycles_survive": known_cycles_survive(),
        "tables": tables,
        "m_free_survivors_at_floor": mfree[:12],
        "sdw_lemma18_reproduction": sdw_lemma18_reproduction(),
        "valley_refinement": valley_refined(at_floor["rows"], 2 ** FLOOR_LOG2),
        "valley_ladder": {label: valley_refined(tables[label]["rows"], X0)["excluded_through"]
                          for X0, label in FLOORS},
        "classification": {
            "label": CLASS_EXCLUDED if M >= 1 else "NEGATIVE_M_CYCLES_TABLES_INCONCLUSIVE",
            "excluded_through_at_floor": M,
            "first_open_m": None if first_open is None else first_open["m"],
            "first_open_survivors": None if first_open is None else first_open["survivors"],
            "conditional_on": f"Rhin 1987 (external theorem); the floor 2^{FLOOR_LOG2} (laboratory certificate: CPU to 2^44, GPU to 2^51)",
        },
    }


def render_markdown(data: dict[str, Any]) -> str:
    lines = [
        "# m-cycles of the 3x-1 map above the floor",
        "",
        "Generated by `python -m research.juggler_sequence.negative_m_cycles`; do not edit.",
        "",
        f"Map: {data['map']}. Known cycles: {data['known_cycles']}. Verified floor `2^{data['floor_log2']}`.",
        "",
        f"Rhin's bound used: `{data['rhin']['form']}`.",
        "",
        "| floor | m excluded through | first open m | survivors at the first open m (K, o, log2 slack) |",
        "|---|---|---|---|",
    ]
    for label, t in data["tables"].items():
        first_open = next((r for r in t["rows"] if not r["excluded"]), None)
        if first_open is None:
            desc = "none in the tabled range"
            fm = "—"
        else:
            fm = str(first_open["m"])
            if not first_open["walked"]:
                desc = f"window not walked ({first_open['expected_admissible']:.0f} expected lengths)"
            else:
                desc = "; ".join(f"({s['K']}, {s['o']}, {s['log2_slack']:.1f})" for s in first_open["survivors"][:6])
        lines.append(f"| {label} | {t['excluded_through']} | {fm} | {desc} |")
    lines += ["", "## Rows at the verified floor", "",
              "| m | Lambda bound | K3 (Rhin ceiling) | admissible K below K3 | least admissible K | survivors |",
              "|---|---|---|---|---|---|"]
    for r in data["tables"][f"2^{data['floor_log2']}"]["rows"]:
        adm = "not walked" if not r["walked"] else str(r["admissible_count"])
        k0 = "—" if r["K0_least_admissible"] is None else str(r["K0_least_admissible"])
        surv = "none" if r["excluded"] else ("?" if not r["walked"] else str([s["K"] for s in r["survivors"]]))
        lines.append(f"| {r['m']} | {r['lambda_bound']:.3e} | {r['K3_rhin_ceiling']} | {adm} | {k0} | {surv} |")
    sdw = data["sdw_lemma18_reproduction"]
    lines += ["", "## Simons-de Weger Lemma 18 on their own side", "",
              f"The same enumerate-and-test with the window on the contracting side, at their floor "
              f"{sdw['floor']}: none for 64 <= m <= 68: {sdw['none_for_64_to_68']}; their pairs all found: "
              f"{sdw['their_pairs_all_found']}; extra pairs: {sdw['extra_pairs']}.", "",
              "| m | admissible | survivors (odd K, even L, log2 slack, falls when X0 >= n * 2^50) |", "|---|---|---|"]
    for m, r in sdw["rows"].items():
        desc = "; ".join(f"({s['o']}, {s['L']}, {s['log2_slack']:.1f}, {s['falls_when_X0_over_2_50']:.1f})"
                         for s in r["survivors"]) or "none"
        lines.append(f"| {m} | {r['admissible_count']} | {desc} |")
    v = data["valley_refinement"]
    lines += ["", "## The valley-count refinement at the verified floor", "",
              "Lemmas 1, 2 and 3 as one constraint system rather than two separate relaxations: "
              f"excluded through m = {v['excluded_through']}, first open m = {v['first_open_m']} "
              f"(the plain tables give {data['classification']['excluded_through_at_floor']} and "
              f"{data['classification']['first_open_m']}).", "",
              "| m | survivors before | survivors after |", "|---|---|---|"]
    for row in v["rows"]:
        if row["survivors_before"] or row["survivors_after"]:
            lines.append(f"| {row['m']} | {row['survivors_before']} | "
                         f"{row['survivors_after'] or 'none'} |")
    lines += ["", "## The cycles that exist pass the same test", ""]
    for c in data["known_cycles_survive"]:
        lines.append(f"- least element {c['cycle_min']}: K = {c['K']}, o = {c['o']}, m = {c['m']}; "
                     f"cycle equation exact: {c['cycle_equation_holds']}; finance bound {c['finance_bound']:.2f} "
                     f"≥ x_min - 1 = {c['xmin_minus_one']}: {c['finance_holds']}; tower bound "
                     f"{c['tower_bound']:.2f} < x_min - 1: {c['tower_holds']}")
    lines += ["", f"Classification: `{data['classification']['label']}`, excluded through m = "
              f"{data['classification']['excluded_through_at_floor']} at `2^{data['floor_log2']}`, "
              f"conditional on {data['classification']['conditional_on']}.", ""]
    return "\n".join(lines)


def write_artifacts(payload: dict[str, Any] | None = None) -> dict[str, Any]:
    data = payload or probe_payload()
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    JSON_PATH.write_text(json.dumps(data, indent=2, default=str) + "\n", encoding="utf-8")
    DOC_PATH.write_text(render_markdown(data), encoding="utf-8")
    return data


def main() -> None:
    data = write_artifacts()
    c = data["classification"]
    print(f"{c['label']}: m-cycles excluded through m = {c['excluded_through_at_floor']} at 2^{FLOOR_LOG2}; "
          f"first open m = {c['first_open_m']}")
    for label, t in data["tables"].items():
        print(f"  floor {label}: excluded through m = {t['excluded_through']}")
    print(f"wrote {JSON_PATH} and {DOC_PATH}")


if __name__ == "__main__":
    main()
