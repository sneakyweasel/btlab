# Paper B: sources

Five-Step Descent Certificates for the Juggler Map: Parity Statistics of Nested Floor Powers, Cochin, Philippe, version 1.2.0.
This archive preserves repository paths; extract it into an empty directory.

## Contents

- `docs/theory/juggler_parity_discrepancy_note.md`, the canonical manuscript, with the generated LaTeX `docs/theory/juggler_parity_discrepancy_note.tex` and the PDF `preprints/juggler_parity_discrepancy_note.pdf`.
- `docs/theory/paper_b_release.json`, the SHA-256 of all 21 inputs and 3 outputs, and `docs/theory/paper_b_zenodo.json`, the Zenodo metadata.
- `tools/build_paper.py` with `tools/papers/b.json`, the same builder every laboratory paper uses, and the template and layout filter in `tools/paper_b/`.
- The exact and symbolic validators `tools/validate_paper_b*.py`, their recorded results and the proof review.
- `SHA256SUMS.txt`, the digest of every other member.

Third-party software, private correspondence and unpublished manuscripts are not included. Links in the documents to other laboratory records refer to the repository https://github.com/sneakyweasel/btlab.

## Verify

Python 3.11 or later, standard library only. From the extracted root:

```text
python tools/build_paper.py B --check-release
python tools/validate_paper_b_consolidated.py --output paper_b_validation.json
```

The first command checks every input and output against the release manifest.
The validator reruns Paper B's exact controls and audits the consolidated source references.

## Rebuild

With Pandoc and XeLaTeX installed, `python tools/build_paper.py B` rebuilds the PDF, LaTeX, metadata and manifest. The build fixes `SOURCE_DATE_EPOCH`; with pandoc.EXE 3.6.3 and MiKTeX-XeTeX 4.18 (MiKTeX 26.5) it reproduces the PDF byte for byte.

## Scope

The exact and symbolic scripts check algebra and exponent bookkeeping; they do not certify asymptotic cancellation. Independent mathematical review and complete Lean verification are outstanding.

The manuscript is licensed CC BY 4.0 and the software under the repository `LICENSE`.
